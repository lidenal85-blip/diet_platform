# Дамп проекта: diet_platform

> Собран: 2026-08-14 09:50:37

## Дерево файлов
````text
.claude/claude.md
.claude/claude.template.md
.env
.env.bak-20260630181938
.env.bak_before_key_cleanup
.env.example
.gitignore
.pytest_cache/.gitignore
.pytest_cache/CACHEDIR.TAG
.pytest_cache/README.md
.pytest_cache/v/cache/lastfailed
.pytest_cache/v/cache/nodeids
MANIFEST.md
PRODUCT_BACKLOG.md
PROJECT_DUMP.md
README.md
TEAM_NOTES.md
api/cabinet_router.py
api/miniapp_router.py
bot.py
bot_handlers/__init__.py
bot_handlers/cabinet.py
bot_handlers/diet_picker.py
bot_handlers/meal_schedule_v2.py
bot_handlers/puhlyash_settings.py
bot_handlers/reactions.py
bot_handlers/recipes.py
bot_handlers/recipes.py.bak_before_model_switch
bot_handlers/schedule.py
building_blocks/__init__.py
building_blocks/config.py
building_blocks/config.py.bak_before_model_switch
building_blocks/contracts.py
building_blocks/logger.py
building_blocks/vault_integration.py
database.py
database_migration_v2.sql
diet_platform.db
diet_platform.db-shm
diet_platform.db-wal
dump_project.sh
dump_project.sh.bak
logs/diet_platform.log
main.py
modules/__init__.py
modules/delivery_api/controllers/api.py
modules/diet_extractor/engine/gemini_extractor.py
modules/diet_extractor/engine/gemini_extractor.py.bak_before_model_switch
modules/diet_extractor/sanitizer/text_sanitizer.py
modules/diet_registry/domain/medical_guard.py
modules/diet_registry/infrastructure/repository.py
modules/fitness/__init__.py
modules/fitness/engine.py
modules/notifier/__init__.py
modules/notifier/sender.py
modules/notifier/sender.py.bak_20260619_211357
modules/puhlyash/__init__.py
modules/puhlyash/irisochka.py
modules/puhlyash/persona.py
modules/reactions/__init__.py
modules/reactions/engine.py
modules/recipes/__init__.py
modules/recipes/engine.py
modules/recipes/prompt_builder.py
modules/scheduler/__init__.py
modules/scheduler/meal_scheduler.py
modules/search_gateway/internal/searcher.py
modules/web_scraper/fetcher/http_fetcher.py
modules/web_scraper/network/ssrf_guard.py
start_here/MASTER_PROMPT.md
start_here/PASSPORT.md
start_here/ROADMAP_v4_assistant.md
start_here/__init__.py
start_here/logs/session_20260527_001.md
start_here/logs/session_20260527_002.md
start_here/logs/snapshot_v1_foundation.md
start_here/session_logger.py
tests/__init__.py
tests/test_puhlyash.py
tests/test_vault_integration.py
workers/pipeline_worker.py
````

---

## Файл: .claude/claude.md

`5278 байт`

````

# diet_platform - Claude Context
**Generated:** 2026-06-30 11:46




## Last Checkpoint
**Синхронизация после параллельной работы. Прочитан TEAM_NOTES.md — обнаружено что баг с Userbot Relay (который я нашёл и зарепортил в предыдущем ответе) уже закрыт параллельной сессией (коммит 5f607c5, мой f27ee9f лёг под ним в истории без конфликтов). Не поверил тексту чекпоинта на слово — живьм вызовом send_notification() подтвердил True за 0.54s. Проверил aiogram getUpdates конфликт у den4ik-claude — за 2 часа ни одного события, похоже исчез. Проверил bot token (8954955644, засвечён открытым текстом в чате) — всё ещё жив, не отозван сам, решение оставлено владельцу (downtime-risk операция). Начал было смотреть F2 (timezone) — подтверждён хардкод Europe/Moscow везде, но саму реализацию не начал — решил спросить приоритеты у Denis перед тем как уходить в бэклог без явного запроса (его сообщение было 'TEAM_NOTES / ctx restore / ctx start' — сигнал на синхронизацию, не на дальнейший разработки). Сервисы проверены active, живых изменений в git не вносилось (только .claude/claude.md локально изменён, не трогал).**
_2026-06-30T11:46 | claude_


Next steps:
- [ ] E1: передать weight_kg/health_notes/goal в fitness/engine.py промпт — приоритет безопасности
- [ ] I2: запрет выдумывать детали в SYS_PUHLYASH/SYS_DIET
- [ ] F2: timezone в user_profiles + per-user APScheduler — подтверждён хардкод Europe/Moscow, реализация не начата — ждёт приоритизации от Denis
- [ ] Groq: обновить протухшие ключи GROQ_K1..K5 на console.groq.com — всё ещё не проверено ни в одной сессии
- [ ] I1: modules/irisochka/persona.py по образцу puhlyash/persona.py — ЧАСТИЧНО СДЕЛАНО в modules/puhlyash/irisochka.py в этой сессии (коммит f27ee9f) — проверить пересекается ли с этим next_step или он устарел
- [ ] RESOLVE: bot token 8954955644 засвечён в чате, жив и рабочий (проверено getMe) — решить ротацию с Denis, ротация = downtime для живых пользователей
- [ ] CLOSED: aiogram getUpdates conflict у den4ik-claude — проверено, 2 часа без событий, похоже исчез с переходом на leviathan_hub_bot.py — можно убрать из next_steps
- [ ] Убрать userbot_relay_token из config/.env если роллбэк точно не понадобится — без изменений




## Architectural Decisions

**integration:** Userbot Relay и Pyrogram полностью убраны. modules/notifier/sender.py теперь использует собственный aiogram Bot() diet_platform (короткоживущий инстанс на каждую отправку). Никакой зависимости от den4ik-claude больше нет. userbot_relay_token оставлен в config для быстрого rollback, но не используется. Коммит 5f607c5.
> Что делать после того как den4ik-claude мигрировал на leviathan_hub_bot.py и сломал Userbot Relay (Pyrogram больше не запущен)?

**database:** aiosqlite.connect() всегда с timeout=30. Алиасы DB_PATH (_DB, db_path и др.) должны проверяться вручную: sed-фикс искал только литерал DB_PATH и пропустил алиас _DB.
> Почему возникает database is locked?

**llm:** LLMFactory.execute_request() для всех LLM-вызовов в проекте. Нельзя читать ключи regex'ом из .env. Нельзя делать urllib.request синхронно. ISSUE-03 закрыт: 5 файлов полностью переведены.
> Как делать LLM-вызовы в diet_platform?

**integration:** Userbot Relay: den4ik-claude остаётся единственным владельцем Pyrogram-сессии. Внутри его asyncio.gather() запущен мини-FastAPI на 127.0.0.1:8190. diet_platform шлёт httpx POST /relay/send с X-Relay-Token. Полное слияние отклонено: разные blast radius (den4ik-claude имеет systemctl-права над всеми сервисами).
> Как объединить два проекта владельца для отправки Telegram-сообщений через один Pyrogram userbot?







````

---

## Файл: .claude/claude.template.md

`1119 байт`

````

# {{project}} - Claude Context
**Generated:** {{generated_at}}

{% if active_session %}
## Active Task
**{{active_session.task}}** ({{active_session.developer}}, since {{active_session.started[:16]}})
{% endif %}

{% if latest_checkpoint %}
## Last Checkpoint
**{{latest_checkpoint.summary}}**
_{{latest_checkpoint.ts[:16]}} | {{latest_checkpoint.developer}}_
{% set steps = latest_checkpoint.next_steps %}
{% if steps %}
Next steps:
{% for s in steps %}- [ ] {{s}}
{% endfor %}{% endif %}
{% else %}
## Last Checkpoint
No checkpoints yet.
{% endif %}

{% if decisions %}
## Architectural Decisions
{% for d in decisions %}
**{{d.category}}:** {{d.decision}}
> {{d.question}}
{% endfor %}{% endif %}

{% if invariants %}
## Established Patterns
{% for i in invariants %}
- {{i.category}}: **{{i.pattern}}** (x{{i.count}})
{% endfor %}{% endif %}

{% if recent_actions %}
## Recent Actions
{% for a in recent_actions[:10] %}
- `{{a.tool}}` {{a.desc}} ({{a.ts[11:16]}})
{% endfor %}{% endif %}

{% if stalled %}
## Stalled Tasks
{% for s in stalled %}
- **{{s.task}}** (since {{s.started[:16]}})
{% endfor %}{% endif %}

````

---

## Файл: .env

`1158 байт`

````
# Diet Platform — конфигурация
# Gemini key pool — 14 ключей (те же что у агента, ротация round-robin)
GEMINI_API_KEY=AIzaSyB8aqLGZsQYZPveDH8tCiCiczo1iNEchOE
GEMINI_KEYS=AIzaSyB4JpiPsipa-tzSIwSH_aoB3tSowhyAeT4,AIzaSyCkGacyKFOrCCQAb1U68jWM2aeGwGNr1o8,AIzaSyB8aqLGZsQYZPveDH8tCiCiczo1iNEchOE,AIzaSyDoIlRxLMo8qD365AwQozsNjbV7qO7ydaw,AIzaSyAZ0P9nWyK9Jf_HFS_SW81t-R00ZYW7l8U,AIzaSyDyJi_9YBT0PmmHLoby8ofoRgCuxCJaW9M,AIzaSyBgUwjHekBNpwLTdylnzVjoz_wj_zhlm3Q,AIzaSyAoUAU3gUVgNWk5mT4Esu6GEiNe87jEbw8
GEMINI_MODEL=gemini-3.1-flash-lite

# Telegram Bot «Пухляш»
TELEGRAM_BOT_TOKEN=8954955644:AAH9hsGQDd6Fm8dmq4Plr0Ye7cFD6tc-bvc

# Userbot Relay (den4ik-claude) — CONFLICT-01 fix, см. TEAM_NOTES.md
USERBOT_RELAY_TOKEN=_5rZ-eWT2E_I_g948dyTiZ7gPnbmj9eXWuhM2Iy_jOo

# App
APP_HOST=0.0.0.0
APP_PORT=8150
DEBUG=false

# DB
DATABASE_PATH=/opt/diet_platform/diet_platform.db

# Search
MAX_URLS_PER_QUERY=5
SEARCH_CACHE_TTL_HOURS=24

# Scraper
SCRAPER_TIMEOUT_SECONDS=15
SCRAPER_MAX_RETRIES=3

# Worker
WORKER_POLL_INTERVAL_SECONDS=3
WORKER_MAX_CONCURRENT=3

# Registry
MIN_CONFIDENCE_SCORE=0.15
AUTO_PUBLISH_THRESHOLD=0.75
````

---

## Файл: .env.bak-20260630181938

`1158 байт`

````
# Diet Platform — конфигурация
# Gemini key pool — 14 ключей (те же что у агента, ротация round-robin)
GEMINI_API_KEY=AIzaSyAJn81A1qktaENz5Dpa-FbpkWXbm1SIf9M
GEMINI_KEYS=AIzaSyB4JpiPsipa-tzSIwSH_aoB3tSowhyAeT4,AIzaSyCkGacyKFOrCCQAb1U68jWM2aeGwGNr1o8,AIzaSyB8aqLGZsQYZPveDH8tCiCiczo1iNEchOE,AIzaSyDoIlRxLMo8qD365AwQozsNjbV7qO7ydaw,AIzaSyAZ0P9nWyK9Jf_HFS_SW81t-R00ZYW7l8U,AIzaSyDyJi_9YBT0PmmHLoby8ofoRgCuxCJaW9M,AIzaSyBgUwjHekBNpwLTdylnzVjoz_wj_zhlm3Q,AIzaSyAoUAU3gUVgNWk5mT4Esu6GEiNe87jEbw8
GEMINI_MODEL=gemini-3.1-flash-lite

# Telegram Bot «Пухляш»
TELEGRAM_BOT_TOKEN=8954955644:AAH9hsGQDd6Fm8dmq4Plr0Ye7cFD6tc-bvc

# Userbot Relay (den4ik-claude) — CONFLICT-01 fix, см. TEAM_NOTES.md
USERBOT_RELAY_TOKEN=_5rZ-eWT2E_I_g948dyTiZ7gPnbmj9eXWuhM2Iy_jOo

# App
APP_HOST=0.0.0.0
APP_PORT=8150
DEBUG=false

# DB
DATABASE_PATH=/opt/diet_platform/diet_platform.db

# Search
MAX_URLS_PER_QUERY=5
SEARCH_CACHE_TTL_HOURS=24

# Scraper
SCRAPER_TIMEOUT_SECONDS=15
SCRAPER_MAX_RETRIES=3

# Worker
WORKER_POLL_INTERVAL_SECONDS=3
WORKER_MAX_CONCURRENT=3

# Registry
MIN_CONFIDENCE_SCORE=0.15
AUTO_PUBLISH_THRESHOLD=0.75
````

---

## Файл: .env.bak_before_key_cleanup

`1398 байт`

````
# Diet Platform — конфигурация
# Gemini key pool — 14 ключей (те же что у агента, ротация round-robin)
GEMINI_API_KEY=AIzaSyAJn81A1qktaENz5Dpa-FbpkWXbm1SIf9M
GEMINI_KEYS=AIzaSyAJn81A1qktaENz5Dpa-FbpkWXbm1SIf9M,AIzaSyAE4DA61xT8_bGCSg1K4hxGhKZjPjweV80,AIzaSyB4JpiPsipa-tzSIwSH_aoB3tSowhyAeT4,AIzaSyCkGacyKFOrCCQAb1U68jWM2aeGwGNr1o8,AIzaSyB8aqLGZsQYZPveDH8tCiCiczo1iNEchOE,AIzaSyDoIlRxLMo8qD365AwQozsNjbV7qO7ydaw,AIzaSyDDz41eXC61Oud9VtgZFni3H6fqo6zPAog,AIzaSyDnksYjASQEIeA55P9KKXAsWFxIBobpnf0,AIzaSyAMJmkqb15Or8JutY4tSrMaCgF41N_Omr0,AIzaSyAgT55rH8aI17iFlmHLqQo15Rqqws_VcNI,AIzaSyAZ0P9nWyK9Jf_HFS_SW81t-R00ZYW7l8U,AIzaSyDyJi_9YBT0PmmHLoby8ofoRgCuxCJaW9M,AIzaSyBgUwjHekBNpwLTdylnzVjoz_wj_zhlm3Q,AIzaSyAoUAU3gUVgNWk5mT4Esu6GEiNe87jEbw8
GEMINI_MODEL=gemini-2.5-flash-lite

# Telegram Bot «Пухляш»
TELEGRAM_BOT_TOKEN=8954955644:AAH9hsGQDd6Fm8dmq4Plr0Ye7cFD6tc-bvc

# Userbot Relay (den4ik-claude) — CONFLICT-01 fix, см. TEAM_NOTES.md
USERBOT_RELAY_TOKEN=_5rZ-eWT2E_I_g948dyTiZ7gPnbmj9eXWuhM2Iy_jOo

# App
APP_HOST=0.0.0.0
APP_PORT=8150
DEBUG=false

# DB
DATABASE_PATH=/opt/diet_platform/diet_platform.db

# Search
MAX_URLS_PER_QUERY=5
SEARCH_CACHE_TTL_HOURS=24

# Scraper
SCRAPER_TIMEOUT_SECONDS=15
SCRAPER_MAX_RETRIES=3

# Worker
WORKER_POLL_INTERVAL_SECONDS=3
WORKER_MAX_CONCURRENT=3

# Registry
MIN_CONFIDENCE_SCORE=0.15
AUTO_PUBLISH_THRESHOLD=0.75
````

---

## Файл: .env.example

`788 байт`

````
# === DIET PLATFORM CONFIG ===

# App
APP_HOST=0.0.0.0
APP_PORT=8150
DEBUG=false

# SQLite
DATABASE_URL=sqlite+aiosqlite:///./diet_platform.db
DATABASE_PATH=/opt/diet_platform/diet_platform.db

# Gemini
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-2.0-flash

# Telegram Bot
TELEGRAM_BOT_TOKEN=your_bot_token_here

# Userbot Relay (смотри TEAM_NOTES.md / CONFLICT-01)
USERBOT_RELAY_TOKEN=ask_owner_for_token

# Search
SERPAPI_KEY=optional_serpapi_key
MAX_URLS_PER_QUERY=5
SEARCH_CACHE_TTL_HOURS=24

# Scraper
SCRAPER_TIMEOUT_SECONDS=15
SCRAPER_MAX_RETRIES=3
SCRAPER_USER_AGENT=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36

# Worker
WORKER_POLL_INTERVAL_SECONDS=3
WORKER_MAX_CONCURRENT=3

# Registry
MIN_CONFIDENCE_SCORE=0.4
AUTO_PUBLISH_THRESHOLD=0.75

````

---

## Файл: .gitignore

`97 байт`

````
__pycache__/
*.pyc
*.pyo
.env
*.db
logs/
*.log
.DS_Store
venv/
.venv/
*.bak
*.bak_*
*.swp
.*.swp

````

---

## Файл: .pytest_cache/.gitignore

`37 байт`

````
# Created by pytest automatically.
*

````

---

## Файл: .pytest_cache/README.md

`302 байт`

````
# pytest cache directory #

This directory contains data from the pytest's cache plugin,
which provides the `--lf` and `--ff` options, as well as the `cache` fixture.

**Do not** commit this to version control.

See [the docs](https://docs.pytest.org/en/stable/how-to/cache.html) for more information.

````

---

## Файл: MANIFEST.md

`2481 байт`

````
# Паспорт проекта Diet Platform «Пухляш»

| Поле | Значение |
|---|---|
| **Название** | Diet Platform «Пухляш» |
| **Версия** | 1.0.0 (MVP) |
| **Назначение** | Telegram-бот — персональный ассистент по питанию, диетам и фитнесу |
| **Владелец** | lidenal85-blip |
| **Лицензия** | MIT |
| **Среда** | Linux VPS, Python 3.10+ |
| **Требования к правам** | No-root, systemd unit |
| **Статус** | 🟡 Production MVP (12 диет сгенерировано, 2 реальных пользователя) |

## Цели

1. Генерировать персонализированные рецепты через LLM.
2. Составлять планы питания на неделю с учётом здоровья/целей/бюджета.
3. Предлагать безопасные фитнес-упражнения (офисная разминка, не спорт).
4. Отправлять напоминания о приёмах пищи с рецептами.
5. Формировать список покупок из выбранных рецептов.
6. Развивать линейку маскотов: Пухляш (саркастичный кот) + Ирисочка (эмпатичная).

## Архитектура

- **FastAPI** (port 8150) + **aiogram3** бот — единый процесс
- **Pipeline:** DuckDuckGo → httpx scraper → Gemini extractor → diet_registry
- **Очередь:** SQLite Outbox (статус-поллинг каждые 3с)
- **LLM:** Leviathan LLMFactory (14 ключей Gemini 2.5-flash, KeyPool + CircuitBreaker, fallback → Groq)
- **Notifications:** собственный aiogram Bot (без Pyrogram/Userbot Relay)
- **Scheduler:** APScheduler (timezone Moscow)
- **БД:** SQLite WAL, 15+ таблиц

## Контроль Buffy

Buffy может:
- читать `README.md`, `MANIFEST.md`, `PRODUCT_BACKLOG.md`, `TEAM_NOTES.md`;
- анализировать состояние через `PRODUCT_BACKLOG.md` (9 эпиков со статусами);
- запускать `python main.py` для локального тестирования;
- проверять `modules/`, `bot_handlers/`, `api/` на изменения.

Проект **не импортирует** `freebuff_plugin` и не зависит от экосистемы freebuff.

````

---

## Файл: PRODUCT_BACKLOG.md

`19678 байт`

````
# 📋 PRODUCT BACKLOG — Diet Platform «Пухляш»

> Продуктовые требования от владельца, зафиксированы 2026-06-20.
> Каждый эпик привязан к реальным файлам (проверено по коду, не со слов).
> Статусы: 🔴 не начато / 🟡 в работе / ✅ готово

---

## EPIC A — Рецепты: meal-prep и режим готовки

### A1 🔴 Контейнеры на неделю (meal-prep)
Рецепты, которые можно заранее приготовить блоками и расфасовать по контейнерам.
- Файл: `modules/recipes/engine.py` — расширить набор режимов (сейчас home/restaurant/quick/pp)
  новым `meal_prep`
- Вывод: порции на N дней, общий список ингредиентов батчем, инструкция
  по хранению/разогреву

### A2 🔴 Генерация рецептов на всю неделю разом
Сейчас рецепт дня Recipe Day генерируется поодиночка (`puhlyash/persona.py:generate_puhlyash_recipe`).
Нужен вариант сразу на 5-7 балансированных рецептов.

### A3 🔴 Режим «Готовим с Пухляшом»
Новая фича. Для выбранного рецепта:
- Чек-лист по шагам (из `steps` рецепта)
- На каждый шаг — примерное время, запускать через APScheduler отложенный job
- Кнопка «✅ Готово» в любой момент; если время вышло и не нажата — напоминание
- Пока ждёт — Пухляш шутит/рассказывает факты (из заранее заданного пула,
  не свободным LLM-вызовом — чтобы не галлюцинировал)
- Активен ТОЛЬКО в этом режиме, не в обычном просмотре рецепта

---

## EPIC B — Интеллект диеты

### B1 🔴 Анализ фактического питания
Колонка `user_profiles.diary` уже есть в БД, но нигде не используется в коде.
Нужно: логировать съеденное (через реакции или отдельную кнопку),
передавать в промпт генерации следующей недели плана.

### B2 🔴 Объяснение «почему именно эти продукты»
`bot_handlers/diet_picker.py` генерирует списки key_foods без объяснения.
Добавить в JSON-схему поле «why» для каждой группы продуктов.

### B3 🔴 План на весь срок диеты, не только на неделю
`_get_week_plan()` в diet_picker.py даёт только 1 неделю, хотя `duration_weeks`
хранится как метаданные. Нужно хранить весь план как один объект
(новая таблица diet_program?), а не перегенерировать каждую неделю заново.

### B4 🔴 Редактирование + заметки на каждом этапе
Добавить `notes` к диете/рецептам/упражнениям, ручная правка через inline-меню.

---

## EPIC C — Интеграция списка покупок

### C1 🔴 Тоггл «интегрировать со списком покупок» в настройках
shopping_list сейчас генерируется LLM отдельно внутри _get_week_plan(),
не связана с реально выбранными рецептами. Нужна настройка-булев:
при включении список собирается из реально выбранных рецептов недели (дедупликация +
суммирование количеств).

---

## EPIC K — Перекрёстная интеграция: Диета ↔ Фитнес ↔ Рецепты ⚠️ ЗАВИСИТ ОТ B3/E1

**Зафиксировано владельцем 2026-06-21.** В настройках — возможность включить
интеграцию между тремя доменами:
- **Рецепты → Диета:** рецепты предлагаются исходя из активной диеты пользователя
- **Рецепты → Фитнес:** рецепты учитывают фитнес-цель/активность
- **Диета ↔ Фитнес:** двунаправленно — фитнес влияет на составление диеты
  (или наоборот)

### ⚠️ ЧЕСТНАЯ ТЕХНИЧЕСКАЯ ОЦЕНКА (проверено по коду)
Сейчас эти тогглы были бы декоративными — данные для реальной интеграции
физически не существуют:
- `goal` и `active_diet_mode` уже есть в `user_profiles`, НО их НЕ ЧИТАЕТ ни
  `modules/recipes/prompt_builder.py` (читает только cook_level/budget_level/
  experiment_level/max_cook_time/excluded_foods), ни `modules/puhlyash/persona.py:
  generate_puhlyash_recipe()` — проверено `grep`, ни одного упоминания goal/
  active_diet_mode
- Диета вообще НЕ хранится как структурированный объект с allowed_foods/
  forbidden_foods — `_get_week_plan()` в diet_picker.py генерирует текст один раз,
  показывает и больше нигде не сохраняет. Рецептам просто нечего «слушаться»
- Аналогично для фитнеса — пока не исправлен E1, у фитнес-движка вообще нет
  доступа даже к profile-полям, нечего будет связывать с диетой

**Вывод: этот эпик физически невозможен без B3 и E1.** Сначала нужно:
1. B3 — хранить выбранную диету как структурированный объект (таблица
   diet_program: allowed_foods/forbidden_foods/conditions на весь срок, не только текст
   на экране)
2. E1 — фитнес-движок должен видеть profile и иметь хотя бы элементарное
   понятие цели/уровня, прежде чем чем-то влиять на диету

### K1 🔴 Тогглы в профиле/кабинете
После B3+E1: три булевых флага в user_profiles рядом с остальными настройками:
`integrate_recipes_with_diet`, `integrate_recipes_with_fitness`,
`integrate_diet_with_fitness`. При включении — прокинуть соответствующие
поля (allowed_foods/forbidden_foods из diet_program, или fitness-goal) в
`build_recipe_prompt()` и `generate_puhlyash_recipe()`.

---

## EPIC D — Пользовательские рецепты/упражнения + модерация

### D1 🔴 Общая база + очередь модерации
Новые таблицы `community_recipes`, `community_exercises` со статусами
draft/pending/approved/rejected. Главный критерий — не навредить:
- Рецепты: проверка на опасные ингредиенты/аллергены без предупреждения
- Упражнения: sanity-проверка на реалистичные повторы/веса для заявленного уровня
- Approve/reject через бот или кабинет (аналогично Diet Core Registry из diet_platform)

---

## EPIC E — Безопасность и калибровка фитнеса ⚠️ ПРИОРИТЕТ

### E1 🔴 KORENЬ: промпт не видит пользователя
`modules/fitness/engine.py:generate_exercises()` подтверждено не получает ни
`weight_kg`, ни `health_notes`, ни возраст — хотя эти поля уже есть в user_profiles.
Отсюда одинаковые упражнения для всех. Нужно передавать profile в промпт
и жёстко ограничивать интенсивность для большого веса/без fitness_level=advanced.

### E2 🔴 Дашборд-упражнения = офисная разминка, НЕ тренировка
Упражнения от Пухляша (он ленив, см. арт) должны выглядеть как лёгкая
разминка в офисе: без приседаний/отжиманий по умолчанию — растяжки,
вращения плеч, ходьба на месте. Переписать MEAL_CONTEXT/SYS в fitness/engine.py.

### E3 🔴 Отдельный фитнес-модуль для «всёрьёз»
Серьёзная программа с учётом здоровья живёт только в отдельном разделе,
не лезет в дашборд завтрак/обед/ужин.

### E4 🔴 Сократить вывод в дашборде + настраиваемая видимость
В общем дневном обзоре — 1 строка + ссылка на полный фитнес-план, без деталей.

Подтверждено по коду (`bot_handlers/meal_schedule_v2.py:_fire()`): сейчас
каждое напоминание о приёме пищи БЕЗУСЛОВНО склеивает рецепт + блок
упражнений в одно сообщение, без возможности отключить.

**Требуется (зафиксировано владельцем 2026-06-20):**
В профиле/кабинете — явные тогглы «что показывать в дашборде/напоминаниях»:
- `show_exercises_in_meals` (вкл/выкл) — тянуть блок `format_exercises()` из
  `_fire()` в meal_schedule_v2.py по этому флагу
- Аналогично для других блоков по мере их появления (не только фитнес —
  любой будущий блок в dashboard должен иметь свой тоггл)
- Хранить в `user_profiles` рядом с остальными notify_* полями (уже есть
  `notify_personal`, `notify_meals` — паттерн уже есть, просто расширить)
- Доступно из ОБЕИХ онбордингов (см. G2 про их разброс — это и есть причина
  почему настройки нужно свести в одно место сразу)

---

## 🔍 НАЙДЕНО ПРИ ТРАССИРОВКЕ ПОЛЬЗОВАТЕЛЬСКОГО ПУТИ (2026-06-20)

Не было в исходном фидбэке, найдено при пошаговом прохождении всех веток bot.py:

### J1 ✅ ИСПРАВЛЕНО (2026-06-21) — BUG-01 рецидив: `meal_schedule_v2.py`
`_fire()` делал `aiosqlite.connect(_DB)` (алиас DB_PATH) без `timeout=30`.
Прошлый sed-фикс искал буквально `DB_PATH`, алиас пропущен. **Исправлено,**
всё репо проверено `grep` на оставшиеся `aiosqlite.connect(` без timeout — больше ни одного.

### J2 ✅ ИСПРАВЛЕНО (2026-06-21) — «Шеф на телефоне» в обход LLMFactory
`recipes.py:chef_chat()` читал Gemini-ключи напрямую из `.env`, raw urllib.
**Переведено на `LLMFactory.execute_request()`** (тот же паттерн, что в
`gemini_extractor.py`) — новая функция `_ask_llm()` в начале recipes.py. История диалога
теперь сворачивается в один prompt (LLMFactory не принимает multi-turn contents).
Смоук-тест прошёл (реальный ответ от Gemini получен). `urllib`/`random`/`re`
импорты убраны из recipes.py как неиспользуемые.
⚠️ Остались аналогичный urllib-паттерн в `modules/recipes/engine.py` и `modules/fitness/engine.py` —
это отдельный, более крупный рефактор (ISSUE-03), не тронут в этой правке намеренно.

### J3 ✅ ИСПРАВЛЕНО (2026-06-21) — Мусор в продакше
Два остаточных `print(..., flush=True)` в recipes.py убраны, заменены на `log.info()`.

### J4 🟡 Два независимых онбординга пишут в одну таблицу
`diet_picker.py` (goal/age/restrictions/activity) и `cabinet.py`
(cook_level/budget_level/excluded_foods/...) — две разные анкеты в одну таблицу
`user_profiles`, ни одна не знает про другую. Связано с G2.

---

## EPIC F — Локализация: регион + время

### F1 🔴 Доступность продуктов по регионам
`location` в user_profiles уже есть, но не передаётся в промпты рецептов/диет.
Быстрый фикс: прокинуть в существующие промпты.

### F2 🔴 Часовой пояс пользователя
`scheduler/meal_scheduler.py:13` — `AsyncIOScheduler(timezone="Europe/Moscow")` жёстко зашит.
Колонки `timezone` в user_profiles нет. Требует:
1. Добавить `timezone` (IANA-строка) в профиль, спрашивать в онбординге/настройках
2. Перевести job'ы с глобального scheduler на per-user (время приёма пищи
   хранить в UTC + конвертировать при планировании job’а) — это настоящий
   рефактор, не простая правка

---

## EPIC G — Онбординг и профиль/настройки

### G1 🟡 Опрос при старте или позже
`onboarding_done`/`onboarding_step` уже есть в схеме — часть флоу вероятно уже есть.
Нужно проверить и добавить явный выбор «Сейчас / Позже в профиле».

### G2 🟡 Все настройки в одном месте
Проверить `bot_handlers/puhlyash_settings.py` + `cabinet.py` на разброс настроек,
свести в единое меню профиля.

---

## EPIC H — Экспорт и хранение данных

### H1 🔴 Экспорт своих данных
Подтверждено — нигде не реализовано. Нужна кнопка «📥 Скачать мои данные» →
сборка JSON (профиль, диеты, рецепты, упражнения, прогресс) → отправка
файлом в Telegram.

### H2 🔴 Политика хранения — МОЯ РЕКОМЕНДАЦИЯ
Нет ни одного cron/задачи на очистку/архивацию. Предлагаю:

**Постоянно для всех (без ограничений):**
Сам объект «diet program» целиком — план, рецепты, упражнения, итоговый прогресс.
Это компактные структурированные данные, не растут в объёме опасно.

**Free/обычные пользователи:**
Гранулярные логи (diary, отметки съеденных приёмов) — 3 месяца rolling window.
После этого — автосворачивание в месячную агрегатную строку (% соблюдения,
средние калории/БЖУ, топ 5 лайков/дизлайков, точки веса) — сырые строки
удаляются.

**VIP:**
Гранулярная история хранится значительно дольше (например, 24 месяца или
бессрочно) — платный тир, объём небольшой (реально активных VIP всегда мало).

**Важно:** экспорт (H1) доступен всегда, не зависит от того, свёрнулись ли
данные или нет — это страховочный клапан, пользователь может скачать до сворачивания.
Реализация: отдельный месячный APScheduler job, похож на идею retention из
`аудит_архитектуры.md` (по аналогии с Diet Core Registry версиоированием).

---

## EPIC I — Маскоты: голос и калибровка ⚠️ ПРИОРИТЕТ

### I1 🔴 Ирисочка нигде не звучит
Маскот утверждён (TEAM_NOTES.md), но modules/irisochka/ не существует.
Сейчас mood="sweet" всё равно идёт через Пухляша (puhlyash/persona.py).
Создать `modules/irisochka/persona.py` по образцу puhlyash/persona.py,
переключить сладкое/десерты на неё.

### I2 🔴 Сарказм без границ (причина найдена)
В SYS_PUHLYASH (persona.py) и SYS_PROMPT (recipes/engine.py) нет правила «не выдумывай
детали» — отсюда шутки про ингредиенты, которых не было в диалоге. Добавить:
«Шути только про то, что реально есть в рецепте/диалоге. Никогда не
выдумывай ингредиенты для шутки. Один лёгкий комментарий на сообщение
максимум, не в каждой реплике». Полноценный бантер оставить только для
режима готовки (A3), где это контекстно ожидаемо.

---

## Предлагаемая последовательность

**Фаза 1 — быстрые и безопасные фиксы (только промпты, без схемы БД):**
Входят: E1, E2 (безопасность упражнений), I2 (сарказм), F1 (регион в промпт)

**Фаза 2 — профиль и инфраструктура (небольшие изменения схемы):**
Входят: F2 (timezone), G1/G2 (onboarding/settings), I1 (Ирисочка), E3/E4 (fitness-модуль)

**Фаза 3 — новые фичи (новые таблицы/FSM):**
Входят: A3 (режим готовки), A1/A2 (meal-prep, неделя рецептов), C1 (список покупок)

**Фаза 4 — глубокий интеллект + данные:**
Входят: B1-B4 (интеллект диеты), D1 (модерация), H1/H2 (экспорт/retention),
K1 (интеграция Диета↔Фитнес↔Рецепты — физически требует B3 и E1 готовыми,
поэтому строго после них)
````

---

## Файл: README.md

`3313 байт`

````
# Diet Platform «Пухляш»

**Версия:** 1.0.0 (MVP)  
**Среда:** Linux (VPS), Python 3.10+  
**Статус:** 🟡 Production (MVP) — активные пользователи

Telegram-бот «Пухляш» — персональный ассистент по питанию, диетам и фитнесу с характером саркастичного рыжего кота.

## 🎯 Что делает

- **🍽️ Рецепты** — генерация рецептов через LLM с учётом предпочтений, аллергий, бюджета
- **📊 Диеты** — персонализированные планы питания на неделю с анализом КБЖУ
- **💪 Фитнес** — упражнения-разминки от ленивого кота (безопасно, без приседаний)
- **🛒 Список покупок** — автоформирование из выбранных рецептов
- **⏰ Напоминания** — о приёмах пищи с рецептами и упражнениями
- **🐱 Маскот** — Пухляш (саркастичный) и Ирисочка (эмпатичная, в разработке)

## 📂 Структура

```
diet_platform/
├── README.md               # этот файл
├── MANIFEST.md             # паспорт проекта
├── TEAM_NOTES.md           # операционный лог команды
├── PRODUCT_BACKLOG.md      # продуктовые требования (9 эпиков)
├── .env.example            # пример секретов
├── main.py                 # точка входа (FastAPI + aiogram)
├── bot.py                  # Telegram-бот «Пухляш»
├── database.py             # схема БД v1
├── database_migration_v2.sql  # миграция v2
├── diet_platform.db        # SQLite БД (WAL)
├── api/                    # FastAPI эндпоинты
├── bot_handlers/           # aiogram хендлеры
├── modules/                # бизнес-логика
│   ├── recipes/            # генерация рецептов
│   ├── fitness/            # фитнес-движок
│   ├── puhlyash/           # персона маскота
│   ├── irisochka/          # персона Ирисочки (план)
│   ├── notifier/           # уведомления (aiogram Bot)
│   ├── scheduler/          # APScheduler задачи
│   └── ...
├── workers/                # фоновые задачи
├── tests/                  # тесты
└── deploy/                 # systemd unit-файлы
```

## 🚀 Быстрый старт

```bash
cd projects/diet_platform/
cp .env.example .env
# Заполни TELEGRAM_BOT_TOKEN и GEMINI_API_KEYS в .env
pip install -r requirements.txt
python main.py
```

## 🔐 Безопасность

- Секреты только в `.env` (в .gitignore)
- Все LLM-вызовы через Leviathan LLMFactory (KeyPool + CircuitBreaker)
- SQLite WAL с `timeout=30` на все коннекты
- Нет raw `shell=True`, нет `os.system`

## 📄 Лицензия

MIT / Internal use.

````

---

## Файл: TEAM_NOTES.md

`23122 байт`

````
# 📋 TEAM NOTES — Diet Platform «Пухляш»

> Файл для синхронизации между разработчиками.
> Обновляй при каждом значимом изменении.
>
> 📌 См. также `PRODUCT_BACKLOG.md` — продуктовые требования от владельца
> (рецепты, диеты, фитнес, локализация, маскоты) — 9 эпиков, фазировано.

---

## 🐱 МАСКОТЫ ПРОЕКТА

### Пухляш (основной)
- Рыжий пухлый кот с мышонком-другом
- **Характер:** саркастичный подкольщик, но заботливый
- **Зона:** питание, диеты, тренировки, расписание
- **Tone of voice:** «Ну ты и обжора... но я помогу 😏»
- Арт: см. `/assets/mascots/puhlyash_*.jpg`

### Ирисочка (в разработке)
- **Характер:** эмпатичная, жизнерадостная, добрая, мудрая советчица
- **Зона:** сладкое, десерты, читмил, утешение
- **Tone of voice:** «Ты молодец! Один кусочек не страшно 🍬»
- Статус: **персонаж утверждён, реализация не начата**
- Нужно: создать `modules/irisochka/persona.py` по образцу `modules/puhlyash/persona.py`

---

## ✅ CONFLICT-01 — ИСПРАВЛЕНО ОКОНЧАТЕЛЬНО (2026-06-30) — Ушли от Pyrogram вообще

**История вопроса:** сначала был конфликт за Pyrogram session между diet_platform
и den4ik-claude (см. историю ниже — Userbot Relay от 2026-06-19). 2026-06-30
den4ik-claude мигрировал на новый файл `leviathan_hub_bot.py` («4 modes:
AUTO/CORE/FORGE/HERALD»), который вообще не использует Pyrogram — Userbot
Relay перестал отвечать (`/opt/den4ik-claude/userbot_relay.py` остался на
диске, но никем не запускается).

**Решение владельца:** Pyrogram/userbot больше не нужен вообще.
`modules/notifier/sender.py` переписан повторно — теперь использует
**собственный aiogram Bot** diet_platform (свой `TELEGRAM_BOT_TOKEN` из `.env`),
никакой зависимости от den4ik-claude/Userbot Relay больше нет. Короткоживущий
`Bot()`-инстанс на каждую отправку (стандартная практика aiogram для одиночных
отправок из фоновых задач, не связанных с long-polling в bot.py).

**Проверено:** `send_notification()` → `True`, реальное сообщение
дошло в Telegram без участия den4ik-claude.

**Не удалено намеренно:** `userbot_relay_token` в `config.py` и `USERBOT_RELAY_TOKEN`
в `.env` оставлены на месте (безвредны, но уже нигде не используются) —
быстрый rollback возможен, если понадобится.

**Старая версия файла:** `modules/notifier/sender.py.bak` (httpx → Userbot Relay).

---

## 📜 ИСТОРИЯ: CONFLICT-01 — Userbot Relay (2026-06-19, устарело, см. выше)

**Была проблема:** `diet_platform` и `/opt/den4ik-claude/` (оба проекта владельца,
подтверждено) использовали один и тот же Pyrogram session-файл
(`/opt/telegram-agent-book/my_account.session`, SQLite). Два процесса одновременно
открыть её не могли → 100% push-уведомлений о приёмах пищи падали с `database is locked`.

**Решение — Userbot Relay.** Почему не полный мердж в один процесс:
den4ik-claude использует Pyrogram глубоко (dialogs, history, create_channel,
live-watcher `@papp.on_message`) — полное слияние увеличило бы blast radius
(баг в публичном diet-боте оказался бы в одном процессе с `systemctl stop` на все
сервисы). Вместо этого вынесли ровно один общий ресурс — саму Telegram-сессию.

**Архитектура:**
- `den4ik-claude` остаётся **единственным владельцем** Pyrogram-сессии, ничего
  в его функционале не изменилось
- Внутри его же `asyncio.gather()` в `main()` запущен мини-FastAPI на
  `127.0.0.1:8190` (новый файл `/opt/den4ik-claude/userbot_relay.py`)
- `diet_platform/modules/notifier/sender.py` полностью переписан: теперь это тонкий
  httpx-клиент, дёргающий `POST http://127.0.0.1:8190/relay/send` — без
  собственного Pyrogram Client. Сигнатура `send_notification()` не изменилась —
  вызывающий код (scheduler/meal_scheduler.py) править не пришлось
- Авторизация: заголовок `X-Relay-Token`, одинаковый с обеих сторон —
  `RELAY_TOKEN` в `den4ik-claude/bot.py` и `USERBOT_RELAY_TOKEN` в `diet_platform/.env`

**Проверено end-to-end:**
- `GET http://127.0.0.1:8190/health` → `{"status":"ok"}`
- `send_notification()` из diet_platform → `True`, сообщение реально дошло в Telegram
- Неверный `X-Relay-Token` → HTTP 403 (авторизация работает)
- `fuser /opt/telegram-agent-book/my_account.session` → ровно ОДИН PID (den4ik-claude)

**Найдено и исправлено по ходу:** `parse_mode="html"` (строкой) вызывал HTTP 502 —
Pyrogram ждёт объект `pyrogram.enums.ParseMode`, а не строку. Добавлен маппинг
в `userbot_relay.py` (`html→ParseMode.HTML`, `md→ParseMode.MARKDOWN`).

**Изменённые файлы:**
- `/opt/den4ik-claude/userbot_relay.py` (новый)
- `/opt/den4ik-claude/bot.py` (+import, +`RELAY_TOKEN`, +`run_relay_server()` в `gather()`)
- `/opt/diet_platform/modules/notifier/sender.py` (полностью переписан, бэкап сохранён)
- `/opt/diet_platform/building_blocks/config.py` (+`userbot_relay_token`)
- `/opt/diet_platform/.env`, `.env.example` (+`USERBOT_RELAY_TOKEN`)

---

## ⚠️ НАЙДЕНО ПОПУТНО, НЕ ИСПРАВЛЕНО — aiogram getUpdates конфликт (den4ik-claude)

Бот `@den4ik_claude_bot` (токен `8933899236:...`) постоянно ловит `TelegramConflictError`:
```
Telegram server says - Conflict: terminated by other getUpdates request
```
Это **не связано** с Userbot Relay выше — разные протоколы
(aiogram = Bot API getUpdates, Pyrogram = MTProto userbot, не пересекаются).

**Диагностика:**
- На этом сервере только один процесс с этим токеном (`den4ik-claude.service`)
- `getWebhookInfo` → webhook пустой, `pending_update_count: 0`
- Значит где-то **вне этого VPS** ещё один процесс держит getUpdates на
  том же токене (другой сервер, забытая screen/tmux/docker-сессия)
- Проблема была и ДО моих правок (839 попыток за ~70 минут до рестарта) —
  не моя работа

**Что проверить владельцу:** нет ли забытой копии этого бота на другом
VPS/локальной машине/забытой docker/screen/tmux-сессии. Это не блокирует
Userbot Relay (он работает через Pyrogram, не через aiogram), но ломает обычные
Telegram-команды den4ik-claude.

---

## ✅ GitHub Push — РЕШЕНО (2026-06-20)

**Была проблема:** исходный PAT для `lidenal85-blip` был мёртв (401 Bad
credentials). Два других токена, которые пробовали вместо него —
`den4ikorm1985` и `lewinthinkman-wq` — это ДРУГИЕ GitHub-аккаунты. Оба валидные,
но имеют только `pull` на `lidenal85-blip/diet_platform` (репо публичный,
поэтому `git fetch` работал даже с мёртвым токеном лиденал85-blip — это
анонимное чтение, не авторизация), а `push` всё равно даёт 403 даже с
валидным токеном. Добавить collaborator тоже не получилось этими же
токенами — `lidenal85-blip` оказался обычным пользователем (не организацией),
админ-действия над репо доступны только с валидным токеном самого `lidenal85-blip`.

**Решение:** владелец перевыпустил PAT из-под самого `lidenal85-blip`.
Проверено через `GET /user` (login совпал) и `GET /repos/.../diet_platform`
(`permissions.push: true`) перед пушем. Push прошёл, SHA на GitHub совпал с
локальным HEAD (`5a6a00c`).

**Важно на будущее:**
- При перевыпуске («Regenerate») GitHub всегда создаёт НОВУЮ строку токена —
  старое значение никогда не оживает повторным нажатием кнопки
- Рабочий токен сейчас вшит только в `git remote -v` (`.git/config`) — НЕ в коде,
  НЕ в истории коммитов (проверено `git grep` по HEAD перед пушем — чисто)
- При истечении/отзыве нового токена — входить именно в аккаунт `lidenal85-blip`
  (Settings → Developer settings → PAT), не в любой другой аккаунт на этом сервере

**Push #1 (5a6a00c):** Userbot Relay, BUG-01/02/03 фиксы, первый коммит ранее
untracked кода (bot_handlers/, api/, modules/fitness, notifier, puhlyash, reactions,
scheduler, recipes), TEAM_NOTES.md + PRODUCT_BACKLOG.md

---

### [FIXED и ПОДТВЕРЖДЕНО]
- BUG-01: `database is locked` (diet_platform.db) — `timeout=30` во все aiosqlite.connect()
  → сервис работает без рестартов (было 298 рестартов)
- BUG-02 (ROOT CAUSE): `EXTRACTION_PROMPT` содержал `{ }` из JSON-схемы → LLMFactory
  `prompt_engine.py` делал `.format(**kwargs)` и падал с `KeyError`. Промпт переписан
  без фигурных скобок
- BUG-03: Сессии зависали в `searching` — `_update_session_progress` теперь вызывается
  и в DLQ-ветке → все 7 сессий стали completed
- **CONFLICT-01** — Userbot Relay, см. выше. Уведомления снова работают
- Результат: pipeline произвёл 12 диет в diet_master (было 0)

### [Новое, не исправлено — вне этого VPS]
- aiogram getUpdates conflict у den4ik-claude — см. раздел выше

### [Открытые, не критичные]
- ISSUE-03: `urllib.request` (sync) в `recipes/engine.py`, `fitness/engine.py`, `puhlyash/persona.py`
  → блокирует event loop. ЧАСТИЧНО исправлено 2026-06-21 (J2 — chef_chat в
bot_handlers/recipes.py переведён на LLMFactory). Остались `modules/recipes/engine.py`,
`modules/fitness/engine.py`, `modules/puhlyash/persona.py` — большой рефактор, не тронуты намеренно
- ISSUE-04: Нет `__init__.py` в `search_gateway/`, `web_scraper/`, `diet_extractor/`, `diet_registry/`
- ISSUE-06: confidence_score низкий (0.15–0.35) из-за CircuitBreaker на Gemini/Groq в момент
  retry — fallback на эвристики. Не баг, но все 12 диет сейчас в pending_verification
  с низким confidence — модератору нужно вручную проверить перед публикацией
- ISSUE-07: outbox пуст — новых задач нет, ждём новых /search от пользователей
  чтобы проверить pipeline на живых данных
- J4 (из трассировки 2026-06-20): два независимых онбординга (diet_picker и cabinet)
  пишут в одну user_profiles — связано с G2 в PRODUCT_BACKLOG.md
- `modules/notifier/sender.py` (старая версия) использовал `logging.getLogger(__name__)`
  без настройки — в новой версии то же самое, не критично

---

## 🗄️ БАЗА ДАННЫХ

- Путь: `/opt/diet_platform/diet_platform.db`
- Режим: WAL (Write-Ahead Logging)
- Схема v1: `database.py`
- Схема v2 (доп. таблицы): `database_migration_v2.sql`
- **Таблицы:** search_sessions, outbox, dlq, web_snapshots, diet_drafts, diet_master,
  audit_log, user_profiles, meal_schedule, recipe_sessions, shopping_lists,
  fridge_sessions, recipes, reactions, diary_entries
- Реальные пользователи: 2 (tg_id: 7709651193, 8113236937)
- Диет в diet_master: 12 (все pending_verification, ждут модерации)

---

## 🏗️ АРХИТЕКТУРА

Краткое:
- FastAPI (port 8150) + aiogram3 бот «Пухляш» — единый процесс
- Pipeline: DuckDuckGo → httpx scraper → Gemini extractor → diet_registry
- Очередь: SQLite Outbox (статус-поллинг каждые 3с)
- LLM: Leviathan LLMFactory (14 ключей Gemini 2.5-flash, KeyPool + CircuitBreaker, fallback → Groq)
- Notifications: собственный aiogram Bot (без Pyrogram/Userbot Relay, см. CONFLICT-01 — 2026-06-30)
- Scheduler: APScheduler (timezone Moscow)

Связанные проекты на этом же сервере:
- `/opt/den4ik-claude/` — личный пульт управления всей инфраструктурой (сервисы,
  медиа-фабрика, вакансии, OWNER_ID-gated). Теперь также хостит Userbot Relay
  для diet_platform

---

## 🚀 ДЕПЛОЙ

```bash
systemctl status diet-platform den4ik-claude   # статус обоих

# ВАЖНО: обычный systemctl restart / kill --signal=SIGTERM иногда не убивает
# процесс полностью (видели: PID висел 'sleeping' после SIGTERM и системд
# считал сервис всё ещё active, новый start ничего не делал). Если обычный
# restart не помог, бей жёстко по PID (systemd сам поднимет благодаря Restart=always):
PID=$(systemctl show <service> -p MainPID --value); kill -9 $PID

# ОБЯЗАТЕЛЬНО после правки .py файлов:
find /opt/diet_platform -name '__pycache__' -exec rm -rf {} +
find /opt/den4ik-claude -name '__pycache__' -exec rm -rf {} +

journalctl -u diet-platform -f         # логи live diet_platform
tail -f /var/log/den4ik_claude.log     # логи live den4ik-claude (буферизуются, не сразу видно)
curl http://localhost:8150/health      # diet_platform healthcheck
curl http://127.0.0.1:8190/health      # Userbot Relay healthcheck
curl -X POST http://localhost:8150/api/v1/dlq/retry-all  # перезапуск DLQ
```

---

## 📅 CHANGELOG

### 2026-06-30 — Ушли от Pyrogram вообще (Claude / Leviathan Agent)
- Обнаружено: den4ik-claude мигрировал на leviathan_hub_bot.py, который не использует
  Pyrogram — Userbot Relay остался на диске, но никем не запускался. Уведомления падали
  с connection refused.
- Владелец решил: Pyrogram/userbot больше не нужен вообще — перевёл уведомления
  на собственный aiogram Bot diet_platform.
- `modules/notifier/sender.py` переписан второй раз (был httpx→Relay, стал
  прямым aiogram Bot()). Сигнатура `send_notification()` не менялась — вызывающий
  код не тронут.
- Проверено реальной отправкой: True, сообщение дошло без участия den4ik-claude.
- diet_platform теперь полностью независим от den4ik-claude для Telegram-функционала.

### 2026-06-21 — J1/J2/J3 фиксы + инцидент с den4ik-claude (Claude / Leviathan Agent)
- **Инцидент:** при рутинной проверке обнаружен `den4ik-claude` в статусе `failed`
  — явный `systemctl stop` 11 часов назад (вероятно через самого бота,
  не моя правка). `Restart=always` не сработал, т.к. стоп был осознанным, не
  крашем. Всё это время Userbot Relay был недоступен. Поднял, проверено —
  оба сервиса снова `active`.
- J1 исправлен: последний оставшийся `aiosqlite.connect()` без timeout (алиас `_DB`
  в meal_schedule_v2.py) — проверено `grep` по всему репо, больше ни одного случая
- J2 исправлен: «Шеф на телефоне» переведён с raw urllib+регекс-чтения .env на
  LLMFactory.execute_request() — смоук-тест прошёл с реальным ответом от Gemini
- J3 исправлен: убраны остаточные `print([DEBUG]...)` из recipes.py
- Зафиксировано новое требование в PRODUCT_BACKLOG.md — настраиваемая видимость
  блоков дашборда/напоминаний через профиль/кабинет (расширение E4)
- Сделана полная трассировка пользовательского пути по всему bot.py — найдены J1-J4

### 2026-06-20 — GitHub push решён (Claude / Leviathan Agent)
- Исходный токен `lidenal85-blip` был мёртв; два альтернативных токена
  (`den4ikorm1985`, `lewinthinkman-wq`) оказались чужими аккаунтами без push-доступа
- Владелец перевыпустил PAT из-под `lidenal85-blip` — push прошёл, подтверждено по SHA
- Попутно закоммичен весь ранее untracked живой код бота (впервые в git!)
- Расширен `.gitignore`: `*.bak_*`, `*.swp`
- Создан `PRODUCT_BACKLOG.md` — 9 эпиков продуктовых требований от владельца,
  фазировано на 4 фазы

### 2026-06-19, вечер — Userbot Relay (Claude / Leviathan Agent)
- Подтверждено владельцем: den4ik-claude — тоже его проект, можно изменять
- Рассмотрел полное слияние в 1 процесс — отклонён (разные bounded contexts,
  большой blast radius для публичного бота)
- Реализован **Userbot Relay**: den4ik-claude остаётся владельцем Pyrogram-сессии,
  diet_platform дёргает его через локальный HTTP (127.0.0.1:8190)
- CONFLICT-01 закрыт, проверено end-to-end и реальной отправкой
- По ходу найдена и не связанная проблема: aiogram getUpdates конфликт у den4ik-claude
  (источник вне этого VPS, предсуществовал до моих правок)

### 2026-06-19, 09:00 UTC — Повторный анализ (Claude / Leviathan Agent)
- Подтверждено: все 3 бага из предыдущей сессии исправлены и держатся 12+ часов
- Найден CONFLICT-01 — исправлен в этот же день вечером (см. выше)

### 2026-06-18 (Claude / Leviathan Agent)
- Проведён анализ проекта, зафиксированы маскоты: Пухляш + Ирисочка
- Исправлены баги: database locked, JSON/format KeyError (root cause), sessions stuck

### 2026-06-17 (Denis)
- init commit: Puhlyash diet platform — bot + FastAPI + Gemini pipeline

---

## ⚠️ ВАЖНО ДЛЯ НОВЫХ РАЗРАБОТЧИКОВ

1. **Не открывай aiosqlite.connect() без `timeout=30`** — будет database locked
2. **Не используй urllib.request в async функциях** — блокирует event loop
3. **Все LLM-вызовы** идут через `/opt/leviathan_engine/llm_factory.py`, не напрямую
4. **НИКАКИХ `{` `}` в промптах для LLMFactory** — он делает `.format(**kwargs)` внутри
5. **После правки .py файлов всегда чисти __pycache__** перед рестартом
6. **systemctl restart иногда виснет полностью** — проверяй PID и бей `kill -9` при необходимости
7. **Bot token и API keys** — только в `.env` / константах рядом с остальными секретами
8. **den4ik-claude и diet_platform — оба проекта владельца**, но разные по риску:
   den4ik-claude имеет `systemctl stop/start` над всеми сервисами — правь аккуратно
9. **Pyrogram больше не используется в diet_platform** (2026-06-30). Уведомления идут
   через собственный aiogram Bot (`modules/notifier/sender.py`). Не создавай
   зависимость от den4ik-claude/Userbot Relay для отправки сообщений снова.
10. **Маскот Пухляш** — саркастичный, но добрый. Ирисочка — мягкая и мудрая. Тон важен!
11. **GitHub push** — токен всегда должен быть из-под аккаунта `lidenal85-blip`,
    не из других аккаунтов на этом сервере — у них только `pull`. Перед pushом
    стоит сверить `permissions.push: true` через GitHub API
````

---

## Файл: api/cabinet_router.py

`8939 байт`

````
"""FastAPI router: веб-кабинет пользователя."""
import secrets
import aiosqlite
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from database import DB_PATH

router = APIRouter(prefix="/diet")

# Токен кабинета храним в памяти {токен: tg_id}
_cabinet_tokens: dict[str, str] = {}


def generate_cabinet_token(tg_id: str) -> str:
    token = secrets.token_urlsafe(20)
    _cabinet_tokens[token] = tg_id
    return token


@router.get("/cabinet", response_class=HTMLResponse)
async def cabinet_page(request: Request, token: str = ""):
    tg_id = _cabinet_tokens.get(token)
    profile = {}
    if tg_id:
        async with aiosqlite.connect(DB_PATH, timeout=30) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM user_profiles WHERE tg_id=?", (tg_id,)) as c:
                row = await c.fetchone()
            if row:
                profile = dict(row)

    html = _render_cabinet(profile, token)
    return HTMLResponse(html)


@router.post("/cabinet/save")
async def cabinet_save(request: Request):
    data = await request.json()
    token = data.get("token", "")
    tg_id = _cabinet_tokens.get(token)
    if not tg_id:
        raise HTTPException(403, "Invalid token")
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles (tg_id,cook_level,experiment_level,budget_level,"
            "max_cook_time,excluded_foods,recipe_day_time,recipe_day_enabled) "
            "VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(tg_id) DO UPDATE SET "
            "cook_level=excluded.cook_level, experiment_level=excluded.experiment_level,"
            "budget_level=excluded.budget_level, max_cook_time=excluded.max_cook_time,"
            "excluded_foods=excluded.excluded_foods, recipe_day_time=excluded.recipe_day_time,"
            "recipe_day_enabled=excluded.recipe_day_enabled",
            (tg_id,
             data.get("cook_level", "beginner"),
             data.get("experiment_level", "sometimes"),
             data.get("budget_level", "normal"),
             int(data.get("max_cook_time", 30)),
             data.get("excluded_foods", ""),
             data.get("recipe_day_time") or None,
             1 if data.get("recipe_day_enabled") else 0)
        )
        await db.commit()
    return JSONResponse({"ok": True})


def _render_cabinet(profile: dict, token: str) -> str:
    cl = profile.get("cook_level", "beginner")
    el = profile.get("experiment_level", "sometimes")
    bl = profile.get("budget_level", "normal")
    ct = profile.get("max_cook_time", 30)
    excl = profile.get("excluded_foods", "") or ""
    rdt = profile.get("recipe_day_time", "") or ""
    rde = bool(profile.get("recipe_day_enabled", 0))

    def sel(val, cur): return 'selected' if val == cur else ''
    def chk(v): return 'checked' if v else ''

    return f"""<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Пухляш — Мой кабинет</title>
<style>
  :root {{
    --bg: #1a1a2e; --card: #16213e; --accent: #e94560;
    --text: #eee; --sub: #aaa; --border: #2a2a4a;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: var(--bg); color: var(--text); font-family: -apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif; min-height: 100vh; padding: 20px; }}
  .card {{ background: var(--card); border-radius: 16px; padding: 24px; max-width: 480px; margin: 0 auto; }}
  h1 {{ font-size: 1.4rem; margin-bottom: 4px; }}
  .sub {{ color: var(--sub); font-size: .85rem; margin-bottom: 24px; }}
  .section {{ margin-bottom: 20px; }}
  label {{ display: block; color: var(--sub); font-size: .8rem; margin-bottom: 8px; text-transform: uppercase; letter-spacing: .05em; }}
  select, input[type=text], input[type=time] {{
    width: 100%; background: var(--bg); border: 1px solid var(--border);
    border-radius: 10px; padding: 12px 14px; color: var(--text); font-size: 1rem;
    outline: none;
  }}
  select:focus, input:focus {{ border-color: var(--accent); }}
  .toggle-row {{ display: flex; align-items: center; gap: 12px; }}
  .toggle {{ position: relative; width: 48px; height: 26px; }}
  .toggle input {{ opacity: 0; width: 0; height: 0; }}
  .slider {{ position: absolute; inset: 0; background: #333; border-radius: 26px; cursor: pointer; transition: .3s; }}
  .slider:before {{ content: ''; position: absolute; width: 20px; height: 20px; left: 3px; bottom: 3px; background: white; border-radius: 50%; transition: .3s; }}
  input:checked + .slider {{ background: var(--accent); }}
  input:checked + .slider:before {{ transform: translateX(22px); }}
  .btn {{ width: 100%; background: var(--accent); color: white; border: none; border-radius: 12px; padding: 14px; font-size: 1rem; font-weight: 600; cursor: pointer; margin-top: 8px; transition: opacity .2s; }}
  .btn:hover {{ opacity: .85; }}
  .toast {{ display: none; background: #27ae60; color: white; border-radius: 10px; padding: 12px 16px; text-align: center; margin-top: 12px; }}
  .toast.show {{ display: block; }}
</style>
</head>
<body>
<div class="card">
  <h1>👨‍🍳 Мой кабинет</h1>
  <p class="sub">Настройка рецептов под тебя</p>

  <div class="section">
    <label>🍳 Кулинарный уровень</label>
    <select id="cook_level">
      <option value="beginner" {sel('beginner',cl)}>🥚 Новичок — яичница, пельмени, макароны</option>
      <option value="amateur" {sel('amateur',cl)}>🍳 Любитель — омлет, суп, паста болоньезе</option>
      <option value="cook" {sel('cook',cl)}>👨‍🍳 Готовлю с удовольствием</option>
      <option value="expert" {sel('expert',cl)}>🌟 Эксперт — равиоли, ризотто</option>
    </select>
  </div>

  <div class="section">
    <label>🚀 Желание экспериментировать</label>
    <select id="experiment_level">
      <option value="classic" {sel('classic',el)}>🔒 Только проверенное</option>
      <option value="sometimes" {sel('sometimes',el)}>⚡ Иногда что-то новое</option>
      <option value="explorer" {sel('explorer',el)}>🚀 Люблю пробовать</option>
    </select>
  </div>

  <div class="section">
    <label>💰 Бюджет</label>
    <select id="budget_level">
      <option value="student" {sel('student',bl)}>🎓 Студенческий — без пармезана</option>
      <option value="normal" {sel('normal',bl)}>💰 Обычный</option>
      <option value="free" {sel('free',bl)}>💳 Не считаю</option>
    </select>
  </div>

  <div class="section">
    <label>⏱ Время на готовку</label>
    <select id="max_cook_time">
      <option value="15" {sel('15',str(ct))}>15 минут</option>
      <option value="30" {sel('30',str(ct))}>30 минут</option>
      <option value="60" {sel('60',str(ct))}>Сколько надо</option>
    </select>
  </div>

  <div class="section">
    <label>🚫 Исключения (через запятую)</label>
    <input type="text" id="excluded_foods" value="{excl}" placeholder="грибы, морепродукты...">
  </div>

  <div class="section">
    <label>🍝 Рецепт дня</label>
    <div class="toggle-row" style="margin-bottom:12px">
      <label class="toggle">
        <input type="checkbox" id="recipe_day_enabled" {chk(rde)}>
        <span class="slider"></span>
      </label>
      <span>Отправлять рецепт в телеграм</span>
    </div>
    <input type="time" id="recipe_day_time" value="{rdt}">
  </div>

  <button class="btn" onclick="save()">&#x2705; Сохранить</button>
  <div class="toast" id="toast">✅ Сохранено!</div>
</div>

<script>
async function save() {{
  const data = {{
    token: '{token}',
    cook_level: document.getElementById('cook_level').value,
    experiment_level: document.getElementById('experiment_level').value,
    budget_level: document.getElementById('budget_level').value,
    max_cook_time: parseInt(document.getElementById('max_cook_time').value),
    excluded_foods: document.getElementById('excluded_foods').value,
    recipe_day_time: document.getElementById('recipe_day_time').value || null,
    recipe_day_enabled: document.getElementById('recipe_day_enabled').checked,
  }};
  const r = await fetch('/diet/cabinet/save', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify(data)}});
  const j = await r.json();
  if (j.ok) {{
    const t = document.getElementById('toast');
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 3000);
  }}
}}
</script>
</body>
</html>"""
````

---

## Файл: api/miniapp_router.py

`13982 байт`

````
"""Telegram Mini App — Diet Platform."""
import aiosqlite
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse
from database import DB_PATH

router = APIRouter(prefix="/diet")


@router.get("/app", response_class=HTMLResponse)
async def mini_app(request: Request):
    return HTMLResponse(MINIAPP_HTML)


@router.get("/app/profile")
async def get_profile(tg_id: str = ""):
    if not tg_id:
        return JSONResponse({"exists": False})
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM user_profiles WHERE tg_id=?", (tg_id,)) as c:
            row = await c.fetchone()
    if not row:
        return JSONResponse({"exists": False})
    d = dict(row)
    d["exists"] = True
    return JSONResponse(d)


@router.post("/app/profile")
async def save_profile(request: Request):
    data = await request.json()
    tg_id = str(data.get("tg_id", ""))
    if not tg_id:
        return JSONResponse({"ok": False, "error": "no tg_id"}, status_code=400)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles "
            "(tg_id,cook_level,experiment_level,budget_level,max_cook_time,"
            "excluded_foods,recipe_day_time,recipe_day_enabled,"
            "notify_personal,notify_meals,notify_recipe_day) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tg_id) DO UPDATE SET "
            "cook_level=excluded.cook_level,experiment_level=excluded.experiment_level,"
            "budget_level=excluded.budget_level,max_cook_time=excluded.max_cook_time,"
            "excluded_foods=excluded.excluded_foods,recipe_day_time=excluded.recipe_day_time,"
            "recipe_day_enabled=excluded.recipe_day_enabled,"
            "notify_personal=excluded.notify_personal,"
            "notify_meals=excluded.notify_meals,"
            "notify_recipe_day=excluded.notify_recipe_day",
            (tg_id,
             data.get("cook_level", "beginner"),
             data.get("experiment_level", "sometimes"),
             data.get("budget_level", "normal"),
             int(data.get("max_cook_time", 30)),
             data.get("excluded_foods", ""),
             data.get("recipe_day_time") or None,
             1 if data.get("recipe_day_enabled") else 0,
             1 if data.get("notify_personal", True) else 0,
             1 if data.get("notify_meals", True) else 0,
             1 if data.get("notify_recipe_day", True) else 0)
        )
        await db.commit()
    return JSONResponse({"ok": True})


MINIAPP_HTML = """\
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>\u041f\u0443\u0445\u043b\u044f\u0448</title>
<script src="https://telegram.org/js/telegram-web-app.js"></script>
<style>
:root{
  --bg:var(--tg-theme-bg-color,#1a1a2e);
  --card:var(--tg-theme-secondary-bg-color,#16213e);
  --text:var(--tg-theme-text-color,#eee);
  --hint:var(--tg-theme-hint-color,#999);
  --accent:var(--tg-theme-button-color,#e94560);
  --btn-txt:var(--tg-theme-button-text-color,#fff);
  --sep:rgba(255,255,255,.07);
}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
body{background:var(--bg);color:var(--text);font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;padding:12px 14px 80px;min-height:100vh}
.hdr{text-align:center;padding:14px 0 18px}
.hdr h1{font-size:1.25rem}
.hdr p{color:var(--hint);font-size:.82rem;margin-top:3px}
.tabs{display:flex;gap:6px;margin-bottom:14px}
.tab{flex:1;padding:9px 4px;border:1px solid var(--sep);border-radius:10px;background:transparent;color:var(--hint);font-size:.82rem;cursor:pointer;transition:.2s;font-weight:500}
.tab.on{background:var(--accent);color:var(--btn-txt);border-color:var(--accent)}
.pg{display:none}.pg.on{display:block}
.card{background:var(--card);border-radius:14px;padding:4px 14px;margin-bottom:10px}
.row{display:flex;align-items:center;justify-content:space-between;padding:13px 0;border-bottom:1px solid var(--sep)}
.row:last-child{border-bottom:none}
.rl{font-size:.95rem}
.rs{font-size:.75rem;color:var(--hint);margin-top:2px}
select{background:transparent;border:none;color:var(--accent);font-size:.92rem;cursor:pointer;-webkit-appearance:none;outline:none;text-align:right;max-width:140px}
input[type=text]{background:transparent;border:none;color:var(--text);font-size:.92rem;outline:none;width:100%;padding:4px 0}
input[type=time]{background:transparent;border:none;color:var(--accent);font-size:.92rem;outline:none;color-scheme:dark}
.tog{position:relative;width:46px;height:26px;flex-shrink:0}
.tog input{opacity:0;width:0;height:0}
.sl{position:absolute;inset:0;background:rgba(255,255,255,.15);border-radius:26px;cursor:pointer;transition:.25s}
.sl:before{content:'';position:absolute;width:20px;height:20px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.25s}
input:checked+.sl{background:var(--accent)}
input:checked+.sl:before{transform:translateX(20px)}
.save-bar{position:fixed;bottom:0;left:0;right:0;padding:10px 14px;background:var(--bg);border-top:1px solid var(--sep)}
.save-btn{width:100%;background:var(--accent);color:var(--btn-txt);border:none;border-radius:12px;padding:13px;font-size:1rem;font-weight:600;cursor:pointer;transition:opacity .15s}
.save-btn:active{opacity:.75}
.toast{position:fixed;top:20px;left:50%;transform:translateX(-50%);background:#27ae60;color:#fff;border-radius:10px;padding:10px 22px;font-size:.9rem;opacity:0;transition:opacity .3s;pointer-events:none;z-index:99}
.toast.on{opacity:1}
.lbl{font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;color:var(--hint);padding:14px 0 6px}
</style>
</head>
<body>
<div class="hdr">
  <h1>\U0001f35d \u041f\u0443\u0445\u043b\u044f\u0448</h1>
  <p>\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0430 \u043f\u043e\u0434 \u0442\u0435\u0431\u044f</p>
</div>

<div class="tabs">
  <button class="tab on" onclick="tab('s',this)">\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438</button>
  <button class="tab" onclick="tab('n',this)">\u0423\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f</button>
</div>

<div id="pg-s" class="pg on">
  <div class="card">
    <div class="lbl">\U0001f373 \u0423\u0440\u043e\u0432\u0435\u043d\u044c \u043a\u0443\u043b\u0438\u043d\u0430\u0440\u0438\u0438</div>
    <div class="row">
      <div><div class="rl">\u041a\u0442\u043e \u044f \u043d\u0430 \u043a\u0443\u0445\u043d\u0435</div>
      <div class="rs">\u0421\u043b\u043e\u0436\u043d\u043e\u0441\u0442\u044c \u0440\u0435\u0446\u0435\u043f\u0442\u043e\u0432</div></div>
      <select id="cook_level">
        <option value="beginner">\U0001f95a \u041d\u043e\u0432\u0438\u0447\u043e\u043a</option>
        <option value="amateur">\U0001f373 \u041b\u044e\u0431\u0438\u0442\u0435\u043b\u044c</option>
        <option value="cook">\U0001f468\u200d\U0001f373 \u0413\u043e\u0442\u043e\u0432\u043b\u044e</option>
        <option value="expert">\U0001f31f \u042d\u043a\u0441\u043f\u0435\u0440\u0442</option>
      </select>
    </div>
    <div class="row">
      <div><div class="rl">\u042d\u043a\u0441\u043f\u0435\u0440\u0438\u043c\u0435\u043d\u0442\u044b</div>
      <div class="rs">\u0416\u0435\u043b\u0430\u043d\u0438\u0435 \u043f\u0440\u043e\u0431\u043e\u0432\u0430\u0442\u044c \u043d\u043e\u0432\u043e\u0435</div></div>
      <select id="experiment_level">
        <option value="classic">\U0001f512 \u041f\u0440\u043e\u0432\u0435\u0440\u0435\u043d\u043d\u043e\u0435</option>
        <option value="sometimes">\u26a1 \u0418\u043d\u043e\u0433\u0434\u0430</option>
        <option value="explorer">\U0001f680 \u041b\u044e\u0431\u043b\u044e \u043f\u0440\u043e\u0431\u043e\u0432\u0430\u0442\u044c</option>
      </select>
    </div>
    <div class="row">
      <div><div class="rl">\u0411\u044e\u0434\u0436\u0435\u0442</div>
      <div class="rs">\u0426\u0435\u043d\u0430 \u0438\u043d\u0433\u0440\u0435\u0434\u0438\u0435\u043d\u0442\u043e\u0432</div></div>
      <select id="budget_level">
        <option value="student">\U0001f393 \u0421\u0442\u0443\u0434\u0435\u043d\u0442</option>
        <option value="normal">\U0001f4b0 \u041e\u0431\u044b\u0447\u043d\u044b\u0439</option>
        <option value="free">\U0001f4b3 \u041d\u0435 \u0441\u0447\u0438\u0442\u0430\u044e</option>
      </select>
    </div>
    <div class="row">
      <div><div class="rl">\u0412\u0440\u0435\u043c\u044f \u043d\u0430 \u0433\u043e\u0442\u043e\u0432\u043a\u0443</div>
      <div class="rs">\u041c\u0430\u043a\u0441\u0438\u043c\u0430\u043b\u044c\u043d\u043e</div></div>
      <select id="max_cook_time">
        <option value="15">15 \u043c\u0438\u043d</option>
        <option value="30">30 \u043c\u0438\u043d</option>
        <option value="60">\u0411\u0435\u0437 \u043e\u0433\u0440\u0430\u043d\u0438\u0447</option>
      </select>
    </div>
  </div>
  <div class="card">
    <div class="lbl">\U0001f6ab \u0418\u0441\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u044f</div>
    <div class="row">
      <input id="excluded" type="text" placeholder="\u0433\u0440\u0438\u0431\u044b, \u043c\u043e\u0440\u0435\u043f\u0440\u043e\u0434\u0443\u043a\u0442\u044b...">
    </div>
  </div>
</div>

<div id="pg-n" class="pg">
  <div class="card">
    <div class="lbl">\U0001f514 \u041f\u0443\u0448 \u0432 \u043b\u0438\u0447\u043a\u0443</div>
    <div class="row">
      <div><div class="rl">\u0412\u0441\u0435 \u0443\u0432\u0435\u0434\u043e\u043c\u043b\u0435\u043d\u0438\u044f</div>
      <div class="rs">\u041c\u0430\u0441\u0442\u0435\u0440-\u0432\u044b\u043a\u043b\u044e\u0447\u0430\u0442\u0435\u043b\u044c</div></div>
      <label class="tog"><input type="checkbox" id="notify_personal" checked><span class="sl"></span></label>
    </div>
    <div class="row">
      <div><div class="rl">\U0001f37d \u041f\u0440\u0438\u0451\u043c \u043f\u0438\u0449\u0438</div>
      <div class="rs">\u0420\u0435\u0446\u0435\u043f\u0442 + \u0443\u043f\u0440\u0430\u0436\u043d\u0435\u043d\u0438\u044f \u043f\u0435\u0440\u0435\u0434 \u0435\u0434\u043e\u0439</div></div>
      <label class="tog"><input type="checkbox" id="notify_meals" checked><span class="sl"></span></label>
    </div>
    <div class="row">
      <div><div class="rl">\U0001f35d \u0420\u0435\u0446\u0435\u043f\u0442 \u0434\u043d\u044f</div>
      <div class="rs">\u0415\u0436\u0435\u0434\u043d\u0435\u0432\u043d\u044b\u0439 \u043e\u0442 \u041f\u0443\u0445\u043b\u044f\u0448\u0430</div></div>
      <label class="tog"><input type="checkbox" id="notify_recipe_day" checked><span class="sl"></span></label>
    </div>
  </div>
  <div class="card">
    <div class="lbl">\u23f0 \u0412\u0440\u0435\u043c\u044f \u0440\u0435\u0446\u0435\u043f\u0442\u0430 \u0434\u043d\u044f</div>
    <div class="row">
      <div class="rl">\u041a\u043e\u0433\u0434\u0430 \u043f\u0440\u0438\u0441\u044b\u043b\u0430\u0442\u044c</div>
      <input type="time" id="recipe_day_time" value="10:00">
    </div>
  </div>
</div>

<div class="save-bar">
  <button class="save-btn" onclick="save()">\u2705 \u0421\u043e\u0445\u0440\u0430\u043d\u0438\u0442\u044c</button>
</div>
<div class="toast" id="toast">\u2705 \u0421\u043e\u0445\u0440\u0430\u043d\u0435\u043d\u043e!</div>

<script>
const tg = window.Telegram?.WebApp;
if(tg){ tg.ready(); tg.expand(); }

// tg_id: from initDataUnsafe OR URL param
const urlP = new URLSearchParams(location.search);
const tgId = tg?.initDataUnsafe?.user?.id?.toString() || urlP.get('uid') || '';

// Show form immediately with defaults, then load profile async
async function loadProfile(){
  if(!tgId) return;
  try{
    const r = await fetch('/diet/app/profile?tg_id='+tgId);
    const d = await r.json();
    if(!d.exists) return;
    const s=(id,v)=>{const e=document.getElementById(id);if(e)e.value=v||''};
    const c=(id,v)=>{const e=document.getElementById(id);if(e)e.checked=v!==0&&v!==false&&v!==null};
    s('cook_level',d.cook_level);
    s('experiment_level',d.experiment_level);
    s('budget_level',d.budget_level);
    s('max_cook_time',d.max_cook_time);
    s('excluded',d.excluded_foods);
    s('recipe_day_time',d.recipe_day_time);
    c('notify_personal',d.notify_personal??1);
    c('notify_meals',d.notify_meals??1);
    c('notify_recipe_day',d.notify_recipe_day??1);
  }catch(e){console.warn('profile load:',e);}
}
loadProfile();

async function save(){
  const g=id=>document.getElementById(id);
  const data={
    tg_id:tgId,
    cook_level:g('cook_level').value,
    experiment_level:g('experiment_level').value,
    budget_level:g('budget_level').value,
    max_cook_time:parseInt(g('max_cook_time').value),
    excluded_foods:g('excluded').value,
    recipe_day_time:g('recipe_day_time').value||null,
    recipe_day_enabled:g('notify_recipe_day').checked,
    notify_personal:g('notify_personal').checked,
    notify_meals:g('notify_meals').checked,
    notify_recipe_day:g('notify_recipe_day').checked,
  };
  try{
    const r=await fetch('/diet/app/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const j=await r.json();
    if(j.ok){
      tg?.HapticFeedback?.notificationOccurred('success');
      const t=document.getElementById('toast');
      t.classList.add('on');
      setTimeout(()=>{t.classList.remove('on');setTimeout(()=>tg?.close(),300);},1000);
    }
  }catch(e){alert('\u041e\u0448\u0438\u0431\u043a\u0430: '+e);}
}

function tab(name,el){
  document.querySelectorAll('.pg').forEach(p=>p.classList.remove('on'));
  document.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));
  document.getElementById('pg-'+name).classList.add('on');
  el.classList.add('on');
  tg?.HapticFeedback?.selectionChanged();
}

document.querySelectorAll('input[type=checkbox]').forEach(el=>{
  el.addEventListener('change',()=>tg?.HapticFeedback?.impactOccurred('light'));
});
</script>
</body>
</html>"""
````

---

## Файл: bot.py

`17703 байт`

````
"""Telegram Bot — Delivery Layer «Пухляш» (aiogram3).

Постоянная клавиатура (ReplyKeyboard) + полный набор команд.
"""
import asyncio
from typing import Optional
import aiosqlite

from aiogram import Bot, Dispatcher, Router, F
from aiogram.filters import CommandStart, Command
from aiogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton,
    CallbackQuery, ReplyKeyboardMarkup, KeyboardButton,
    ReplyKeyboardRemove, WebAppInfo,
)
from aiogram.utils.keyboard import InlineKeyboardBuilder

from building_blocks.config import get_settings
from building_blocks.contracts import new_trace_id
from building_blocks.logger import get_logger, set_trace_context
from database import DB_PATH
from modules.search_gateway.internal.searcher import initiate_search
from modules.diet_registry.infrastructure.repository import (
    get_diet_by_id, search_diets, verify_diet
)

log = get_logger(__name__)
cfg = get_settings()

router = Router()

# ── Постоянная нижняя клавиатура ───────────────────────────

MAIN_KEYBOARD = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🎯 Подобрать диету"), KeyboardButton(text="👤 Кабинет")],
        [KeyboardButton(text="🍝 Рецепт от Пухляша"), KeyboardButton(text="👨‍🍳 Рецепты")],
        [KeyboardButton(text="🧊 Холодильник"), KeyboardButton(text="💰 По бюджету")],
        [KeyboardButton(text="👨‍🍳 Шеф на телефоне"), KeyboardButton(text="⏰ Расписание")],
        [KeyboardButton(text="ℹ️ Помощь")],
    ],
    resize_keyboard=True,
    persistent=True,
)


def _main_kb() -> ReplyKeyboardMarkup:
    return MAIN_KEYBOARD


# ── /start ───────────────────────────────────────────────

@router.message(CommandStart())
async def cmd_start(message: Message):
    webapp_kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="📱 Открыть кабинет",
            web_app=WebAppInfo(url=f"https://leviathanstory.ru/diet/app?uid={message.from_user.id}")
        )
    ]])
    await message.answer(
        "🍝 <b>Пухляш</b> — свой парень, накормит вкусно 😋\n\n"
        "🎯 <b>Что умею:</b>\n"
        "• Подберу диету под тебя\n"
        "• Предложу рецепты по твоему уровню\n"
        "• Напомню когда есть\n"
        "• Пришлю рецепт дня в личку\n\n"
        "⬇️ Нажми что хочешь или настрой профиль:",
        parse_mode="HTML",
        reply_markup=_main_kb(),
    )
    await message.answer(
        "📱 Настрой профиль в кабинете:",
        reply_markup=webapp_kb
    )
# ── /help ──────────────────────────────────────────────

@router.message(Command("help"))
@router.message(F.text == "ℹ️ Помощь")
async def cmd_help(message: Message):
    await message.answer(
        "🔬 <b>Diet Platform — справка</b>\n\n"
        "Ищу диеты из интернета, извлекаю структуру, валидирую.\n\n"
        "<b>Поиск:</b>\n"
        "🔍 /search &lt;запрос&gt; — найти диету по ключевому слову\n\n"
        "<b>Просмотр:</b>\n"
        "🥗 /diets [&lt;запрос&gt;] — верифицированные диеты\n"
        "⏳ /pending — диеты на модерации\n"
        "🔍 /status &lt;id&gt; — статус запроса\n\n"
        "<b>Администрирование:</b>\n"
        "🚨 /dlq — Dead Letter Queue (ошибки)\n"
        "❤️ /health — здоровье сервиса",
        parse_mode="HTML",
        reply_markup=_main_kb(),
    )


# ── /health ────────────────────────────────────────────

@router.message(Command("health"))
async def cmd_health(message: Message):
    import aiohttp
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:8150/health", timeout=aiohttp.ClientTimeout(total=3)) as r:
                data = await r.json()
        await message.answer(
            f"❤️ <b>Сервис работает</b>\n"
            f"version: {data.get('version', '?')}\n"
            f"status: {data.get('status', '?')}",
            parse_mode="HTML",
        )
    except Exception as e:
        await message.answer(f"❌ Сервис недоступен: {e}", reply_markup=_main_kb())


# ── /search ──────────────────────────────────────────

@router.message(Command("search"))
@router.message(F.text == "🔍 Найти диету")
async def cmd_search(message: Message):
    parts = message.text.split(maxsplit=1) if message.text else []
    # Кнопка — просим ввести запрос
    if len(parts) < 2 or parts[0] == "🔍 Найти диету":
        await message.answer(
            "🔍 Напиши запрос через команду:\n"
            "<code>/search кето диета при диабете</code>\n\n"
            "Или просто напиши запрос следующим сообщением.",
            parse_mode="HTML",
        )
        return

    query = parts[1].strip()[:300]
    user_id = str(message.from_user.id)
    trace_id = new_trace_id()
    set_trace_context(trace_id)

    msg = await message.answer(f"🔍 Ищу: <b>{query}</b>\n\n…", parse_mode="HTML", reply_markup=_main_kb())

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        session_id = await initiate_search(db, query, user_id)

    await msg.edit_text(
        f"🔍 Запрос запущен!\n"
        f"🆔 <code>{session_id}</code>\n\n"
        f"Проверь статус: /status {session_id[:8]}…\n"
        f"Или смотри диеты: /diets",
        parse_mode="HTML",
    )


# ── Текстовый ввод после кнопки "Найти диету" ───────────────

_awaiting_search: set[int] = set()   # user_id кто нажал кнопку


@router.message(F.text == "🔍 Найти диету")
async def btn_search_prompt(message: Message):
    _awaiting_search.add(message.from_user.id)
    await message.answer(
        "🔍 Напиши что ищем, например:\n"
        "<code>кето диета при диабете</code>",
        parse_mode="HTML",
    )


@router.message(F.func(lambda m: m.from_user.id in _awaiting_search))
async def handle_freetext_search(message: Message):
    if not message.text or len(message.text.strip()) < 2:
        await message.answer("Слишком короткий запрос")
        return
    _awaiting_search.discard(message.from_user.id)

    query = message.text.strip()[:300]
    user_id = str(message.from_user.id)
    trace_id = new_trace_id()
    set_trace_context(trace_id)

    msg = await message.answer(f"🔍 Ищу: <b>{query}</b>\n\n…", parse_mode="HTML", reply_markup=_main_kb())

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        session_id = await initiate_search(db, query, user_id)

    await msg.edit_text(
        f"🔍 Запрос запущен!\n"
        f"🆔 <code>{session_id}</code>\n\n"
        f"Проверь статус: /status {session_id[:8]}…",
        parse_mode="HTML",
    )


# ── /status ──────────────────────────────────────────

@router.message(Command("status"))
async def cmd_status(message: Message):
    parts = message.text.split(maxsplit=1)
    if len(parts) < 2:
        await message.answer("❌ Укажи session_id: /status &lt;id&gt;", parse_mode="HTML", reply_markup=_main_kb())
        return

    session_id_part = parts[1].strip()
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM search_sessions WHERE id LIKE ?",
            (session_id_part + "%",)
        ) as cur:
            row = await cur.fetchone()

    if not row:
        await message.answer("❌ Сессия не найдена")
        return

    status_emoji = {
        "completed": "✅", "failed": "❌", "searching": "🔍",
        "scraping": "🌐", "extracting": "🧠",
    }.get(row["status"], "⏳")

    await message.answer(
        f"{status_emoji} <b>Статус сессии</b>\n"
        f"📝 Запрос: {row['query_text']}\n"
        f"🟡 Статус: {row['status']}\n"
        f"🕒 {row['created_at']}",
        parse_mode="HTML",
    )


# ── /diets ───────────────────────────────────────────

@router.message(Command("diets"))
@router.message(F.text == "🥗 Мои диеты")
async def cmd_diets(message: Message):
    parts = message.text.split(maxsplit=1) if message.text else []
    query = ""
    if len(parts) > 1 and parts[0].startswith("/"):
        query = parts[1].strip()

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        diets = await search_diets(db, query=query, status="approved", limit=8)

    if not diets:
        async with aiosqlite.connect(DB_PATH, timeout=30) as db:
            db.row_factory = aiosqlite.Row
            diets = await search_diets(db, query=query,
                                       status="pending_verification", limit=8)
        if not diets:
            await message.answer(
                "💭 Диет пока нет.\n"
                "Используй /search для поиска."
            )
            return

    kb = InlineKeyboardBuilder()
    for d in diets:
        name = d["diet_name"][:38]
        score = d["confidence_score"]
        status_icon = "✅" if d["status"] == "approved" else "⏳"
        kb.button(
            text=f"{status_icon} {name} ({score:.0%})",
            callback_data=f"diet:{d['id']}"
        )
    kb.adjust(1)

    await message.answer(
        f"📊 Найдено {len(diets)} диет:\n"
        f"(выбери для подробностей)",
        reply_markup=kb.as_markup(),
        parse_mode="HTML",
    )


# ── /pending ────────────────────────────────────────

@router.message(Command("pending"))
@router.message(F.text == "⏳ Ожидают оценки")
async def cmd_pending(message: Message):
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        diets = await search_diets(db, status="pending_verification", limit=10)

    if not diets:
        await message.answer("✅ Очередь модерации пуста")
        return

    kb = InlineKeyboardBuilder()
    for d in diets:
        name = d["diet_name"][:35]
        score = d["confidence_score"]
        kb.button(
            text=f"⏳ {name} ({score:.0%})",
            callback_data=f"pending_diet:{d['id']}"
        )
    kb.adjust(1)

    await message.answer(
        f"⏳ <b>На модерации: {len(diets)}</b>\n"
        f"Выбери диету для оценки:",
        reply_markup=kb.as_markup(),
        parse_mode="HTML",
    )


# ── /dlq ─────────────────────────────────────────────

@router.message(Command("dlq"))
@router.message(F.text == "🚨 Ошибки (DLQ)")
async def cmd_dlq(message: Message):
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM dlq ORDER BY failed_at DESC LIMIT 10"
        ) as cur:
            rows = await cur.fetchall()

    if not rows:
        await message.answer("✅ DLQ пуста — ошибок нет")
        return

    text = f"🚨 <b>Dead Letter Queue ({len(rows)} записей)</b>\n\n"
    for r in rows[:5]:
        err = (r["error_reason"] or "")[:80]
        text += (
            f"• <code>{r['task_id'][:16]}</code>\n"
            f"  Ошибка: {err}\n"
            f"  Время: {r['failed_at']}\n\n"
        )

    await message.answer(text[:4000], parse_mode="HTML", reply_markup=_main_kb())


# ── Деталь диеты (callback) ────────────────────────────

async def _send_diet_detail(callback: CallbackQuery, diet_id: str, with_moderation: bool = False):
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        diet = await get_diet_by_id(db, diet_id)

    if not diet:
        await callback.answer("❌ Не найдено", show_alert=True)
        return

    allowed = diet.get("allowed_foods", [])[:10]
    forbidden = diet.get("forbidden_foods", [])[:5]
    contraind = diet.get("contraindications", [])[:5]

    text = (
        f"🥗 <b>{diet['diet_name']}</b>\n"
        f"⭐ Уверенность: {diet['confidence_score']:.0%}\n"
        f"🟢 Статус: {diet['status']}\n\n"
    )
    if allowed:
        text += "✅ <b>Разрешено:</b>\n" + "\n".join(f"  • {f}" for f in allowed) + "\n\n"
    if forbidden:
        text += "❌ <b>Запрещено:</b>\n" + "\n".join(f"  • {f}" for f in forbidden) + "\n\n"
    if contraind:
        text += "⚠️ <b>Противопоказания:</b>\n" + "\n".join(f"  • {c}" for c in contraind)
    if diet.get("source_url"):
        text += f"\n\n🔗 <a href='{diet['source_url']}'>Источник</a>"

    markup = None
    if with_moderation and diet["status"] == "pending_verification":
        kb = InlineKeyboardBuilder()
        kb.button(text="✅ Одобрить",  callback_data=f"verify:approve:{diet_id}")
        kb.button(text="❌ Отклонить", callback_data=f"verify:reject:{diet_id}")
        kb.adjust(2)
        markup = kb.as_markup()

    await callback.message.answer(text[:4000], parse_mode="HTML", reply_markup=markup)
    await callback.answer()


@router.callback_query(F.data.startswith("diet:"))
async def diet_detail(callback: CallbackQuery):
    diet_id = callback.data.split(":", 1)[1]
    await _send_diet_detail(callback, diet_id, with_moderation=False)


@router.callback_query(F.data.startswith("pending_diet:"))
async def pending_diet_detail(callback: CallbackQuery):
    diet_id = callback.data.split(":", 1)[1]
    await _send_diet_detail(callback, diet_id, with_moderation=True)


# ── verify callback ──────────────────────────────────────

@router.callback_query(F.data.startswith("verify:"))
async def verify_callback(callback: CallbackQuery):
    _, action, diet_id = callback.data.split(":", 2)
    approved = action == "approve"
    trace_id = new_trace_id()

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        ok = await verify_diet(db, diet_id, approved, "moderator", trace_id)

    if ok:
        icon = "✅" if approved else "❌"
        label = "Одобрено" if approved else "Отклонено"
        await callback.answer(f"{icon} {label}", show_alert=True)
        await callback.message.edit_reply_markup(reply_markup=None)
    else:
        await callback.answer("❌ Ошибка обновления", show_alert=True)


# ── запуск ───────────────────────────────────────────

async def start_bot():
    from bot_handlers.recipes import router as recipes_router
    from bot_handlers.schedule import router as schedule_router
    from bot_handlers.diet_picker import router as picker_router
    from bot_handlers.reactions import router as reactions_router
    from bot_handlers.meal_schedule_v2 import router as meal_v2_router
    from bot_handlers.cabinet import router as cabinet_router
    from bot_handlers.puhlyash_settings import router as puhlyash_router
    from aiogram.fsm.storage.memory import MemoryStorage
    bot = Bot(token=cfg.telegram_bot_token)
    dp = Dispatcher(storage=MemoryStorage())
    dp.include_router(reactions_router)  # callbacks: лайки, мастер
    dp.include_router(puhlyash_router)   # настройка Пухляша + тест
    dp.include_router(meal_v2_router)    # расписание v2
    dp.include_router(cabinet_router)    # FSM кабинета
    dp.include_router(picker_router)     # FSM подбора диеты
    dp.include_router(recipes_router)    # FSM рецептов
    dp.include_router(schedule_router)   # старый schedule (fallback)
    dp.include_router(router)            # общие хендлеры
    log.info("🥬 Telegram bot (Пухляш) starting...")
    await dp.start_polling(bot, allowed_updates=["message", "callback_query"], polling_timeout=20)

````

---

## Файл: bot_handlers/cabinet.py

`12225 байт`

````
"""Bot handler: Личный кабинет пользователя."""
import aiosqlite
from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from building_blocks.logger import get_logger
from database import DB_PATH

log = get_logger(__name__)
router = Router()

LEVELS = {
    "🥚 Новичок": "beginner",
    "🍳 Любитель": "amateur",
    "👨‍🍳 Готовлю с удовольствием": "cook",
    "🌟 Эксперт": "expert",
}
EXPS = {
    "🔒 Только проверенное": "classic",
    "⚡ Иногда что-то новое": "sometimes",
    "🚀 Люблю пробовать": "explorer",
}
BUDGETS = {
    "🎓 Студенческий": "student",
    "💰 Обычный": "normal",
    "💳 Не считаю": "free",
}
TIMES = {
    "⏱ До 15 мин": 15,
    "⏰ До 30 мин": 30,
    "☕ Сколько надо": 60,
}


class CabinetStates(StatesGroup):
    level = State()
    experiment = State()
    budget = State()
    time = State()
    exclude = State()
    recipe_day_time = State()


def _kb(options: list, cancel=True) -> ReplyKeyboardMarkup:
    rows = [[KeyboardButton(text=o)] for o in options]
    if cancel:
        rows.append([KeyboardButton(text="❌ Отмена")])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def _main_kb():
    from bot_handlers.recipes import main_kb
    return main_kb()


async def _get_profile(tg_id: str) -> dict:
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT cook_level,experiment_level,budget_level,max_cook_time,"
            "excluded_foods,recipe_day_time,recipe_day_enabled FROM user_profiles WHERE tg_id=?",
            (tg_id,)
        ) as c:
            r = await c.fetchone()
    return dict(r) if r else {}


def _profile_text(p: dict) -> str:
    lvl_map = {v: k for k, v in LEVELS.items()}
    exp_map = {v: k for k, v in EXPS.items()}
    bud_map = {v: k for k, v in BUDGETS.items()}
    time_map = {v: k for k, v in TIMES.items()}
    excl = p.get('excluded_foods', '') or 'нет'
    rdt = p.get('recipe_day_time') or 'не задано'
    rde = '✅ включён' if p.get('recipe_day_enabled') else '❌ выключен'
    return (
        f"👨‍🍳 <b>Твой кабинет</b>\n\n"
        f"🍳 Уровень: {lvl_map.get(p.get('cook_level','beginner'), 'Новичок')}\n"
        f"🚀 Эксперименты: {exp_map.get(p.get('experiment_level','sometimes'), '')}\n"
        f"💰 Бюджет: {bud_map.get(p.get('budget_level','normal'), '')}\n"
        f"⏱ Время: {time_map.get(p.get('max_cook_time', 30), '')}\n"
        f"🚫 Исключения: {excl}\n"
        f"🍝 Рецепт дня: {rde}, {rdt}\n\n"
        f"🌐 <a href='https://leviathanstory.ru/diet/cabinet'>Открыть в браузере</a>"
    )


@router.message(F.text.in_(["👤 Кабинет", "/cabinet"]))
async def cmd_cabinet(message: Message, state: FSMContext):
    p = await _get_profile(str(message.from_user.id))
    webapp_kb = InlineKeyboardMarkup(inline_keyboard=[[
        InlineKeyboardButton(
            text="📱 Открыть кабинет",
            web_app=WebAppInfo(url="https://leviathanstory.ru/diet/app")
        )
    ]])
    tg_kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="✏️ Настроить через бот")],
        [KeyboardButton(text="🍝 Рецепт дня: вкл/выкл")],
        [KeyboardButton(text="❌ Закрыть")],
    ], resize_keyboard=True)
    await message.answer(
        _profile_text(p) if p else "👤 <b>Кабинет</b>\n\nПрофиль не заполнен.",
        parse_mode="HTML", reply_markup=tg_kb)
    await message.answer("📱 Или открой в браузере:", reply_markup=webapp_kb)


@router.message(F.text == "✏️ Настроить через бот")
async def start_cabinet(message: Message, state: FSMContext):
    await state.set_state(CabinetStates.level)
    await message.answer(
        "🍳 <b>Какой твой уровень кулинарии?</b>\n"
        "🥚 Новичок — яичница, пельмени, макароны\n"
        "🍳 Любитель — омлет, суп, паста болоньезе\n"
        "👨‍🍳 Готовлю — маринады, запеканка, соусы\n"
        "🌟 Эксперт — равиоли, ризотто, профи техники",
        parse_mode="HTML", reply_markup=_kb(list(LEVELS.keys()))
    )


@router.message(CabinetStates.level, F.text.in_(list(LEVELS.keys())))
async def got_level(message: Message, state: FSMContext):
    await state.update_data(cook_level=LEVELS[message.text])
    await state.set_state(CabinetStates.experiment)
    await message.answer(
        "🚀 <b>Отношение к новым рецептам?</b>",
        parse_mode="HTML", reply_markup=_kb(list(EXPS.keys()))
    )


@router.message(CabinetStates.experiment, F.text.in_(list(EXPS.keys())))
async def got_experiment(message: Message, state: FSMContext):
    await state.update_data(experiment_level=EXPS[message.text])
    await state.set_state(CabinetStates.budget)
    await message.answer(
        "💰 <b>Бюджет на еду?</b>\n"
        "🎓 Студенческий — чётко и без пармезана\n"
        "💰 Обычный — супермаркет без излишеств\n"
        "💳 Не считаю — можно любые продукты",
        parse_mode="HTML", reply_markup=_kb(list(BUDGETS.keys()))
    )


@router.message(CabinetStates.budget, F.text.in_(list(BUDGETS.keys())))
async def got_budget(message: Message, state: FSMContext):
    await state.update_data(budget_level=BUDGETS[message.text])
    await state.set_state(CabinetStates.time)
    await message.answer(
        "⏱ <b>Сколько времени на готовку?</b>",
        parse_mode="HTML", reply_markup=_kb(list(TIMES.keys()))
    )


@router.message(CabinetStates.time, F.text.in_(list(TIMES.keys())))
async def got_time(message: Message, state: FSMContext):
    await state.update_data(max_cook_time=TIMES[message.text])
    await state.set_state(CabinetStates.exclude)
    await message.answer(
        "🚫 <b>Есть продукты которые не ешь?</b>\n"
        "Напиши через запятую или «нет»:",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="нет")],
            [KeyboardButton(text="❌ Отмена")]
        ], resize_keyboard=True)
    )


@router.message(CabinetStates.exclude)
async def got_exclude(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    excl = "" if message.text.lower() == "нет" else message.text.strip()
    await state.update_data(excluded_foods=excl)
    await state.set_state(CabinetStates.recipe_day_time)
    await message.answer(
        "🍝 <b>Рецепт дня</b> — в какое время присылать?\n"
        "Напиши время форматом <code>10:00</code> или «не нужно»:",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="09:00"), KeyboardButton(text="12:00")],
            [KeyboardButton(text="18:00"), KeyboardButton(text="не нужно")],
        ], resize_keyboard=True)
    )


@router.message(CabinetStates.recipe_day_time)
async def got_recipe_day_time(message: Message, state: FSMContext):
    import re
    text = message.text.strip()
    if text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    rdt = None
    enabled = 0
    if text != "не нужно":
        t = text.replace(".", ":")
        if re.match(r'^([01]?\d|2[0-3]):[0-5]\d$', t):
            h, m = t.split(":")
            rdt = f"{int(h):02d}:{int(m):02d}"
            enabled = 1
        else:
            return await message.answer("Формат: <code>10:00</code> или «не нужно»", parse_mode="HTML")

    data = await state.get_data()
    await state.clear()
    tg_id = str(message.from_user.id)

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles (tg_id,cook_level,experiment_level,budget_level,"
            "max_cook_time,excluded_foods,recipe_day_time,recipe_day_enabled) "
            "VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(tg_id) DO UPDATE SET "
            "cook_level=excluded.cook_level, experiment_level=excluded.experiment_level,"
            "budget_level=excluded.budget_level, max_cook_time=excluded.max_cook_time,"
            "excluded_foods=excluded.excluded_foods, recipe_day_time=excluded.recipe_day_time,"
            "recipe_day_enabled=excluded.recipe_day_enabled",
            (tg_id,
             data.get("cook_level", "beginner"),
             data.get("experiment_level", "sometimes"),
             data.get("budget_level", "normal"),
             data.get("max_cook_time", 30),
             data.get("excluded_foods", ""),
             rdt, enabled)
        )
        await db.commit()

    # Перепланируем recipe_day job
    if enabled and rdt:
        from modules.scheduler.meal_scheduler import scheduler
        from apscheduler.triggers.cron import CronTrigger
        from modules.notifier.sender import send_notification
        from modules.recipes.engine import generate_recipe
        from modules.recipes.prompt_builder import build_random_recipe_prompt
        import asyncio, json

        async def send_recipe_day(uid=tg_id):
            async with aiosqlite.connect(DB_PATH, timeout=30) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute("SELECT * FROM user_profiles WHERE tg_id=?", (uid,)) as c:
                    prof = dict(await c.fetchone() or {})
            if not prof.get("notify_personal", 1) or not prof.get("notify_recipe_day", 1):
                return
            from modules.puhlyash.persona import generate_puhlyash_recipe, format_puhlyash_message
            recipe = await generate_puhlyash_recipe(profile=prof)
            text = format_puhlyash_message(recipe)
            await send_notification(int(uid), text)

        job_id = f"recipe_day_{tg_id}"
        if scheduler.get_job(job_id):
            scheduler.remove_job(job_id)
        h, m = rdt.split(":")
        scheduler.add_job(send_recipe_day, CronTrigger(hour=int(h), minute=int(m)),
                          id=job_id, replace_existing=True)

    p = await _get_profile(tg_id)
    await message.answer(
        "✅ <b>Профиль сохранён!</b>\n\n" + _profile_text(p),
        parse_mode="HTML", reply_markup=_main_kb()
    )


@router.message(F.text == "🍝 Рецепт дня: вкл/выкл")
async def toggle_recipe_day(message: Message):
    tg_id = str(message.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        async with db.execute(
            "SELECT recipe_day_enabled FROM user_profiles WHERE tg_id=?", (tg_id,)
        ) as c:
            row = await c.fetchone()
        cur = (row[0] if row else 0) or 0
        new = 1 - cur
        await db.execute(
            "UPDATE user_profiles SET recipe_day_enabled=? WHERE tg_id=?", (new, tg_id)
        )
        await db.commit()
    status = "✅ включён" if new else "❌ выключен"
    await message.answer(f"🍝 Рецепт дня: {status}", reply_markup=_main_kb())


@router.message(F.text == "❌ Закрыть")
async def close_cabinet(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Главное меню", reply_markup=_main_kb())
````

---

## Файл: bot_handlers/diet_picker.py

`12151 байт`

````
"""Bot handler: Подбор диеты — опросник + Gemini рекомендации."""
import json, sys
import aiosqlite
sys.path.insert(0, "/opt/leviathan_engine")
try:
    from llm_factory import LLMFactory
    _LEV = True
except ImportError:
    _LEV = False
from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from building_blocks.logger import get_logger
from database import DB_PATH

log = get_logger(__name__)
router = Router()

SYS_DIET = """Ты диетолог и нутрициолог. Отвечай строго в JSON без текста вне JSON."""


class PickerStates(StatesGroup):
    goal = State()
    age = State()
    restrictions = State()
    activity = State()
    confirm = State()
    choosing = State()


def _main_kb():
    from bot_handlers.recipes import main_kb
    return main_kb()


def _cancel_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="❌ Отмена")]
    ], resize_keyboard=True)


def _goal_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🔥 Похудеть"), KeyboardButton(text="💪 Набрать мышцы")],
        [KeyboardButton(text="⚡ Больше энергии"), KeyboardButton(text="❤️ Здоровое питание")],
        [KeyboardButton(text="🦠 Лечебная диета"), KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)


def _activity_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🛋 Малоподвижный"), KeyboardButton(text="🚶 Умеренный")],
        [KeyboardButton(text="🏋 Активный"), KeyboardButton(text="⚡ Очень активный")],
        [KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)


async def _gemini(prompt: str, system: str = SYS_DIET) -> str:
    if not _LEV:
        raise RuntimeError("LLMFactory недоступен")
    return await LLMFactory.execute_request(
        prompt=prompt,
        system=system,
        model="gemini-3.1-flash-lite",
        driver="gemini",
        fallback=True,
        task_type="structured",
    )

def _fmt_diet_card(d: dict, n: int) -> str:
    pros = "\n".join(f"  ✅ {p}" for p in d.get("pros", []))
    cons = "\n".join(f"  ⚠️ {c}" for c in d.get("cons", []))
    foods = ", ".join(d.get("key_foods", []))
    return (
        f"<b>{n}. {d['name']}</b>\n"
        f"📝 {d.get('tagline', '')}\n\n"
        f"🔥 {d.get('calories_range', '')}  |  "
        f"⏱ {d.get('duration_weeks', '?')} нед.  |  "
        f"💪 {d.get('difficulty', '')}\n\n"
        f"{pros}\n{cons}\n\n"
        f"🥗 Ключевые продукты: {foods}"
    )


def _fmt_week_plan(plan: dict, diet_name: str) -> str:
    lines = [f"📅 <b>План на неделю — {diet_name}</b>\n"]
    for day in plan.get("days", []):
        lines.append(f"<b>{day['day']}</b>")
        b = day.get("breakfast", {})
        l = day.get("lunch", {})
        d = day.get("dinner", {})
        lines.append(f"  🌅 {b.get('название', b) if isinstance(b, dict) else b} ({b.get('ккал', '?') if isinstance(b, dict) else '?'} ккал)")
        lines.append(f"  🍽 {l.get('название', l) if isinstance(l, dict) else l} ({l.get('ккал', '?') if isinstance(l, dict) else '?'} ккал)")
        lines.append(f"  🌙 {d.get('название', d) if isinstance(d, dict) else d} ({d.get('ккал', '?') if isinstance(d, dict) else '?'} ккал)")
        if day.get("snack"):
            lines.append(f"  🍎 Перекус: {day['snack']}")
        lines.append("")
    shop = plan.get("shopping_list", [])
    if shop:
        lines.append("🛒 <b>Список покупок:</b>")
        lines += [f"  • {s}" for s in shop]
    tips = plan.get("tips", [])
    if tips:
        lines.append("\n💡 <b>Советы:</b>")
        lines += [f"  • {t}" for t in tips]
    return "\n".join(lines)


# ── Хендлеры ──────────────────────────────────────────────

@router.message(F.text.in_(["🎯 Подобрать диету", "🔍 Найти диету"]))
async def btn_pick_diet(message: Message, state: FSMContext):
    await state.set_state(PickerStates.goal)
    await message.answer(
        "🎯 <b>Подбор диеты</b>\n\n"
        "Шаг 1 из 4. Какая главная цель?",
        parse_mode="HTML", reply_markup=_goal_kb()
    )


GOALS = ["🔥 Похудеть", "💪 Набрать мышцы",
         "⚡ Больше энергии", "❤️ Здоровое питание", "🦠 Лечебная диета"]


@router.message(PickerStates.goal)
async def got_goal(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    await state.update_data(goal=message.text)
    await state.set_state(PickerStates.age)
    await message.answer(
        "👤 Шаг 2 из 4. Сколько тебе лет?\n"
        "Напиши цифру, например: <code>28</code>",
        parse_mode="HTML", reply_markup=_cancel_kb()
    )


@router.message(PickerStates.age)
async def got_age(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    digits = "".join(filter(str.isdigit, message.text or ""))
    if not digits or not (10 <= int(digits) <= 100):
        return await message.answer("Напиши возраст, например: <code>28</code>", parse_mode="HTML")
    await state.update_data(age=int(digits))
    await state.set_state(PickerStates.restrictions)
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="Нет ограничений")],
        [KeyboardButton(text="Без глютена"), KeyboardButton(text="Без лактозы")],
        [KeyboardButton(text="Вегетарианство"), KeyboardButton(text="Диабет")],
        [KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)
    await message.answer(
        "🥑 Шаг 3 из 4. Есть ограничения в еде?\n"
        "Выбери или напиши своё:",
        parse_mode="HTML", reply_markup=kb
    )


@router.message(PickerStates.restrictions)
async def got_restrictions(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    await state.update_data(restrictions=message.text)
    await state.set_state(PickerStates.activity)
    await message.answer(
        "🏋 Шаг 4 из 4. Уровень физической активности:",
        parse_mode="HTML", reply_markup=_activity_kb()
    )


@router.message(PickerStates.activity)
async def got_activity(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    data = await state.get_data()
    data["activity"] = message.text
    await state.update_data(activity=message.text)
    await state.set_state(PickerStates.confirm)

    # Сохраняем профиль в БД
    tg_id = str(message.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles (tg_id, goal, age, onboarding_done) VALUES (?,?,?,1) "
            "ON CONFLICT(tg_id) DO UPDATE SET goal=excluded.goal, age=excluded.age, onboarding_done=1",
            (tg_id, data.get("goal", ""), data.get("age", 0))
        )
        await db.commit()

    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🚀 Подбирай!"), KeyboardButton(text="❌ Отмена")]
    ], resize_keyboard=True)
    await message.answer(
        f"📋 <b>Твой профиль:</b>\n"
        f"🎯 Цель: {data.get('goal')}\n"
        f"👤 Возраст: {data.get('age')} лет\n"
        f"🥑 Ограничения: {data.get('restrictions')}\n"
        f"🏋 Активность: {data.get('activity')}\n\n"
        "Подобрать 3 варианта диеты?",
        parse_mode="HTML", reply_markup=kb
    )


@router.message(PickerStates.confirm, F.text == "🚀 Подбирай!")
async def do_pick(message: Message, state: FSMContext):
    data = await state.get_data()
    msg = await message.answer("⏳ Анализирую твой профиль, подбираю 3 диеты…", reply_markup=_main_kb())
    try:
        import asyncio
        diets = await asyncio.wait_for(_get_3_diets(data), timeout=60)
        await state.update_data(diets=diets)
        await state.set_state(PickerStates.choosing)

        # Отправляем 3 карточки
        cards = "\n\n".join(_fmt_diet_card(d, i+1) for i, d in enumerate(diets))
        await msg.delete()

        # Кнопки выбора
        kb = ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text=f"1️⃣ {diets[0]['name']}")],
            [KeyboardButton(text=f"2️⃣ {diets[1]['name']}")],
            [KeyboardButton(text=f"3️⃣ {diets[2]['name']}")],
            [KeyboardButton(text="❌ Отмена")],
        ], resize_keyboard=True)

        await message.answer(
            f"🎯 <b>Твои 3 варианта:</b>\n\n{cards}\n\n"
            "Выбери диету или напиши свой вариант:",
            parse_mode="HTML", reply_markup=kb
        )
    except Exception as e:
        log.error("diet picker: %s", e)
        await message.answer(f"❌ Ошибка: {e}", reply_markup=_main_kb())


@router.message(PickerStates.choosing)
async def chose_diet(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())

    data = await state.get_data()
    diets = data.get("diets", [])

    # Определяем выбранную диету
    chosen = None
    for i, d in enumerate(diets):
        if message.text.startswith(f"{i+1}️⃣") or d["name"].lower() in message.text.lower():
            chosen = d
            break
    if not chosen:
        # Свой вариант от пользователя
        chosen = {"name": message.text.strip()}

    await state.clear()
    diet_name = chosen["name"]

    # Сохраняем выбор в БД
    tg_id = str(message.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "UPDATE user_profiles SET active_diet_mode='home' WHERE tg_id=?", (tg_id,)
        )
        await db.commit()

    msg = await message.answer(
        f"✅ Выбрана <b>{diet_name}</b>!\n"
        f"⏳ Генерирую план питания на неделю…",
        parse_mode="HTML", reply_markup=_main_kb()
    )
    try:
        import asyncio
        plan = await asyncio.wait_for(_get_week_plan(diet_name, data), timeout=60)
        text = _fmt_week_plan(plan, diet_name)
        await msg.delete()
        # Длинный текст бьём частями
        for chunk in [text[i:i+3800] for i in range(0, len(text), 3800)]:
            await message.answer(chunk, parse_mode="HTML", reply_markup=_main_kb())
    except Exception as e:
        log.error("week plan: %s", e)
        await message.answer(f"❌ Ошибка плана: {e}", reply_markup=_main_kb())


@router.message(PickerStates.confirm, F.text == "❌ Отмена")
async def cancel_confirm(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Отменено", reply_markup=_main_kb())
````

---

## Файл: bot_handlers/meal_schedule_v2.py

`12970 байт`

````
"""Meal schedule v2 — все приёмы пищи в одном месте с именами."""
import uuid, re
import aiosqlite
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from building_blocks.logger import get_logger
from database import DB_PATH

log = get_logger(__name__)
router = Router()
TIME_RE = re.compile(r'^([01]?\d|2[0-3]):([0-5]\d)$')

DEFAULT_MEALS = [
    ("🌅 Завтрак", "07:30"),
    ("☕ Второй завтрак", "10:30"),
    ("🍽 Обед", "13:00"),
    ("🍎 Полдник", "16:00"),
    ("🌙 Ужин", "19:30"),
]


class MealScheduleStates(StatesGroup):
    main = State()
    adding_name = State()
    adding_time = State()
    editing_time = State()


def _main_kb():
    from bot_handlers.recipes import main_kb
    return main_kb()


async def _get_meals(tg_id: str) -> list:
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM meal_schedule WHERE tg_id=? ORDER BY sort_order, meal_time", (tg_id,)
        ) as c:
            return [dict(r) for r in await c.fetchall()]


async def _meals_text_kb(tg_id: str):
    meals = await _get_meals(tg_id)
    if not meals:
        text = "⏰ <b>Расписание питания</b>\n\nПриёмов пищи пока нет. Добавь свои или загрузи стандартное."
    else:
        lines = ["⏰ <b>Расписание питания</b>\n"]
        for m in meals:
            s = "✅" if m["enabled"] else "⏸"
            lines.append(f"{s} {m['meal_name']} — <b>{m['meal_time']}</b>")
        text = "\n".join(lines)

    rows = []
    for m in meals:
        tog = "⏸" if m["enabled"] else "▶️"
        rows.append([
            InlineKeyboardButton(text=f"✏️ {m['meal_name']}", callback_data=f"m:edit:{m['id']}"),
            InlineKeyboardButton(text=tog, callback_data=f"m:tog:{m['id']}"),
            InlineKeyboardButton(text="🗑", callback_data=f"m:del:{m['id']}"),
        ])
    rows.append([
        InlineKeyboardButton(text="➕ Добавить", callback_data="m:add"),
        InlineKeyboardButton(text="📋 Стандартное", callback_data="m:default"),
    ])
    rows.append([InlineKeyboardButton(text="✅ Готово", callback_data="m:done")])
    return text, InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text.in_(["⏰ Расписание", "/schedule"]))
async def cmd_schedule(message: Message, state: FSMContext):
    await state.set_state(MealScheduleStates.main)
    text, kb = await _meals_text_kb(str(message.from_user.id))
    await message.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data == "m:add")
async def meal_add(call: CallbackQuery, state: FSMContext):
    await state.set_state(MealScheduleStates.adding_name)
    await call.answer()
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🌅 Завтрак"), KeyboardButton(text="☕ Перекус")],
        [KeyboardButton(text="🍽 Обед"), KeyboardButton(text="🍎 Полдник")],
        [KeyboardButton(text="🌙 Ужин"), KeyboardButton(text="🍵 Вечерний чай")],
        [KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)
    await call.message.answer("📝 Название приёма пищи (выбери или напиши своё):", reply_markup=kb)


@router.message(MealScheduleStates.adding_name)
async def meal_got_name(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.set_state(MealScheduleStates.main)
        text, kb = await _meals_text_kb(str(message.from_user.id))
        return await message.answer(text, parse_mode="HTML", reply_markup=kb)
    await state.update_data(new_meal_name=message.text.strip())
    await state.set_state(MealScheduleStates.adding_time)
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="07:00"), KeyboardButton(text="08:00"), KeyboardButton(text="09:00")],
        [KeyboardButton(text="12:00"), KeyboardButton(text="13:00"), KeyboardButton(text="14:00")],
        [KeyboardButton(text="17:00"), KeyboardButton(text="18:00"), KeyboardButton(text="19:00")],
        [KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)
    await message.answer(
        f"⏰ Время для <b>{message.text}</b>? Формат: <code>08:30</code>",
        parse_mode="HTML", reply_markup=kb
    )


@router.message(MealScheduleStates.adding_time)
async def meal_got_time(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.set_state(MealScheduleStates.main)
        text, kb = await _meals_text_kb(str(message.from_user.id))
        return await message.answer(text, parse_mode="HTML", reply_markup=kb)
    t = message.text.strip().replace(".", ":")
    if not TIME_RE.match(t):
        return await message.answer("⚠️ Формат: <code>08:30</code>", parse_mode="HTML")
    h, m = t.split(":")
    time_str = f"{int(h):02d}:{int(m):02d}"
    data = await state.get_data()
    name = data.get("new_meal_name", "Приём пищи")
    tg_id = str(message.from_user.id)
    meals = await _get_meals(tg_id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO meal_schedule (id,tg_id,meal_name,meal_time,enabled,sort_order) VALUES (?,?,?,?,1,?)",
            (str(uuid.uuid4()), tg_id, name, time_str, len(meals))
        )
        await db.commit()
    await _schedule_meal(tg_id, name, time_str)
    await state.set_state(MealScheduleStates.main)
    text, kb = await _meals_text_kb(tg_id)
    await message.answer(f"✅ Добавлен <b>{name}</b> в {time_str}", parse_mode="HTML", reply_markup=_main_kb())
    await message.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data == "m:default")
async def meal_default(call: CallbackQuery, state: FSMContext):
    tg_id = str(call.from_user.id)
    await call.answer("Загружаю стандартное расписание...")
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute("DELETE FROM meal_schedule WHERE tg_id=?", (tg_id,))
        for i, (name, time_str) in enumerate(DEFAULT_MEALS):
            await db.execute(
                "INSERT INTO meal_schedule (id,tg_id,meal_name,meal_time,enabled,sort_order) VALUES (?,?,?,?,1,?)",
                (str(uuid.uuid4()), tg_id, name, time_str, i)
            )
        await db.commit()
    for name, time_str in DEFAULT_MEALS:
        await _schedule_meal(tg_id, name, time_str)
    text, kb = await _meals_text_kb(tg_id)
    await call.message.edit_text(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data.startswith("m:tog:"))
async def meal_toggle(call: CallbackQuery, state: FSMContext):
    meal_id = call.data[6:]
    tg_id = str(call.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        async with db.execute("SELECT enabled FROM meal_schedule WHERE id=?", (meal_id,)) as c:
            row = await c.fetchone()
        if not row: return await call.answer("?")
        new = 1 - (row[0] or 0)
        await db.execute("UPDATE meal_schedule SET enabled=? WHERE id=?", (new, meal_id))
        await db.commit()
    await call.answer("✅" if new else "⏸")
    text, kb = await _meals_text_kb(tg_id)
    await call.message.edit_text(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data.startswith("m:del:"))
async def meal_delete(call: CallbackQuery, state: FSMContext):
    meal_id = call.data[6:]
    tg_id = str(call.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        async with db.execute("SELECT meal_name FROM meal_schedule WHERE id=?", (meal_id,)) as c:
            row = await c.fetchone()
        if row:
            try:
                from modules.scheduler.meal_scheduler import scheduler
                jid = f"meal_{tg_id}_{row[0]}"
                if scheduler.get_job(jid): scheduler.remove_job(jid)
            except Exception: pass
        await db.execute("DELETE FROM meal_schedule WHERE id=?", (meal_id,))
        await db.commit()
    await call.answer("🗑 Удалено")
    text, kb = await _meals_text_kb(tg_id)
    await call.message.edit_text(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data.startswith("m:edit:"))
async def meal_edit(call: CallbackQuery, state: FSMContext):
    meal_id = call.data[7:]
    await state.set_state(MealScheduleStates.editing_time)
    await state.update_data(editing_id=meal_id)
    await call.answer()
    await call.message.answer(
        "⏰ Новое время (<code>08:30</code>):", parse_mode="HTML",
        reply_markup=ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="❌ Отмена")]], resize_keyboard=True)
    )


@router.message(MealScheduleStates.editing_time)
async def meal_edit_time(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.set_state(MealScheduleStates.main)
        text, kb = await _meals_text_kb(str(message.from_user.id))
        return await message.answer(text, parse_mode="HTML", reply_markup=kb)
    t = message.text.strip().replace(".", ":")
    if not TIME_RE.match(t):
        return await message.answer("⚠️ Формат: <code>08:30</code>", parse_mode="HTML")
    h, m = t.split(":")
    time_str = f"{int(h):02d}:{int(m):02d}"
    data = await state.get_data()
    meal_id = data.get("editing_id")
    tg_id = str(message.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        async with db.execute("SELECT meal_name FROM meal_schedule WHERE id=?", (meal_id,)) as c:
            row = await c.fetchone()
        await db.execute("UPDATE meal_schedule SET meal_time=? WHERE id=?", (time_str, meal_id))
        await db.commit()
        if row: await _schedule_meal(tg_id, row[0], time_str)
    await state.set_state(MealScheduleStates.main)
    text, kb = await _meals_text_kb(tg_id)
    await message.answer(f"✅ Время обновлено: {time_str}", reply_markup=_main_kb())
    await message.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data == "m:done")
async def meal_done(call: CallbackQuery, state: FSMContext):
    await state.clear()
    await call.answer("✅ Сохранено!")
    await call.message.answer("✅ Расписание готово!", reply_markup=_main_kb())


async def _schedule_meal(tg_id: str, meal_name: str, time_str: str):
    try:
        from modules.scheduler.meal_scheduler import scheduler
        from apscheduler.triggers.cron import CronTrigger
        from modules.notifier.sender import send_notification
        from modules.puhlyash.persona import generate_puhlyash_recipe, format_puhlyash_message
        import aiosqlite
        from database import DB_PATH as _DB

        job_id = f"meal_{tg_id}_{meal_name}"
        if scheduler.get_job(job_id): scheduler.remove_job(job_id)

        async def _fire(uid=tg_id, name=meal_name):
            async with aiosqlite.connect(_DB, timeout=30) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute(
                    "SELECT enabled FROM meal_schedule WHERE tg_id=? AND meal_name=?", (uid, name)
                ) as c:
                    row = await c.fetchone()
            if not row or not row["enabled"]: return
            async with aiosqlite.connect(_DB, timeout=30) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute("SELECT * FROM user_profiles WHERE tg_id=?", (uid,)) as c:
                    prof = await c.fetchone()
            if not prof: return
            prof = dict(prof)
            if not prof.get("notify_personal", 1) or not prof.get("notify_meals", 1): return
            recipe = await generate_puhlyash_recipe(profile=prof)
            from modules.fitness.engine import generate_exercises, format_exercises
            exercises = await generate_exercises("lunch", prof.get("active_diet_mode") or "home")
            text = (
                f"⏰ <b>{name}!</b>\n\n"
                f"{format_puhlyash_message(recipe)}\n\n"
                f"{format_exercises(exercises)}"
            )
            await send_notification(uid, text)

        h, m = time_str.split(":")
        scheduler.add_job(_fire, CronTrigger(hour=int(h), minute=int(m), timezone="Europe/Moscow"),
                          id=job_id, replace_existing=True)
        log.info("Scheduled meal '%s' for %s at %s", meal_name, tg_id, time_str)
    except Exception as e:
        log.error("_schedule_meal: %s", e)
````

---

## Файл: bot_handlers/puhlyash_settings.py

`10706 байт`

````
"""Puhlyash mascot settings + test notifications."""
import aiosqlite
from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from building_blocks.logger import get_logger
from database import DB_PATH

log = get_logger(__name__)
router = Router()


class PuhlyashStates(StatesGroup):
    main = State()
    edit_name = State()
    edit_specialty = State()
    edit_tone = State()


DEFAULT_PUHLYASH = {
    "name": "Пухляш",
    "specialty": "всё подряд",
    "tone": "friendly",
    "catchphrase": "Свой парень, знает толк в еде!",
    "emoji": "🍝",
}

TONES = {
    "friendly":  "😊 Дружелюбный",
    "funny":     "😂 С юморком",
    "serious":   "🧐 Серьёзный",
    "foodie":    "😍 Гурман",
}


def _main_kb():
    from bot_handlers.recipes import main_kb
    return main_kb()


async def _get_puhlyash(tg_id: str) -> dict:
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT puhlyash_name, puhlyash_specialty, puhlyash_tone, puhlyash_catchphrase, puhlyash_emoji "
            "FROM user_profiles WHERE tg_id=?", (tg_id,)
        ) as c:
            row = await c.fetchone()
    if not row:
        return DEFAULT_PUHLYASH.copy()
    return {
        "name": row["puhlyash_name"] or DEFAULT_PUHLYASH["name"],
        "specialty": row["puhlyash_specialty"] or DEFAULT_PUHLYASH["specialty"],
        "tone": row["puhlyash_tone"] or DEFAULT_PUHLYASH["tone"],
        "catchphrase": row["puhlyash_catchphrase"] or DEFAULT_PUHLYASH["catchphrase"],
        "emoji": row["puhlyash_emoji"] or DEFAULT_PUHLYASH["emoji"],
    }


async def _ensure_columns():
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        for col in [
            "puhlyash_name TEXT DEFAULT 'Пухляш'",
            "puhlyash_specialty TEXT DEFAULT 'всё подряд'",
            "puhlyash_tone TEXT DEFAULT 'friendly'",
            "puhlyash_catchphrase TEXT",
            "puhlyash_emoji TEXT DEFAULT '🍝'",
        ]:
            try:
                await db.execute(f"ALTER TABLE user_profiles ADD COLUMN {col}")
            except Exception:
                pass
        await db.commit()


@router.message(F.text.in_(["🍝 Пухляш", "🍝 Настройка Пухляша", "/puhlyash"]))
async def cmd_puhlyash(message: Message, state: FSMContext):
    await _ensure_columns()
    tg_id = str(message.from_user.id)
    p = await _get_puhlyash(tg_id)
    tone_label = TONES.get(p["tone"], p["tone"])

    text = (
        f"{p['emoji']} <b>Настройка {p['name']}</b>\n\n"
        f"🎨 Имя: <b>{p['name']}</b>\n"
        f"🍳 Специализация: {p['specialty']}\n"
        f"💬 Тон: {tone_label}\n"
        f"✨ Фраза: <i>{p['catchphrase']}</i>\n\n"
        f"🧪 Тест уведомлений:"
    )

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text=f"🎨 Изменить имя", callback_data="ph:name"),
         InlineKeyboardButton(text=f"🍳 Специализация", callback_data="ph:spec")],
        [InlineKeyboardButton(text=f"💬 Тон общения", callback_data="ph:tone"),
         InlineKeyboardButton(text=f"✨ Фраза", callback_data="ph:catch")],
        [InlineKeyboardButton(text="🧪 Прислать тестовое уведомление", callback_data="ph:test_notify")],
        [InlineKeyboardButton(text="🍝 Получить рецепт сейчас", callback_data="ph:recipe_now")],
    ])
    await message.answer(text, parse_mode="HTML", reply_markup=kb)


@router.callback_query(F.data == "ph:test_notify")
async def test_notify(call, state: FSMContext):
    await call.answer("Отправляю...")
    tg_id = str(call.from_user.id)
    try:
        from modules.notifier.sender import send_notification
        from modules.puhlyash.persona import generate_puhlyash_recipe, format_puhlyash_message
        import asyncio
        p = await _get_puhlyash(tg_id)
        recipe = await asyncio.wait_for(generate_puhlyash_recipe(), timeout=30)
        text = (
            f"{p['emoji']} <b>Тестовое уведомление от {p['name']}</b>\n\n"
            f"{format_puhlyash_message(recipe)}"
        )
        ok = await send_notification(int(tg_id), text)
        if ok:
            await call.message.answer("✅ Отправлено! Проверь личные сообщения в Telegram → @FatBoyandGirl_bot")
        else:
            await call.message.answer("❌ Не удалось. Проверь настройки userbot'a.")
    except Exception as e:
        await call.message.answer(f"❌ Ошибка: {e}")


@router.callback_query(F.data == "ph:recipe_now")
async def recipe_now(call, state: FSMContext):
    await call.answer("🍝 Генерирую...")
    tg_id = str(call.from_user.id)
    try:
        from modules.puhlyash.persona import generate_puhlyash_recipe, format_puhlyash_message
        from modules.reactions.engine import reaction_kb
        from bot_handlers.recipes import _save
        import asyncio
        recipe = await asyncio.wait_for(generate_puhlyash_recipe(), timeout=45)
        await _save(recipe)
        text = format_puhlyash_message(recipe)
        await call.message.answer(text, parse_mode="HTML",
                                  reply_markup=reaction_kb("recipe", recipe.get("id", "")))
        await call.message.answer("👇 Как тебе?", reply_markup=_main_kb())
    except Exception as e:
        await call.message.answer(f"❌ {e}")


@router.callback_query(F.data == "ph:name")
async def edit_name(call, state: FSMContext):
    await call.answer()
    await state.set_state(PuhlyashStates.edit_name)
    await call.message.answer(
        "🎨 Как будем звать маскота?\n"
        "Напиши имя (например: Пухляш, Боря, Гурман)",
        reply_markup=ReplyKeyboardMarkup(keyboard=[
            [KeyboardButton(text="Пухляш")],
            [KeyboardButton(text="❌ Отмена")]
        ], resize_keyboard=True)
    )


@router.message(PuhlyashStates.edit_name)
async def got_name(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    name = message.text.strip()[:30]
    tg_id = str(message.from_user.id)
    await _ensure_columns()
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles (tg_id, puhlyash_name) VALUES (?,?) "
            "ON CONFLICT(tg_id) DO UPDATE SET puhlyash_name=excluded.puhlyash_name",
            (tg_id, name)
        )
        await db.commit()
    await state.clear()
    await message.answer(f"✅ Теперь твой маскот — <b>{name}</b>!", parse_mode="HTML", reply_markup=_main_kb())


@router.callback_query(F.data == "ph:spec")
async def edit_spec(call, state: FSMContext):
    await call.answer()
    await state.set_state(PuhlyashStates.edit_specialty)
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="всё подряд"), KeyboardButton(text="итальянская кухня")],
        [KeyboardButton(text="азиатская кухня"), KeyboardButton(text="домашняя русская")],
        [KeyboardButton(text="выпечка и десерты"), KeyboardButton(text="здоровое питание")],
        [KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)
    await call.message.answer("🍳 На чём специализируется?", reply_markup=kb)


@router.message(PuhlyashStates.edit_specialty)
async def got_spec(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    tg_id = str(message.from_user.id)
    await _ensure_columns()
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles (tg_id, puhlyash_specialty) VALUES (?,?) "
            "ON CONFLICT(tg_id) DO UPDATE SET puhlyash_specialty=excluded.puhlyash_specialty",
            (tg_id, message.text.strip())
        )
        await db.commit()
    await state.clear()
    await message.answer(f"✅ Специализация: <b>{message.text}</b>", parse_mode="HTML", reply_markup=_main_kb())


@router.callback_query(F.data == "ph:tone")
async def edit_tone_cb(call, state: FSMContext):
    await call.answer()
    await state.set_state(PuhlyashStates.edit_tone)
    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text=label) for label in TONES.values()],
        [KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)
    await call.message.answer("💬 Тон общения:", reply_markup=kb)


@router.message(PuhlyashStates.edit_tone)
async def got_tone(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        return await message.answer("Отменено", reply_markup=_main_kb())
    tone_key = next((k for k, v in TONES.items() if v == message.text), "friendly")
    tg_id = str(message.from_user.id)
    await _ensure_columns()
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles (tg_id, puhlyash_tone) VALUES (?,?) "
            "ON CONFLICT(tg_id) DO UPDATE SET puhlyash_tone=excluded.puhlyash_tone",
            (tg_id, tone_key)
        )
        await db.commit()
    await state.clear()
    await message.answer(f"✅ Тон: <b>{message.text}</b>", parse_mode="HTML", reply_markup=_main_kb())


@router.callback_query(F.data == "ph:catch")
async def edit_catch(call, state: FSMContext):
    from aiogram.fsm.state import State
    await call.answer()
    # Используем edit_name state как generic text input
    await state.set_state(PuhlyashStates.edit_name)
    await state.update_data(editing_field="catchphrase")
    await call.message.answer(
        "✨ Напиши фразу маскота:\n"
        "Например: <i>Свой парень, знает толк в еде!</i>",
        parse_mode="HTML",
        reply_markup=ReplyKeyboardMarkup(keyboard=[[KeyboardButton(text="❌ Отмена")]], resize_keyboard=True)
    )
````

---

## Файл: bot_handlers/reactions.py

`8340 байт`

````
"""Callback handler: реакции на рецепты/диеты/упражнения."""
import asyncio, sys
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from building_blocks.logger import get_logger
from modules.reactions.engine import save_reaction, reaction_kb_with_reason

log = get_logger(__name__)

sys.path.insert(0, "/opt/leviathan_engine")
try:
    from llm_factory import LLMFactory
    _LEV = True
except ImportError:
    _LEV = False
    log.warning("LLMFactory недоступен в reactions.py")
router = Router()


class WizardStates(StatesGroup):
    chatting = State()


@router.callback_query(F.data.startswith("react:"))
async def on_reaction(call: CallbackQuery, state: FSMContext):
    parts = call.data.split(":", 3)
    if len(parts) < 4:
        return await call.answer()
    _, reaction, item_type, item_id = parts
    tg_id = str(call.from_user.id)

    item_title = ""
    if call.message and call.message.html_text:
        for line in call.message.html_text.split("\n"):
            clean = line.replace("<b>", "").replace("</b>", "").replace("<i>", "").replace("</i>", "").strip()
            if clean and not clean.startswith("\u2022") and not clean.startswith("\u23f1"):
                item_title = clean[:80]
                break

    if reaction == "save":
        await save_reaction(tg_id, item_type, item_id, item_title, "save")
        return await call.answer("🔖 Сохранено!", show_alert=False)

    if reaction in ("like", "dislike"):
        await save_reaction(tg_id, item_type, item_id, item_title, reaction)
        emoji = "👍" if reaction == "like" else "👎"
        await call.answer(f"{emoji} Записал!", show_alert=False)
        kb = reaction_kb_with_reason(item_type, item_id, reaction)
        await call.message.answer(
            f"{'\u0420ад слышать! ' if reaction == 'like' else '\u0416аль... '}"
            f"Хочешь уточнить почему? (\u043dеобязательно)",
            reply_markup=kb
        )
        return

    if reaction == "alt":
        await call.answer("🔄 Генерирую альтернативы...", show_alert=False)
        await _send_alternatives(call, item_id, tg_id)
        return

    if reaction == "expand":
        await call.answer("💡 Запускаю мастера...", show_alert=False)
        await _start_wizard(call, item_id, item_title, state)
        return


@router.callback_query(F.data.startswith("reason:"))
async def on_reason(call: CallbackQuery):
    parts = call.data.split(":", 3)
    if len(parts) < 4:
        return await call.answer()
    _, reason, item_type, item_id = parts
    tg_id = str(call.from_user.id)
    if reason != "skip":
        import aiosqlite
        from database import DB_PATH
        async with aiosqlite.connect(DB_PATH, timeout=30) as db:
            await db.execute(
                "UPDATE reactions SET reason=? WHERE tg_id=? AND item_type=? AND item_id=? "
                "ORDER BY created_at DESC LIMIT 1",
                (reason, tg_id, item_type, item_id)
            )
            await db.commit()
    await call.answer("✅ Спасибо!", show_alert=False)
    try:
        await call.message.delete()
    except Exception:
        pass


async def _send_alternatives(call: CallbackQuery, item_id: str, tg_id: str):
    import aiosqlite
    from database import DB_PATH
    from modules.recipes.engine import generate_recipe
    from modules.reactions.engine import reaction_kb

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT title, mode FROM recipes WHERE id=?", (item_id,)) as c:
            row = await c.fetchone()

    title = row["title"] if row else "блюдо"
    mode = row["mode"] if row else "home"
    msg = await call.message.answer(f"🔄 Придумываю альтернативы к «{title}»...")
    try:
        from bot_handlers.recipes import _fmt, _save
        alt1, alt2 = await asyncio.gather(
            generate_recipe(f"простой вариант похожего на {title}", mode),
            generate_recipe(f"необычный вариант блюда похожего на {title}", mode),
        )
        await _save(alt1)
        await _save(alt2)
        await msg.delete()
        await call.message.answer(f"🔄 <b>Альтернативы к «{title}»:</b>", parse_mode="HTML")
        await call.message.answer(f"1️⃣ <b>Попроще:</b>\n\n{_fmt(alt1)}", parse_mode="HTML",
                                   reply_markup=reaction_kb("recipe", alt1["id"]))
        await call.message.answer(f"2️⃣ <b>Поинтереснее:</b>\n\n{_fmt(alt2)}", parse_mode="HTML",
                                   reply_markup=reaction_kb("recipe", alt2["id"]))
    except Exception as e:
        log.error("alternatives: %s", e)
        await msg.edit_text(f"❌ Ошибка: {e}")


async def _start_wizard(call: CallbackQuery, item_id: str, item_title: str, state: FSMContext):
    await state.set_state(WizardStates.chatting)
    await state.update_data(wizard_recipe=item_title, wizard_history=[], wizard_item_id=item_id)
    await call.message.answer(
        f"🧑‍🍳 <b>Мастер кулинарных экспериментов</b>\n\n"
        f"Пухляш готов поэкспериментировать с <b>{item_title}</b>!\n\n"
        f"Что хочешь добавить или изменить?\n"
        f"Например: <i>добавить помидоры</i>, <i>сделать острее</i>, <i>без мяса</i>\n\n"
        f"<i>Но учти — Пухляш проверит можно ли такое сочетать 😄</i>\n\n"
        f"Для выхода напиши <code>стоп</code>",
        parse_mode="HTML"
    )


@router.message(WizardStates.chatting)
async def wizard_chat(message: Message, state: FSMContext):
    if message.text and message.text.lower().strip() in ("стоп", "stop", "выход", "хватит"):
        await state.clear()
        return await message.answer("👨‍🍳 Опыт закончен! Приятного аппетита 😋")

    data = await state.get_data()
    recipe_name = data.get("wizard_recipe", "блюдо")
    history = data.get("wizard_history", [])
    msg = await message.answer("🧐 Пухляш думает...")

    sys_prompt = (
        f"Ты Пухляш — опытный повар с характером. "
        f"Пользователь хочет экспериментировать с «{recipe_name}». "
        f"Твоя задача:\n"
        f"1. Проверить совместимость ингредиентов (как селёдка с молоком — плохая идея)\n"
        f"2. Если плохое сочетание — честно предупреди, с юмором\n"
        f"3. Если нормальное — подскажи как добавить\n"
        f"4. Если отличное — восхитись и опиши что получится\n"
        f"Не соглашайся на всё. Быть контролирующим, но дружелюбным. Коротко (2-4 предложения). На русском."
    )

    history.append({"role": "user", "parts": [{"text": message.text}]})
    try:
        if not _LEV:
            raise RuntimeError("LLMFactory недоступен")
        dialogue = "\n".join(
            f'{"Пользователь" if h["role"]=="user" else "Пухляш"}: {h["parts"][0]["text"]}'
            for h in history[-8:]
        )
        answer = await LLMFactory.execute_request(
            prompt=dialogue,
            system=sys_prompt,
            model="gemini-3.1-flash-lite",
            driver="gemini",
            fallback=True,
            task_type="default",
        )
        history.append({"role": "model", "parts": [{"text": answer}]})
        await state.update_data(wizard_history=history[-12:])
        await msg.delete()
        await message.answer(f"👨‍🍳 {answer}")
    except Exception as e:
        await msg.edit_text(f"❌ {e}")
````

---

## Файл: bot_handlers/recipes.py

`16152 байт`

````
"""Bot handlers v2: Рецепты, Холодильник, Бюджет, Шеф на телефоне."""
import json, sys
import aiosqlite
from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from building_blocks.logger import get_logger
from database import DB_PATH
from modules.recipes.engine import generate_recipe, generate_from_fridge, generate_budget_recipe, MODES

log = get_logger(__name__)
router = Router()

sys.path.insert(0, "/opt/leviathan_engine")
try:
    from llm_factory import LLMFactory
    _LEVIATHAN_CORE = True
except ImportError:
    _LEVIATHAN_CORE = False
    log.warning("⚠️ LLMFactory недоступен в recipes.py, Чеф на телефоне не будет работать")


async def _ask_llm(prompt: str, system: str) -> str:
    """Свободный чат («Шеф на телефоне») через Leviathan LLMFactory:
    KeyPool + CircuitBreaker + fallback на Groq, вместо raw urllib + ручной ротации ключей.
    """
    if not _LEVIATHAN_CORE:
        raise RuntimeError("LLMFactory недоступен")
    return await LLMFactory.execute_request(
        prompt=prompt,
        system=system,
        model="gemini-3.1-flash-lite",
        driver="gemini",
        fallback=True,
        task_type="default",
    )


class RecipeStates(StatesGroup):
    waiting_query = State()
    waiting_mode = State()

class FridgeStates(StatesGroup):
    waiting_ingredients = State()

class BudgetStates(StatesGroup):
    waiting_amount = State()

class ChefStates(StatesGroup):
    chatting = State()


MODE_MAP = {"⚡ Быстро": "quick", "🏠 Домашний": "home",
            "🍽 Ресторанный": "restaurant", "🥦 ПП": "pp"}


def recipes_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="⚡ Быстро"), KeyboardButton(text="🏠 Домашний")],
        [KeyboardButton(text="🍽 Ресторанный"), KeyboardButton(text="🥦 ПП")],
        [KeyboardButton(text="🔙 Назад")],
    ], resize_keyboard=True)


def main_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="🎯 Подобрать диету"), KeyboardButton(text="👤 Кабинет")],
        [KeyboardButton(text="🍝 Рецепт от Пухляша"), KeyboardButton(text="👨‍🍳 Рецепты")],
        [KeyboardButton(text="🧊 Холодильник"), KeyboardButton(text="💰 По бюджету")],
        [KeyboardButton(text="👨‍🍳 Шеф на телефоне"), KeyboardButton(text="⏰ Расписание")],
        [KeyboardButton(text="🐈 Пухляш"), KeyboardButton(text="ℹ️ Помощь")],
    ], resize_keyboard=True, persistent=True)


def _fmt(r: dict) -> str:
    ingr = json.loads(r.get("ingredients", "[]"))
    steps = json.loads(r.get("steps", "[]"))
    tags = json.loads(r.get("tags", "[]"))
    lines = [
        f"🍳 <b>{r.get('title','?')}</b>",
        f"📝 {r.get('description','')}", "",
        f"⏱ {r.get('cook_time_minutes','?')} мин  |  👤 {r.get('servings',2)} порции",
        f"🔥 {r.get('calories_per_serving','?')} ккал  |"
        f"  Б:{r.get('protein_g','?')}г  Ж:{r.get('fat_g','?')}г  У:{r.get('carbs_g','?')}г",
        "", "<b>Ингредиенты:</b>"
    ] + [f"• {i}" for i in ingr] + ["", "<b>Приготовление:</b>"] + list(steps)
    if tags:
        lines += ["", "🏷 " + "  ".join(f"#{t}" for t in tags)]
    return "\n".join(lines)


async def _save(recipe: dict):
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT OR IGNORE INTO recipes "
            "(id,title,mode,description,ingredients,steps,"
            "calories_per_serving,protein_g,fat_g,carbs_g,cook_time_minutes,servings,tags)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (recipe["id"], recipe.get("title",""), recipe.get("mode",""),
             recipe.get("description",""), recipe["ingredients"], recipe["steps"],
             recipe.get("calories_per_serving"), recipe.get("protein_g"),
             recipe.get("fat_g"), recipe.get("carbs_g"),
             recipe.get("cook_time_minutes"), recipe.get("servings", 2), recipe["tags"])
        )
        await db.commit()


# ── Рецепты ───────────────────────────────────────────────
@router.message(F.text == "👨‍🍳 Рецепты")
async def btn_recipes(message: Message, state: FSMContext):
    log.info("btn_recipes called from %s", message.from_user.id)
    await state.set_state(RecipeStates.waiting_query)
    await message.answer(
        "👨‍🍳 <b>Рецепты</b>\n\nЧто хочешь приготовить?\nНапример: <code>паста карбонара</code>",
        parse_mode="HTML", reply_markup=recipes_kb()
    )


@router.message(RecipeStates.waiting_query, F.text.in_(list(MODE_MAP.keys())))
async def recipe_query_is_mode(message: Message, state: FSMContext):
    """User сразу выбрал режим без запроса — генерируем случайное блюдо."""
    mode = MODE_MAP[message.text]
    await state.clear()
    RANDOM_QUERIES = {
        "quick": "быстрый завтрак",
        "home": "вкусный ужин",
        "restaurant": "ресторанное блюдо",
        "pp": "здоровое блюдо",
    }
    query = RANDOM_QUERIES.get(mode, "вкусное блюдо")
    msg = await message.answer("⏳ Генерирую рецепт…", reply_markup=main_kb())
    try:
        import asyncio
        recipe = await asyncio.wait_for(generate_recipe(query, mode), timeout=45)
        await _save(recipe)
        await msg.delete()
        from modules.reactions.engine import reaction_kb as _rkb
        rid = recipe.get("id", "")
        await message.answer(_fmt(recipe), parse_mode="HTML",
            reply_markup=_rkb("recipe", rid) if rid else main_kb())
        if rid:
            await message.answer("👇 Как тебе?", reply_markup=main_kb())
    except asyncio.TimeoutError:
        await message.answer("❌ Генерация заняла слишком долго. Попробуй ещё раз.")
    except Exception as e:
        log.error("recipe: %s", e)
        await message.answer(f"❌ Ошибка: {e}")


@router.message(RecipeStates.waiting_query,
    F.text.not_in(list(MODE_MAP.keys()) + ["🔙 Назад"]))
async def recipe_got_query(message: Message, state: FSMContext):
    await state.update_data(query=message.text.strip())
    await state.set_state(RecipeStates.waiting_mode)
    await message.answer(
        f"🍽 <b>{message.text.strip()}</b>\n\nВыбери режим:",
        parse_mode="HTML", reply_markup=recipes_kb()
    )


@router.message(RecipeStates.waiting_mode, F.text.in_(list(MODE_MAP.keys())))
async def recipe_got_mode(message: Message, state: FSMContext):
    data = await state.get_data()
    mode = MODE_MAP[message.text]
    query = data.get("query", "вкусное блюдо")
    await state.clear()
    msg = await message.answer("⏳ Генерирую рецепт…", reply_markup=main_kb())
    try:
        import asyncio
        recipe = await asyncio.wait_for(generate_recipe(query, mode), timeout=45)
        await _save(recipe)
        await msg.delete()
        from modules.reactions.engine import reaction_kb as _rkb
        rid = recipe.get("id", "")
        await message.answer(_fmt(recipe), parse_mode="HTML",
            reply_markup=_rkb("recipe", rid) if rid else main_kb())
        if rid:
            await message.answer("👇 Как тебе?", reply_markup=main_kb())
    except asyncio.TimeoutError:
        await message.answer("❌ Генерация заняла слишком долго. Попробуй ещё раз.")
    except Exception as e:
        log.error("recipe: %s", e)
        await message.answer(f"❌ Ошибка: {e}")


# ── Холодильник ──────────────────────────────────────────
@router.message(F.text == "🧊 Холодильник")
async def btn_fridge(message: Message, state: FSMContext):
    await state.set_state(FridgeStates.waiting_ingredients)
    await message.answer(
        "🧊 <b>Холодильник</b>\n\nПеречисли что есть через запятую:\n"
        "<code>курица, яйца, помидоры, сыр</code>",
        parse_mode="HTML"
    )


@router.message(FridgeStates.waiting_ingredients)
async def fridge_got_ingredients(message: Message, state: FSMContext):
    ingredients = [i.strip() for i in message.text.split(",") if i.strip()]
    if len(ingredients) < 2:
        await message.answer("Укажи хотя бы 2 ингредиента через запятую")
        return
    await state.clear()
    msg = await message.answer(f"🧨 Смотрю что сделать из {len(ingredients)} продуктов…", reply_markup=main_kb())
    try:
        import asyncio
        recipe = await asyncio.wait_for(generate_from_fridge(ingredients), timeout=45)
        await _save(recipe)
        await msg.delete()
        from modules.reactions.engine import reaction_kb as _rkb
        rid = recipe.get("id", "")
        await message.answer(_fmt(recipe), parse_mode="HTML",
            reply_markup=_rkb("recipe", rid) if rid else main_kb())
        if rid:
            await message.answer("👇 Как тебе?", reply_markup=main_kb())
    except asyncio.TimeoutError:
        await message.answer("❌ Генерация заняла слишком долго. Попробуй ещё раз.")
    except Exception as e:
        await message.answer(f"❌ Ошибка: {e}")


# ── По бюджету ───────────────────────────────────────────
@router.message(F.text == "💰 По бюджету")
async def btn_budget(message: Message, state: FSMContext):
    await state.set_state(BudgetStates.waiting_amount)
    await message.answer(
        "💰 <b>Меню по бюджету</b>\n\nНапиши сумму в рублях:\n<code>500</code>",
        parse_mode="HTML"
    )


@router.message(BudgetStates.waiting_amount)
async def budget_got_amount(message: Message, state: FSMContext):
    digits = "".join(filter(str.isdigit, message.text or ""))
    if not digits:
        await message.answer("Напиши число, например: <code>500</code>", parse_mode="HTML")
        return
    budget = int(digits)
    await state.clear()
    msg = await message.answer(f"💰 Придумываю ужин на {budget} руб…", reply_markup=main_kb())
    try:
        import asyncio
        recipe = await asyncio.wait_for(generate_budget_recipe(budget), timeout=45)
        await _save(recipe)
        await msg.delete()
        from modules.reactions.engine import reaction_kb as _rkb
        rid = recipe.get("id", "")
        await message.answer(_fmt(recipe), parse_mode="HTML",
            reply_markup=_rkb("recipe", rid) if rid else main_kb())
        if rid:
            await message.answer("👇 Как тебе?", reply_markup=main_kb())
    except asyncio.TimeoutError:
        await message.answer("❌ Генерация заняла слишком долго. Попробуй ещё раз.")
    except Exception as e:
        await message.answer(f"❌ Ошибка: {e}")


# ── Шеф на телефоне ───────────────────────────────────
@router.message(F.text == "👨‍🍳 Шеф на телефоне")
async def btn_chef(message: Message, state: FSMContext):
    await state.set_state(ChefStates.chatting)
    await state.update_data(history=[])
    await message.answer(
        "👨‍🍳 <b>Шеф на телефоне</b>\n\nСпрашивай что угодно:\n"
        "• Как пожарить стейк?\n• Чем заменить яйца?\n• Сколько варить пасту?\n\n"
        "Для выхода напиши <code>стоп</code>",
        parse_mode="HTML"
    )


@router.message(ChefStates.chatting)
async def chef_chat(message: Message, state: FSMContext):
    if message.text and message.text.lower().strip() in ("стоп", "stop", "выход", "🔙 назад"):
        await state.clear()
        await message.answer("👍 До следующего раза!", reply_markup=main_kb())
        return
    data = await state.get_data()
    history = data.get("history", [])
    msg = await message.answer("👨‍🍳 Думаю…")
    try:
        sys_chef = "Ты опытный шеф-повар. Отвечай кратко, практично, по делу. На русском."
        history.append({"role": "user", "text": message.text})
        # LLMFactory не принимает multi-turn contents напрямую — сворачиваем
        # историю в один промпт (последние 10 реплик)
        dialogue = "\n".join(
            f"{'Пользователь' if h['role']=='user' else 'Шеф'}: {h['text']}"
            for h in history[-10:]
        )
        answer = await _ask_llm(prompt=dialogue, system=sys_chef)
        history.append({"role": "model", "text": answer})
        await state.update_data(history=history[-20:])
        await msg.delete()
        await message.answer(f"👨‍🍳 {answer}")
    except Exception as e:
        log.error("chef_chat: %s", e)
        try:
            await msg.delete()
        except Exception:
            pass
        await message.answer("❌ Шеф сейчас занят, попробуй позже")


# ── Назад ────────────────────────────────────────────────
# ── Рецепт от Пухляша ──────────────────────────────────────

@router.message(F.text == "🍝 Рецепт от Пухляша")
async def btn_puhlyash_recipe(message: Message, state: FSMContext):
    import asyncio
    import aiosqlite
    from database import DB_PATH
    from modules.puhlyash.persona import generate_puhlyash_recipe, format_puhlyash_message
    msg = await message.answer("🍝 Пухляш думает...", reply_markup=main_kb())
    try:
        tg_id = str(message.from_user.id)
        profile = {}
        async with aiosqlite.connect(DB_PATH, timeout=30) as db:
            db.row_factory = aiosqlite.Row
            async with db.execute("SELECT * FROM user_profiles WHERE tg_id=?", (tg_id,)) as c:
                row = await c.fetchone()
            if row:
                profile = dict(row)
        recipe = await asyncio.wait_for(
            generate_puhlyash_recipe(profile=profile), timeout=45
        )
        text = format_puhlyash_message(recipe)
        await msg.delete()
        from modules.reactions.engine import reaction_kb
        rid = recipe.get("id", "")
        await _save(recipe)
        await message.answer(text, parse_mode="HTML",
                             reply_markup=reaction_kb("recipe", rid) if rid else main_kb())
        if rid:
            await message.answer("👇 Как тебе?", reply_markup=main_kb())
    except asyncio.TimeoutError:
        await message.answer("❌ Пухляш задумался... Попробуй ещё раз!")
    except Exception as e:
        log.error("puhlyash recipe: %s", e)
        await message.answer(f"❌ {e}")


@router.message(F.text == "🔙 Назад")
async def btn_back(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Главное меню", reply_markup=main_kb())
````

---

## Файл: bot_handlers/schedule.py

`7019 байт`

````
"""Bot handler: настройка расписания питания."""
import re
import aiosqlite
from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from building_blocks.logger import get_logger
from database import DB_PATH
from modules.scheduler.meal_scheduler import reschedule_user

log = get_logger(__name__)
router = Router()

TIME_RE = re.compile(r'^([01]?\d|2[0-3]):([0-5]\d)$')


class ScheduleStates(StatesGroup):
    breakfast = State()
    lunch = State()
    dinner = State()
    confirm = State()


def _main_kb():
    from bot_handlers.recipes import main_kb
    return main_kb()


def _skip_kb():
    return ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="⏭️ Пропустить")],
        [KeyboardButton(text="❌ Отмена")],
    ], resize_keyboard=True)


@router.message(F.text.in_(["⏰ Расписание", "/schedule"]))
async def cmd_schedule(message: Message, state: FSMContext):
    tg_id = str(message.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT meal_breakfast, meal_lunch, meal_dinner FROM user_profiles WHERE tg_id=?",
            (tg_id,)
        ) as cur:
            row = await cur.fetchone()

    current = ""
    if row:
        b = row["meal_breakfast"] or "—"
        l = row["meal_lunch"] or "—"
        d = row["meal_dinner"] or "—"
        current = f"\n\nТекущее: Завтрак {b} | Обед {l} | Ужин {d}"

    await state.set_state(ScheduleStates.breakfast)
    await message.answer(
        f"⏰ <b>Настройка расписания питания</b>{current}\n\n"
        "🌅 В какое время завтрак?\n"
        "Напиши время в формате <code>08:30</code> или пропусти",
        parse_mode="HTML", reply_markup=_skip_kb()
    )


def _validate_time(text: str) -> str | None:
    text = text.strip().replace(".", ":")
    if TIME_RE.match(text):
        h, m = text.split(":")
        return f"{int(h):02d}:{int(m):02d}"
    return None


@router.message(ScheduleStates.breakfast)
async def got_breakfast(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        await message.answer("Отменено", reply_markup=_main_kb())
        return
    t = None if message.text == "⏭️ Пропустить" else _validate_time(message.text)
    if message.text != "⏭️ Пропустить" and t is None:
        await message.answer("Формат: <code>08:30</code>", parse_mode="HTML")
        return
    await state.update_data(breakfast=t)
    await state.set_state(ScheduleStates.lunch)
    await message.answer(
        "🍽 Обед — в которое время?\n"
        "Например: <code>13:00</code> или пропусти",
        parse_mode="HTML", reply_markup=_skip_kb()
    )


@router.message(ScheduleStates.lunch)
async def got_lunch(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        await message.answer("Отменено", reply_markup=_main_kb())
        return
    t = None if message.text == "⏭️ Пропустить" else _validate_time(message.text)
    if message.text != "⏭️ Пропустить" and t is None:
        await message.answer("Формат: <code>13:00</code>", parse_mode="HTML")
        return
    await state.update_data(lunch=t)
    await state.set_state(ScheduleStates.dinner)
    await message.answer(
        "🌙 Ужин — время?\nНапример: <code>19:00</code> или пропусти",
        parse_mode="HTML", reply_markup=_skip_kb()
    )


@router.message(ScheduleStates.dinner)
async def got_dinner(message: Message, state: FSMContext):
    if message.text == "❌ Отмена":
        await state.clear()
        await message.answer("Отменено", reply_markup=_main_kb())
        return
    t = None if message.text == "⏭️ Пропустить" else _validate_time(message.text)
    if message.text != "⏭️ Пропустить" and t is None:
        await message.answer("Формат: <code>19:00</code>", parse_mode="HTML")
        return
    data = await state.get_data()
    data["dinner"] = t
    await state.update_data(dinner=t)

    b = data.get("breakfast") or "—"
    l = data.get("lunch") or "—"
    d = data.get("dinner") or "—"

    kb = ReplyKeyboardMarkup(keyboard=[
        [KeyboardButton(text="✅ Сохранить"), KeyboardButton(text="❌ Отмена")]
    ], resize_keyboard=True)

    await state.set_state(ScheduleStates.confirm)
    await message.answer(
        f"⏰ <b>Расписание:</b>\n"
        f"🌅 Завтрак: {b}\n"
        f"🍽 Обед: {l}\n"
        f"🌙 Ужин: {d}\n\n"
        "Буду слать рецепт + упражнения в это время. Сохранить?",
        parse_mode="HTML", reply_markup=kb
    )


@router.message(ScheduleStates.confirm, F.text == "✅ Сохранить")
async def confirm_schedule(message: Message, state: FSMContext):
    data = await state.get_data()
    tg_id = str(message.from_user.id)
    b = data.get("breakfast")
    l = data.get("lunch")
    d = data.get("dinner")
    await state.clear()

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "INSERT INTO user_profiles (tg_id, meal_breakfast, meal_lunch, meal_dinner, notifications_enabled) "
            "VALUES (?,?,?,?,1) ON CONFLICT(tg_id) DO UPDATE SET "
            "meal_breakfast=excluded.meal_breakfast, meal_lunch=excluded.meal_lunch, "
            "meal_dinner=excluded.meal_dinner, notifications_enabled=1",
            (tg_id, b, l, d)
        )
        await db.commit()

    await reschedule_user(tg_id, b or "", l or "", d or "")
    await message.answer(
        "✅ <b>Расписание сохранено!</b>\n"
        "Буду слать рецепт и упражнения перед каждым приёмом пищи ❤️",
        parse_mode="HTML", reply_markup=_main_kb()
    )


@router.message(ScheduleStates.confirm, F.text == "❌ Отмена")
async def cancel_schedule(message: Message, state: FSMContext):
    await state.clear()
    await message.answer("Отменено", reply_markup=_main_kb())


@router.message(F.text == "🔕 Пауза уведомлений")
async def pause_notifications(message: Message):
    tg_id = str(message.from_user.id)
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute(
            "UPDATE user_profiles SET notifications_enabled=0 WHERE tg_id=?", (tg_id,)
        )
        await db.commit()
    await message.answer("🔕 Уведомления пауза. Включить: /schedule", reply_markup=_main_kb())
````

---

## Файл: building_blocks/config.py

`3491 байт`

````
"""Config: pydantic-settings для всего проекта."""
from pydantic_settings import BaseSettings
from pydantic import Field
from functools import lru_cache


class Settings(BaseSettings):
    # App
    app_host: str = "0.0.0.0"
    app_port: int = 8150
    debug: bool = False

    # DB
    database_path: str = "/opt/diet_platform/diet_platform.db"

    # Gemini
    gemini_api_key: str = ""
    gemini_keys: str = ""  # comma-separated pool
    gemini_model: str = "gemini-3.1-flash-lite"

    # Telegram
    telegram_bot_token: str = ""

    # Userbot Relay (den4ik-claude) — см. CONFLICT-01 в TEAM_NOTES.md
    userbot_relay_token: str = ""

    # Search
    serpapi_key: str = ""
    max_urls_per_query: int = 5
    search_cache_ttl_hours: int = 24

    # Scraper
    scraper_timeout_seconds: int = 15
    scraper_max_retries: int = 3
    scraper_user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )

    # Worker
    worker_poll_interval_seconds: int = 3
    worker_max_concurrent: int = 3

    # Registry
    min_confidence_score: float = 0.15
    auto_publish_threshold: float = 0.75

    # Vault (Secrets Vault integration)
    vault_url: str = "http://127.0.0.1:8400"
    vault_api_key: str = ""
    vault_project_id: str = "diet_platform"
    vault_enabled: bool = True  # загружать секреты из Vault

    class Config:
        env_file = "/opt/diet_platform/.env"
        env_file_encoding = "utf-8"
        extra = "ignore"

    def load_vault_secrets(self) -> dict[str, str]:
        """Загрузить секреты из Vault и вернуть как dict."""
        if not self.vault_enabled:
            return {}
        try:
            from building_blocks.vault_integration import VaultSecretLoader
            vault = VaultSecretLoader(
                vault_url=self.vault_url,
                project_id=self.vault_project_id,
                api_key=self.vault_api_key or None,
            )
            secrets = vault.load_all()
            vault.close()
            return secrets
        except Exception as e:
            import logging
            logging.getLogger("diet_platform.config").warning(
                "Vault secrets load failed: %s", e
            )
            return {}

    def apply_vault_overrides(self):
        """Перезаписать поля из Vault (vault-значения приоритетнее .env)."""
        vault_secrets = self.load_vault_secrets()
        if not vault_secrets:
            return
        for key, val in vault_secrets.items():
            # Маппинг env-имён в snake_case поля Settings
            field_map = {
                "GEMINI_API_KEY": "gemini_api_key",
                "GEMINI_KEYS": "gemini_keys",
                "GEMINI_MODEL": "gemini_model",
                "TELEGRAM_BOT_TOKEN": "telegram_bot_token",
                "USERBOT_RELAY_TOKEN": "userbot_relay_token",
                "SERPAPI_KEY": "serpapi_key",
                "DATABASE_PATH": "database_path",
                "VAULT_API_KEY": "vault_api_key",
            }
            field = field_map.get(key, key.lower())
            if hasattr(self, field) and val:
                setattr(self, field, val)


@lru_cache()
def get_settings() -> Settings:
    s = Settings()
    s.apply_vault_overrides()  # vault перезаписывает .env
    return s
````

---

## Файл: building_blocks/contracts.py

`2479 байт`

````
"""Shared Kernel: неизменяемые контракты обмена между модулями."""
from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional
import uuid


class PipelineStatus(str, Enum):
    CREATED = "created"
    SEARCHING = "searching"
    SCRAPING = "scraping"
    EXTRACTING = "extracting"
    REGISTERING = "registering"
    COMPLETED = "completed"
    FAILED = "failed"
    POSTPONED = "postponed"


class DietStatus(str, Enum):
    DRAFT = "draft"
    PENDING_VERIFICATION = "pending_verification"
    APPROVED = "approved"
    FLAGGED = "flagged"
    ARCHIVED = "archived"


class FetchFailReason(str, Enum):
    SECURITY_VIOLATION = "security_violation"
    TIMEOUT = "timeout"
    HTTP_ERROR = "http_error"
    PARSE_ERROR = "parse_error"
    EMPTY_CONTENT = "empty_content"
    MAX_RETRIES_EXCEEDED = "max_retries_exceeded"


@dataclass(frozen=True)
class SearchUrlsDiscoveredEvent:
    session_id: str
    trace_id: str
    query_text: str
    urls: list
    discovered_at: datetime = field(default_factory=datetime.utcnow)


@dataclass(frozen=True)
class ContentFetchedEvent:
    task_id: str
    session_id: str
    trace_id: str
    source_url: str
    raw_cleaned_text: str
    content_sha256: str
    scraped_at: datetime = field(default_factory=datetime.utcnow)
    http_status: int = 200
    content_length: int = 0


@dataclass(frozen=True)
class ContentFetchFailedEvent:
    task_id: str
    session_id: str
    trace_id: str
    source_url: str
    reason: FetchFailReason
    attempt: int
    failed_at: datetime = field(default_factory=datetime.utcnow)


@dataclass(frozen=True)
class SubmitDietDraftCommand:
    draft_id: str
    session_id: str
    trace_id: str
    source_url: str
    content_sha256: str
    diet_name: str
    allowed_foods: list
    forbidden_foods: list
    menu_structure: dict
    contraindications: list
    conditions: list
    confidence_score: float
    raw_text_excerpt: str
    extracted_at: datetime = field(default_factory=datetime.utcnow)


@dataclass(frozen=True)
class DietMasterPublishedEvent:
    diet_id: str
    session_id: str
    trace_id: str
    diet_name: str
    status: DietStatus
    version: int
    published_at: datetime = field(default_factory=datetime.utcnow)


def new_trace_id() -> str:
    return str(uuid.uuid4())


def new_session_id() -> str:
    return str(uuid.uuid4())
````

---

## Файл: building_blocks/logger.py

`1257 байт`

````
"""Logger с Correlation ID поддержкой."""
import logging
import sys
from contextvars import ContextVar
from typing import Optional

_trace_id_var: ContextVar[str] = ContextVar("trace_id", default="-")
_session_id_var: ContextVar[str] = ContextVar("session_id", default="-")


def set_trace_context(trace_id: str, session_id: str = "-") -> None:
    _trace_id_var.set(trace_id)
    _session_id_var.set(session_id)


def get_trace_id() -> str:
    return _trace_id_var.get()


class CorrelationFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.trace_id = _trace_id_var.get()
        record.session_id = _session_id_var.get()
        return True


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] [trace=%(trace_id)s] "
            "[session=%(session_id)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        handler.addFilter(CorrelationFilter())
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger
````

---

## Файл: building_blocks/vault_integration.py

`3388 байт`

````
"""Vault Integration — подключение diet_platform к Secrets Vault.

Использует универсальный VaultClient из vault_client_v2.
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, Optional

import sys
sys.path.insert(0, "/opt/secrets_vault/client")

from vault_client_v2 import VaultClient as _VaultClient

logger = logging.getLogger("diet_platform.vault")

VAULT_URL = os.getenv("VAULT_URL", "http://127.0.0.1:8400")
PROJECT_ID = os.getenv("VAULT_PROJECT_ID", "diet_platform")
API_KEY = os.getenv("VAULT_API_KEY", "lev_-nvEajzVSG9F3rxoBA7ltGctDYbW05L8")


class VaultSecretLoader:
    """Загрузчик секретов из Vault (обёртка над VaultClient)."""

    def __init__(
        self,
        vault_url: str = VAULT_URL,
        project_id: str = PROJECT_ID,
        api_key: str = API_KEY,
    ):
        self._client = _VaultClient(
            vault_url=vault_url,
            project_id=project_id,
            api_key=api_key,
        )

    # ── делегирование VaultClient ──

    @property
    def vault_url(self) -> str:
        return self._client.vault_url

    @property
    def project_id(self) -> str:
        return self._client.project_id or ""

    def get_secret(self, key_name: str) -> Optional[str]:
        return self._client.get_secret(key_name)

    def load_all(self) -> Dict[str, str]:
        return self._client.load_all()

    def list_secrets(self) -> Dict[str, Any]:
        """Возвращает имена ключей как dict (для совместимости)."""
        keys = self._client.list_keys()
        return {k: {} for k in keys}

    def set_secret(self, key_name: str, value: str) -> bool:
        return self._client.set_secret(key_name, value)

    def set_secrets_batch(self, secrets: Dict[str, str]) -> int:
        return self._client.set_secrets_batch(secrets)

    def health(self) -> bool:
        return self._client.health()

    def close(self):
        self._client.close()

    # ── миграция ──

    def migrate_from_env(
        self,
        env_path: str = "/opt/diet_platform/.env",
        keys: Optional[list[str]] = None,
    ) -> int:
        """Мигрировать секреты из .env файла в Vault."""
        if keys is None:
            keys = [
                "GEMINI_API_KEY", "GEMINI_KEYS", "GEMINI_MODEL",
                "TELEGRAM_BOT_TOKEN", "USERBOT_RELAY_TOKEN",
                "SERPAPI_KEY", "VAULT_API_KEY",
            ]

        path = Path(env_path)
        if not path.exists():
            logger.warning(".env not found at %s", env_path)
            return 0

        secrets: Dict[str, str] = {}
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip("\"'")
            if key in keys and val:
                secrets[key] = val

        if not secrets:
            logger.info("No secrets to migrate from .env")
            return 0

        saved = self.set_secrets_batch(secrets)
        logger.info("Migrated %d/%d secrets to Vault", saved, len(secrets))
        return saved

````

---

## Файл: database.py

`5014 байт`

````
"""SQLite schema + migrations. Transactional Outbox pattern."""
import aiosqlite
from building_blocks.config import get_settings
from building_blocks.logger import get_logger

log = get_logger(__name__)
DB_PATH = get_settings().database_path


SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- Search sessions (SearchQuery aggregate)
CREATE TABLE IF NOT EXISTS search_sessions (
    id TEXT PRIMARY KEY,
    trace_id TEXT NOT NULL,
    query_text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'created',
    user_id TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now')),
    error_message TEXT
);

-- Transactional Outbox (pipeline queue)
CREATE TABLE IF NOT EXISTS outbox (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    trace_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    attempt INTEGER NOT NULL DEFAULT 0,
    max_attempts INTEGER NOT NULL DEFAULT 3,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    scheduled_at TEXT NOT NULL DEFAULT (datetime('now')),
    processed_at TEXT,
    error TEXT
);

-- Dead Letter Queue
CREATE TABLE IF NOT EXISTS dlq (
    id TEXT PRIMARY KEY,
    outbox_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    trace_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    payload TEXT NOT NULL,
    reason TEXT NOT NULL,
    failed_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Web page snapshots
CREATE TABLE IF NOT EXISTS web_snapshots (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    trace_id TEXT NOT NULL,
    source_url TEXT NOT NULL,
    content_sha256 TEXT NOT NULL,
    raw_text_length INTEGER NOT NULL DEFAULT 0,
    http_status INTEGER NOT NULL DEFAULT 200,
    scraped_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Diet drafts
CREATE TABLE IF NOT EXISTS diet_drafts (
    id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    trace_id TEXT NOT NULL,
    source_url TEXT NOT NULL,
    content_sha256 TEXT NOT NULL,
    diet_name TEXT NOT NULL,
    confidence_score REAL NOT NULL DEFAULT 0.0,
    raw_payload TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Diet master (source of truth)
CREATE TABLE IF NOT EXISTS diet_master (
    id TEXT PRIMARY KEY,
    session_id TEXT,
    trace_id TEXT,
    source_url TEXT,
    content_sha256 TEXT UNIQUE,
    diet_name TEXT NOT NULL,
    allowed_foods TEXT NOT NULL DEFAULT '[]',
    forbidden_foods TEXT NOT NULL DEFAULT '[]',
    menu_structure TEXT NOT NULL DEFAULT '{}',
    contraindications TEXT NOT NULL DEFAULT '[]',
    conditions TEXT NOT NULL DEFAULT '[]',
    confidence_score REAL NOT NULL DEFAULT 0.0,
    status TEXT NOT NULL DEFAULT 'pending_verification',
    version INTEGER NOT NULL DEFAULT 1,
    is_verified INTEGER NOT NULL DEFAULT 0,
    verified_by TEXT,
    verified_at TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Audit log
CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    action TEXT NOT NULL,
    actor TEXT NOT NULL DEFAULT 'system',
    old_value TEXT,
    new_value TEXT,
    trace_id TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_outbox_status_scheduled
    ON outbox(status, scheduled_at);
CREATE INDEX IF NOT EXISTS idx_diet_master_status
    ON diet_master(status);
CREATE INDEX IF NOT EXISTS idx_diet_master_name
    ON diet_master(diet_name);
CREATE INDEX IF NOT EXISTS idx_sessions_status
    ON search_sessions(status);
"""


async def init_db() -> None:
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.executescript(SCHEMA)
        await db.commit()
    log.info("Database initialized: %s", DB_PATH)


async def get_db():
    """Async context manager for DB connection."""
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        yield db
# v2: Recipes
RECIPES_SCHEMA = """
CREATE TABLE IF NOT EXISTS recipes (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    mode TEXT NOT NULL,           -- quick/home/restaurant/pp
    description TEXT,
    ingredients TEXT NOT NULL,    -- JSON list
    steps TEXT NOT NULL,          -- JSON list
    calories_per_serving INTEGER,
    protein_g REAL,
    fat_g REAL,
    carbs_g REAL,
    cook_time_minutes INTEGER,
    servings INTEGER DEFAULT 2,
    tags TEXT,                    -- JSON list
    source TEXT DEFAULT 'gemini',
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS fridge_sessions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    ingredients TEXT NOT NULL,    -- JSON list
    recipe_id TEXT,
    status TEXT DEFAULT 'pending',
    created_at TEXT DEFAULT (datetime('now'))
);
"""

````

---

## Файл: database_migration_v2.sql

`1329 байт`

````
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS user_profiles (
    tg_id TEXT PRIMARY KEY,
    name TEXT, age INTEGER, gender TEXT,
    weight_kg REAL, height_cm REAL, goal TEXT,
    health_notes TEXT, location TEXT,
    cuisine_prefs TEXT DEFAULT '[]',
    excluded_foods TEXT DEFAULT '[]',
    track_cycle INTEGER DEFAULT 0,
    cycle_start_date TEXT, cycle_length_days INTEGER DEFAULT 28,
    email TEXT, phone TEXT,
    onboarding_done INTEGER DEFAULT 0,
    onboarding_step TEXT DEFAULT 'start',
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS recipe_sessions (
    id TEXT PRIMARY KEY, tg_id TEXT NOT NULL,
    mode TEXT NOT NULL, request_text TEXT NOT NULL,
    result_json TEXT, status TEXT DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS shopping_lists (
    id TEXT PRIMARY KEY, tg_id TEXT NOT NULL,
    recipe_session_id TEXT,
    items_json TEXT NOT NULL DEFAULT '[]',
    budget REAL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_user_profiles_tg ON user_profiles(tg_id);
CREATE INDEX IF NOT EXISTS idx_recipe_sessions_tg ON recipe_sessions(tg_id);
CREATE INDEX IF NOT EXISTS idx_shopping_tg ON shopping_lists(tg_id);

````

---

## Файл: dump_project.sh

`3319 байт`

````
#!/usr/bin/env bash
# ============================================================
# dump_project.sh — собирает проект в один Markdown-дамп
# Использование:
#   bash dump_project.sh [путь_к_проекту] [путь_к_выходному_md]
# ============================================================
set -u

PROJECT_DIR="${1:-/storage/emulated/0/PROJECTS/workstation/freebuff/projects_17/diet_platform}"
OUT="${2:-$PROJECT_DIR/PROJECT_DUMP.md}"
MAX_SIZE=150000   # файлы крупнее (байт) идут только в список, без содержимого

# текстовые расширения, которые попадают в дамп
EXTS='md|txt|html|htm|css|scss|js|mjs|cjs|ts|tsx|jsx|json|py|sh|bash|yml|yaml|xml|svg|toml|ini|cfg|conf|log|csv|sql|kt|java|dart|php|rb|go|rs|ipynb'
# файлы без расширения / dotfiles, которые тоже считаем текстом
NAMES='Makefile|Dockerfile|LICENSE|Procfile|\.gitignore|\.gitattributes|\.editorconfig|\.env|\.env\..*'
# директории-мусор, которые пропускаем
EXCLUDE='/(node_modules|\.git|__pycache__|\.venv|venv|dist|build|\.idea|\.vscode|\.cache|__MACOSX|\.dart_tool)/'

TMP_SKIPPED=$(mktemp)
trap 'rm -f "$TMP_SKIPPED"' EXIT

rel(){ echo "${1#"$PROJECT_DIR"/}"; }

# ---------- заголовок + дерево файлов ----------
{
  echo "# Дамп проекта: $(basename "$PROJECT_DIR")"
  echo
  echo "> Собран: $(date '+%Y-%m-%d %H:%M:%S')"
  echo
  echo "## Дерево файлов"
  echo '````text'
} > "$OUT"

find "$PROJECT_DIR" -type f 2>/dev/null | grep -vE "$EXCLUDE" | sort \
  | while IFS= read -r f; do printf '%s\n' "$(rel "$f")"; done >> "$OUT"

echo '````' >> "$OUT"

# ---------- содержимое текстовых файлов ----------
COUNT=0
while IFS= read -r f; do
  [ -e "$f" ] || continue
  [ "$f" = "$OUT" ] && continue
  r=$(rel "$f")
  base=$(basename "$f")
  ext="${base##*.}"; [ "$ext" = "$base" ] && ext=""
  size=$(wc -c < "$f" 2>/dev/null | tr -d ' ')

  want=0
  echo "$ext"  | grep -qE "^($EXTS)$"  && want=1
  echo "$base" | grep -qE "^($NAMES)$" && want=1

  if [ "$want" = 0 ]; then
    echo "- \`$r\` — медиа/бинарный, $size байт" >> "$TMP_SKIPPED"; continue
  fi
  if [ "$size" -gt "$MAX_SIZE" ]; then
    echo "- \`$r\` — слишком большой, $size байт" >> "$TMP_SKIPPED"; continue
  fi
  if ! grep -qI . "$f" 2>/dev/null; then
    echo "- \`$r\` — бинарный, $size байт" >> "$TMP_SKIPPED"; continue
  fi

  {
    echo; echo "---"; echo
    echo "## Файл: $r"
    echo
    echo "\`$size байт\`"
    echo
    echo '````'
    cat "$f"
    echo
    echo '````'
  } >> "$OUT"
  COUNT=$((COUNT+1))
done < <(find "$PROJECT_DIR" -type f 2>/dev/null | grep -vE "$EXCLUDE" | sort)

# ---------- список пропущенных ----------
{
  echo; echo "---"; echo
  echo "## Пропущенные файлы (медиа/бинарные/крупные)"
  echo
  if [ -s "$TMP_SKIPPED" ]; then cat "$TMP_SKIPPED"; else echo "- нет"; fi
} >> "$OUT"

echo
echo "✅ Готово: $OUT"
echo "   Файлов с содержимым: $COUNT"
echo "   Размер дампа: $(wc -c < "$OUT" | tr -d ' ') байт"
````

---

## Файл: main.py

`1331 байт`

````
"""App bootstrap: FastAPI + Telegram Bot + Worker в одном процессе."""
import asyncio
import sys
import os

sys.path.insert(0, "/opt/diet_platform")

from building_blocks.config import get_settings
from building_blocks.logger import get_logger

log = get_logger("bootstrap")
cfg = get_settings()


async def main():
    import uvicorn
    from modules.delivery_api.controllers.api import app

    tasks = []

    # FastAPI
    config = uvicorn.Config(
        app,
        host=cfg.app_host,
        port=cfg.app_port,
        log_level="info",
        access_log=True,
    )
    server = uvicorn.Server(config)
    tasks.append(asyncio.create_task(server.serve()))

    # Scheduler
    from modules.scheduler.meal_scheduler import start_scheduler, load_all_schedules
    start_scheduler()
    await load_all_schedules()
    log.info("⏰ Scheduler started, jobs loaded")

    # Telegram Bot (optional)
    if cfg.telegram_bot_token:
        from bot import start_bot
        tasks.append(asyncio.create_task(start_bot()))
        log.info("🤖 Telegram bot enabled")
    else:
        log.warning("⚠️ TELEGRAM_BOT_TOKEN not set, bot disabled")

    log.info("🚀 Diet Platform starting on %s:%d", cfg.app_host, cfg.app_port)
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(main())
````

---

## Файл: modules/delivery_api/controllers/api.py

`7815 байт`

````
"""Delivery API: FastAPI REST endpoints.

Read-only. CQRS. Singleflight для защиты от Cache Stampede.
"""
import asyncio
from contextlib import asynccontextmanager
from typing import Optional

import aiosqlite
from fastapi import FastAPI, HTTPException, Query, BackgroundTasks, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from building_blocks.config import get_settings
from building_blocks.contracts import new_trace_id, new_session_id, PipelineStatus
from building_blocks.logger import get_logger, set_trace_context
from database import init_db, DB_PATH
from modules.search_gateway.internal.searcher import initiate_search
from modules.diet_registry.infrastructure.repository import (
    get_diet_by_id, search_diets, verify_diet
)
from workers.pipeline_worker import run_worker_loop

log = get_logger(__name__)
cfg = get_settings()

# Singleflight: ключ -> Future
_singleflight: dict[str, asyncio.Future] = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    log.info("✅ Diet Platform started on port %d", cfg.app_port)
    worker_task = asyncio.create_task(run_worker_loop())
    yield
    worker_task.cancel()
    log.info("⏹ Diet Platform stopped")


app = FastAPI(
    title="Diet Platform API",
    version="1.0.0",
    description="Автоматизированный сбор и выдача медицинских планов питания",
    lifespan=lifespan,
)


class SearchRequest(BaseModel):
    query: str
    user_id: Optional[str] = None


class VerifyRequest(BaseModel):
    approved: bool
    actor: str = "moderator"


@app.get("/health")
async def health():
    return {"status": "ok", "service": "diet-platform", "version": "1.0.0"}


@app.post("/api/v1/search", status_code=202)
async def start_search(req: SearchRequest):
    """
    Async: возвращает session_id немедленно.
    Клиент опрашивает /api/v1/sessions/{id} для статуса.
    """
    if not req.query or len(req.query.strip()) < 2:
        raise HTTPException(status_code=400, detail="Query too short")
    if len(req.query) > 500:
        raise HTTPException(status_code=400, detail="Query too long")

    trace_id = new_trace_id()
    set_trace_context(trace_id)

    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        session_id = await initiate_search(db, req.query.strip(), req.user_id)

    return {
        "session_id": session_id,
        "trace_id": trace_id,
        "status": "accepted",
        "message": "Запрос принят. Опрашивайте /api/v1/sessions/{session_id} для статуса.",
    }


@app.get("/api/v1/sessions/{session_id}")
async def get_session_status(session_id: str):
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM search_sessions WHERE id=?", (session_id,)
        ) as cur:
            row = await cur.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Session not found")

        async with db.execute(
            "SELECT status, COUNT(*) as cnt FROM outbox WHERE session_id=? GROUP BY status",
            (session_id,)
        ) as cur:
            stats = {r["status"]: r["cnt"] for r in await cur.fetchall()}

    return {
        "session_id": session_id,
        "status": row["status"],
        "query": row["query_text"],
        "created_at": row["created_at"],
        "tasks": stats,
    }


@app.get("/api/v1/diets")
async def list_diets(
    q: Optional[str] = Query(None, max_length=200),
    status: str = Query("approved"),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    # Singleflight для защиты от Cache Stampede
    cache_key = f"diets:{q}:{status}:{limit}:{offset}"
    if cache_key in _singleflight:
        return await _singleflight[cache_key]

    fut = asyncio.get_event_loop().create_future()
    _singleflight[cache_key] = fut

    try:
        async with aiosqlite.connect(DB_PATH, timeout=30) as db:
            db.row_factory = aiosqlite.Row
            diets = await search_diets(db, query=q or "", status=status,
                                       limit=limit, offset=offset)
        result = {"items": diets, "count": len(diets)}
        fut.set_result(result)
        return result
    except Exception as e:
        fut.set_exception(e)
        raise
    finally:
        _singleflight.pop(cache_key, None)


@app.get("/api/v1/diets/{diet_id}")
async def get_diet(diet_id: str):
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        diet = await get_diet_by_id(db, diet_id)
    if not diet:
        raise HTTPException(status_code=404, detail="Diet not found")
    return diet


@app.post("/api/v1/diets/{diet_id}/verify")
async def verify_diet_endpoint(diet_id: str, req: VerifyRequest):
    """Moderator endpoint: одобрение/отклонение диеты."""
    trace_id = new_trace_id()
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        ok = await verify_diet(db, diet_id, req.approved, req.actor, trace_id)
    if not ok:
        raise HTTPException(status_code=409, detail="Version conflict or diet not found")
    return {"ok": True, "diet_id": diet_id, "approved": req.approved}


@app.get("/api/v1/pending")
async def list_pending(
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    """Moderation queue: диеты на проверке."""
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        diets = await search_diets(db, status="pending_verification",
                                   limit=limit, offset=offset)
    return {"items": diets, "count": len(diets)}


@app.get("/api/v1/dlq")
async def list_dlq(limit: int = Query(20, ge=1, le=100)):
    """DLQ: необработанные задачи для инженеров."""
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM dlq ORDER BY failed_at DESC LIMIT ?", (limit,)
        ) as cur:
            rows = await cur.fetchall()
    return {"items": [dict(r) for r in rows], "count": len(rows)}




@app.post("/api/v1/dlq/retry-all")
async def retry_dlq_all():
    """DLQ Retry Dashboard: возвращает все DLQ-задачи в pending."""
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM dlq") as cur:
            items = await cur.fetchall()
        count = 0
        for item in items:
            d = dict(item)
            # Возвращаем в outbox с обнулённым attempt
            await db.execute(
                "UPDATE outbox SET status='pending', attempt=0, error=NULL, "
                "scheduled_at=datetime('now') WHERE id=?",
                (d["outbox_id"],)
            )
            count += 1
        await db.commit()
    return {"retried": count}


@app.delete("/api/v1/dlq/{dlq_id}")
async def delete_dlq_item(dlq_id: str):
    """DLQ: удалить запись вручную."""
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        await db.execute("DELETE FROM dlq WHERE id=?", (dlq_id,))
        await db.commit()
    return {"ok": True, "deleted": dlq_id}
# Cabinet web UI
from api.cabinet_router import router as cabinet_router  # noqa
app.include_router(cabinet_router)

# Mini App
from api.miniapp_router import router as miniapp_router  # noqa
app.include_router(miniapp_router)
````

---

## Файл: modules/diet_extractor/engine/gemini_extractor.py

`8529 байт`

````
"""Diet Extractor: ядро Leviathan LLMFactory (gemini-3.1-flash-lite, KeyPool, CircuitBreaker) + fallback.

Подключён к /opt/leviathan_engine/llm_factory.py — использует KeyPool с 14 ключами,
CircuitBreaker и авто-фоллбэк на Groq при исчерпании Gemini.
Агент управляет Diet Platform; Diet Platform агентом не пользуется.
"""
import json
import re
import sys
import uuid
from typing import Optional

# Путь к ядру Leviathan — приоритетный import
sys.path.insert(0, "/opt/leviathan_engine")
try:
    from llm_factory import LLMFactory
    _LEVIATHAN_CORE = True
except ImportError:
    _LEVIATHAN_CORE = False

from building_blocks.config import get_settings
from building_blocks.contracts import SubmitDietDraftCommand
from building_blocks.logger import get_logger
from modules.diet_extractor.sanitizer.text_sanitizer import sanitize_text

log = get_logger(__name__)
cfg = get_settings()

if _LEVIATHAN_CORE:
    log.info("🔗 Leviathan LLMFactory (gemini-3.1-flash-lite, KeyPool 14 ключей) подключён")
else:
    log.warning("⚠️ LLMFactory недоступен, fallback на google.genai")

MODEL = "gemini-3.1-flash-lite"

EXTRACTION_SYSTEM = """\
Ты — медицинский NLP-парсер диет и планов питания.
ВОЗВРАЩАЙ ТОЛЬКО ВАЛИДНЫЙ JSON БЕЗ ПОЯСНЕНИЙ, БЕЗ МАРКДАУНА.
"""

EXTRACTION_PROMPT = """Извлеки информацию о диете из текста ниже.

Верни только JSON-объект со следующими полями (без пояснений):
diet_name - название диеты (string)
allowed_foods - разрешённые продукты (array of strings)
forbidden_foods - запрещённые продукты (array of strings)
menu_structure - план питания с ключами breakfast, lunch, dinner, snacks (object)
contraindications - медицинские противопоказания (array of strings)
conditions - заболевания/состояния для которых подходит диета (array of strings)
confidence_score - уверенность от 0.0 до 1.0

Правила:
- confidence_score < 0.4 если в тексте недостаточно данных о диете
- Не выдумывай данные которых нет в тексте
- allowed_foods / forbidden_foods — конкретные продукты, не категории

Текст:
{text}
"""


def _heuristic_extract(text: str) -> dict:
    """Fallback: эвристика без LLM."""
    allowed, forbidden = [], []
    for line in text.split("."):
        line = line.strip()
        if any(m in line.lower() for m in ["можно", "разрешено", "рекомендуется"]) and len(line) < 200:
            allowed.append(line[:100])
        elif any(m in line.lower() for m in ["нельзя", "запрещено", "исключить"]) and len(line) < 200:
            forbidden.append(line[:100])
    m = re.search(r"(диета|питание|рацион)\s+([\w\s]{3,40})", text, re.IGNORECASE)
    diet_name = m.group(0)[:50] if m else "Неизвестная диета"
    score = min(0.35, (len(allowed) + len(forbidden)) * 0.05)
    return {
        "diet_name": diet_name,
        "allowed_foods": allowed[:20],
        "forbidden_foods": forbidden[:20],
        "menu_structure": {"breakfast": [], "lunch": [], "dinner": [], "snacks": []},
        "contraindications": [],
        "conditions": [],
        "confidence_score": score,
    }



def _clean_llm_json(raw: str) -> str:
    """Надёжная очистка LLM-ответа перед json.loads.
    Обрабатывает: leading newlines, markdown blocks, JSON внутри текста.
    """
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?\s*\n?", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\n?\s*```\s*$", "", raw)
    raw = raw.strip()
    if not raw.startswith("{"):
        m = re.search(r"\{[\s\S]*\}", raw)
        if m:
            raw = m.group(0)
    return raw.strip()


async def _llm_extract(clean_text: str, trace_id: str) -> Optional[dict]:
    """LLM экстракция: Leviathan LLMFactory (KeyPool+CB) или fallback google.genai."""
    prompt = EXTRACTION_PROMPT.replace("{text}", clean_text[:8000])

    # ── Приоритет 1: Leviathan Core LLMFactory ──────────────────
    if _LEVIATHAN_CORE:
        try:
            raw = await LLMFactory.execute_request(
                prompt=prompt,
                system=EXTRACTION_SYSTEM,
                model=MODEL,
                driver="gemini",
                fallback=True,
                task_type="structured",
            )
            raw = _clean_llm_json(raw)
            result = json.loads(raw)
            log.info("[%s] Leviathan LLMFactory OK: %s conf=%.2f",
                     trace_id, result.get("diet_name", "?"), result.get("confidence_score", 0))
            return result
        except json.JSONDecodeError as e:
            log.warning("[%s] JSON parse error from LLMFactory: %s", trace_id, e)
            return None
        except Exception as e:
            log.error("[%s] LLMFactory error: %s", trace_id, e)
            # Провалился — падаем на heuristic в extract_diet
            return None

    # ── Fallback: google.genai (direct) ───────────────────────────
    try:
        import itertools
        from google import genai as _genai
        from google.genai import types as _types

        keys: list[str] = []
        raw_keys = getattr(cfg, 'gemini_keys', '') or ''
        for k in raw_keys.split(','):
            k = k.strip()
            if k:
                keys.append(k)
        single = getattr(cfg, 'gemini_api_key', '') or ''
        if single and single not in keys:
            keys.append(single)

        for api_key in keys[:3]:
            try:
                client = _genai.Client(api_key=api_key)
                full_prompt = EXTRACTION_SYSTEM + "\n" + prompt
                response = client.models.generate_content(
                    model=MODEL, contents=full_prompt,
                    config=_types.GenerateContentConfig(temperature=0.1, max_output_tokens=2048),
                )
                raw = response.text.strip()
                raw = _clean_llm_json(raw)
                result = json.loads(raw)
                log.info("[%s] google.genai fallback OK conf=%.2f",
                         trace_id, result.get("confidence_score", 0))
                return result
            except Exception as e:
                if '429' in str(e) or 'RESOURCE_EXHAUSTED' in str(e):
                    continue
                log.error("[%s] google.genai error: %s", trace_id, e)
                break
    except ImportError:
        log.warning("[%s] google.genai not installed", trace_id)

    return None


async def extract_diet(
    raw_text: str, source_url: str, session_id: str,
    trace_id: str, content_sha256: str,
) -> Optional[SubmitDietDraftCommand]:
    clean_text, is_suspicious = sanitize_text(raw_text)
    if is_suspicious:
        log.warning("[%s] Suspicious content, sanitized", trace_id)

    extracted = await _llm_extract(clean_text, trace_id)

    if not extracted:
        log.info("[%s] Using heuristic fallback", trace_id)
        extracted = _heuristic_extract(clean_text)

    confidence = float(extracted.get("confidence_score", 0.0))
    if confidence < cfg.min_confidence_score:
        log.info("[%s] Low confidence %.2f < %.2f, skipping",
                 trace_id, confidence, cfg.min_confidence_score)
        return None

    return SubmitDietDraftCommand(
        draft_id=str(uuid.uuid4()), session_id=session_id, trace_id=trace_id,
        source_url=source_url, content_sha256=content_sha256,
        diet_name=extracted.get("diet_name", "Неизвестная диета")[:200],
        allowed_foods=extracted.get("allowed_foods", [])[:50],
        forbidden_foods=extracted.get("forbidden_foods", [])[:50],
        menu_structure=extracted.get("menu_structure", {}),
        contraindications=extracted.get("contraindications", [])[:30],
        conditions=extracted.get("conditions", [])[:30],
        confidence_score=confidence,
        raw_text_excerpt=clean_text[:500],
    )
````

---

## Файл: modules/diet_extractor/sanitizer/text_sanitizer.py

`2009 байт`

````
"""Data Sanitization Unit: защита от Prompt Injection + PII removal."""
import re
from building_blocks.logger import get_logger

log = get_logger(__name__)

# Паттерны промпт-инъекций
_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(previous|all|prior|above)", re.IGNORECASE),
    re.compile(r"system\s*prompt", re.IGNORECASE),
    re.compile(r"forget\s+(your|all|previous)", re.IGNORECASE),
    re.compile(r"you\s+are\s+now", re.IGNORECASE),
    re.compile(r"забудь|игнорируй|отменяешь", re.IGNORECASE),
    re.compile(r"предыдущие\s+инструкции", re.IGNORECASE),
    re.compile(r"system\s*:", re.IGNORECASE),
    re.compile(r"<\s*/?\s*(system|prompt|instruction)", re.IGNORECASE),
    re.compile(r"\[INST\]|\[/INST\]|<\|im_start\|>", re.IGNORECASE),
]

# PII паттерны
_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")
_PHONE_RE = re.compile(r"(?:\+7|8)[\s\-]?\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}")
_CARD_RE = re.compile(r"\b\d{4}[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b")

# Ограничение длины для LLM
MAX_TOKENS_APPROX = 8000  # ~32k chars


def sanitize_text(text: str) -> tuple[str, bool]:
    """
    Returns (sanitized_text, is_suspicious).
    is_suspicious=True если обнаружены паттерны инъекции.
    """
    is_suspicious = False

    # Проверяем injection patterns
    for pattern in _INJECTION_PATTERNS:
        if pattern.search(text):
            log.warning("Injection pattern detected: %s", pattern.pattern)
            is_suspicious = True
            # Удаляем подозрительные строки
            text = pattern.sub("[REDACTED]", text)

    # PII removal
    text = _EMAIL_RE.sub("[EMAIL]", text)
    text = _PHONE_RE.sub("[PHONE]", text)
    text = _CARD_RE.sub("[CARD]", text)

    # Ограничение длины
    text = text[:MAX_TOKENS_APPROX * 4]

    return text, is_suspicious
````

---

## Файл: modules/diet_registry/domain/medical_guard.py

`2815 байт`

````
"""Medical Dictionary Guard — белый/чёрный список продуктов.

Layer 2 защиты от Data Poisoning (audit finding).
"""

# Опасные вещества / токсины в разрешённых продуктах
DANGEROUS_SUBSTANCES = {
    "мышьяк", "цианид", "арсен", "arsenic", "cyanide", "mercury",
    "ртуть", "свинец", "блекота", "метанол",
    "bleach", "detergent", "turpentine", "gasoline",
}

# Абсолютные противопоказания при диабете (образец)
DIABETES_FORBIDDEN = {
    "сахар", "сахароза", "фруктоза",
}

# Конфликты: заболевание -> продукты, недопустимые в allowed_foods
CRITICAL_CONFLICTS = {
    "диабет": DIABETES_FORBIDDEN,
    "diabetes": DIABETES_FORBIDDEN,
}


def check_dangerous_substances(foods: list) -> list:
    """Returns список опасных продуктов если найдены."""
    found = []
    for food in foods:
        food_lower = food.lower()
        for danger in DANGEROUS_SUBSTANCES:
            if danger in food_lower:
                found.append(food)
                break
    return found


def check_critical_conflicts(conditions: list, allowed_foods: list) -> list:
    """Returns конфликты: [продукт, заболевание]."""
    conflicts = []
    for condition in conditions:
        cond_lower = condition.lower()
        for disease_key, forbidden_set in CRITICAL_CONFLICTS.items():
            if disease_key in cond_lower:
                for food in allowed_foods:
                    if any(f in food.lower() for f in forbidden_set):
                        conflicts.append((food, condition))
    return conflicts


def validate_diet_draft(draft_data: dict) -> tuple[bool, list]:
    """
    Returns (is_valid, issues).
    Должна вернуть False если найдены опасные продукты или конфликты.
    """
    issues = []

    allowed = draft_data.get("allowed_foods", [])
    conditions = draft_data.get("conditions", [])
    diet_name = draft_data.get("diet_name", "")

    # Проверка опасных веществ
    dangerous = check_dangerous_substances(allowed)
    for d in dangerous:
        issues.append(f"DANGEROUS_SUBSTANCE_IN_ALLOWED: {d}")

    # Проверка критических конфликтов
    conflicts = check_critical_conflicts(conditions, allowed)
    for food, condition in conflicts:
        issues.append(f"CONFLICT: '{food}' allowed but condition is '{condition}'")

    # Проверка названия
    if not diet_name or len(diet_name.strip()) < 3:
        issues.append("INVALID_DIET_NAME")

    return len(issues) == 0, issues
````

---

## Файл: modules/diet_registry/infrastructure/repository.py

`6597 байт`

````
"""Diet Core Registry: хранение, валидация, OCC-версионирование, Audit Log."""
import json
import uuid
from datetime import datetime
from typing import Optional
import aiosqlite

from building_blocks.config import get_settings
from building_blocks.contracts import SubmitDietDraftCommand, DietStatus
from building_blocks.logger import get_logger
from modules.diet_registry.domain.medical_guard import validate_diet_draft

log = get_logger(__name__)
cfg = get_settings()


async def register_diet_draft(
    db: aiosqlite.Connection,
    cmd: SubmitDietDraftCommand,
) -> tuple[str, DietStatus]:
    """
    Idempotent: проверяет content_sha256 перед вставкой.
    Returns (diet_id, status).
    """
    # Idempotency: если уже есть — не дублируем
    async with db.execute(
        "SELECT id, status FROM diet_master WHERE content_sha256=?",
        (cmd.content_sha256,)
    ) as cur:
        existing = await cur.fetchone()
    if existing:
        log.info("[%s] Duplicate diet (sha256=%s), skipping", cmd.trace_id, cmd.content_sha256[:8])
        return existing["id"], DietStatus(existing["status"])

    # Medical Guard validation
    draft_data = {
        "diet_name": cmd.diet_name,
        "allowed_foods": cmd.allowed_foods,
        "forbidden_foods": cmd.forbidden_foods,
        "conditions": cmd.conditions,
        "contraindications": cmd.contraindications,
    }
    is_valid, issues = validate_diet_draft(draft_data)

    diet_id = str(uuid.uuid4())
    now = datetime.utcnow().isoformat()

    if not is_valid:
        log.warning("[%s] Diet flagged: %s", cmd.trace_id, issues)
        status = DietStatus.FLAGGED
    elif cmd.confidence_score >= cfg.auto_publish_threshold:
        status = DietStatus.PENDING_VERIFICATION
    else:
        status = DietStatus.PENDING_VERIFICATION

    # Сохраняем DietMaster
    await db.execute(
        """INSERT INTO diet_master(
            id, session_id, trace_id, source_url, content_sha256,
            diet_name, allowed_foods, forbidden_foods, menu_structure,
            contraindications, conditions, confidence_score, status, version
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,1)""",
        (
            diet_id, cmd.session_id, cmd.trace_id, cmd.source_url, cmd.content_sha256,
            cmd.diet_name,
            json.dumps(cmd.allowed_foods, ensure_ascii=False),
            json.dumps(cmd.forbidden_foods, ensure_ascii=False),
            json.dumps(cmd.menu_structure, ensure_ascii=False),
            json.dumps(cmd.contraindications, ensure_ascii=False),
            json.dumps(cmd.conditions, ensure_ascii=False),
            cmd.confidence_score, status.value,
        )
    )

    # Audit log
    await _audit(db, "diet_master", diet_id, "created",
                 new_value=json.dumps({"status": status.value, "issues": issues},
                                      ensure_ascii=False),
                 trace_id=cmd.trace_id)
    await db.commit()

    log.info("[%s] Diet registered: %s (status=%s, confidence=%.2f)",
             cmd.trace_id, diet_id, status.value, cmd.confidence_score)
    return diet_id, status


async def verify_diet(
    db: aiosqlite.Connection,
    diet_id: str,
    approved: bool,
    actor: str = "moderator",
    trace_id: str = "-",
) -> bool:
    """
    Moderator action: одобрение/отклонение диеты.
    OCC: проверяет статус перед обновлением.
    """
    async with db.execute(
        "SELECT id, status, version FROM diet_master WHERE id=?", (diet_id,)
    ) as cur:
        row = await cur.fetchone()
    if not row:
        return False

    old_status = row["status"]
    new_status = DietStatus.APPROVED.value if approved else DietStatus.ARCHIVED.value
    now = datetime.utcnow().isoformat()

    # OCC: обновляем только если version совпадает
    result = await db.execute(
        """UPDATE diet_master SET status=?, version=version+1,
           is_verified=1, verified_by=?, verified_at=?, updated_at=?
           WHERE id=? AND version=?""",
        (new_status, actor, now, now, diet_id, row["version"])
    )
    if result.rowcount == 0:
        log.warning("[%s] OCC conflict on diet %s", trace_id, diet_id)
        return False

    await _audit(db, "diet_master", diet_id, "verified",
                 old_value=old_status, new_value=new_status,
                 actor=actor, trace_id=trace_id)
    await db.commit()
    log.info("[%s] Diet %s -> %s by %s", trace_id, diet_id, new_status, actor)
    return True


async def get_diet_by_id(db: aiosqlite.Connection, diet_id: str) -> Optional[dict]:
    async with db.execute(
        "SELECT * FROM diet_master WHERE id=?", (diet_id,)
    ) as cur:
        row = await cur.fetchone()
    if not row:
        return None
    return _row_to_dict(row)


async def search_diets(
    db: aiosqlite.Connection,
    query: str = "",
    status: str = DietStatus.APPROVED.value,
    limit: int = 20,
    offset: int = 0,
) -> list:
    if query:
        sql = """SELECT * FROM diet_master WHERE status=?
                 AND (diet_name LIKE ? OR conditions LIKE ? OR allowed_foods LIKE ?)
                 ORDER BY confidence_score DESC LIMIT ? OFFSET ?"""
        q = f"%{query}%"
        async with db.execute(sql, (status, q, q, q, min(limit, 100), offset)) as cur:
            rows = await cur.fetchall()
    else:
        sql = "SELECT * FROM diet_master WHERE status=? ORDER BY created_at DESC LIMIT ? OFFSET ?"
        async with db.execute(sql, (status, min(limit, 100), offset)) as cur:
            rows = await cur.fetchall()
    return [_row_to_dict(r) for r in rows]


def _row_to_dict(row: aiosqlite.Row) -> dict:
    d = dict(row)
    for field in ["allowed_foods", "forbidden_foods", "menu_structure",
                  "contraindications", "conditions"]:
        if d.get(field):
            try:
                d[field] = json.loads(d[field])
            except Exception:
                pass
    return d


async def _audit(
    db: aiosqlite.Connection,
    entity_type: str,
    entity_id: str,
    action: str,
    old_value: str = None,
    new_value: str = None,
    actor: str = "system",
    trace_id: str = "-",
) -> None:
    await db.execute(
        """INSERT INTO audit_log(id, entity_type, entity_id, action,
           actor, old_value, new_value, trace_id)
           VALUES(?,?,?,?,?,?,?,?)""",
        (str(uuid.uuid4()), entity_type, entity_id, action,
         actor, old_value, new_value, trace_id)
    )
````

---

## Файл: modules/fitness/engine.py

`3945 байт`

````
"""Fitness Engine — лёгкие упражнения без снарядов через Gemini."""
import json, sys
sys.path.insert(0, "/opt/leviathan_engine")
from building_blocks.logger import get_logger

log = get_logger(__name__)

try:
    from llm_factory import LLMFactory
    _LEVIATHAN_CORE = True
    log.info("🔗 Leviathan LLMFactory подключён в fitness/engine.py")
except ImportError:
    _LEVIATHAN_CORE = False
    log.warning("⚠️ LLMFactory недоступен в fitness/engine.py")

MEAL_CONTEXT = {
    "breakfast": "утренняя офисная разминка до еды, 3-5 минут прямо за столом или рядом, без прыжков",
    "lunch":     "лёгкая растяжка после обеда, 5 минут, сидя или стоя рядом с рабочим местом",
    "dinner":    "вечерняя расслабляющая растяжка дома, 7-10 минут, без нагрузки",
}

DIET_HINTS = {
    "quick":      "лёгкая активация тела, 3-4 простых движения",
    "home":       "умеренная растяжка и дыхание",
    "restaurant": "после обильной еды: только ходьба и дыхание, никакого пресса",
    "pp":         "активация метаболизма: шаги на месте, вращения, наклоны",
}

SYS = """Ты фитнес-тренер, специализируешься на офисной и домашней микро-гимнастике.
Генерируй 3-4 лёгких упражнения:
- Можно делать в офисе или дома, без инвентаря и снарядов
- Без прыжков, рывков, тяжёлой нагрузки
- Подходит людям с разным уровнем подготовки
- Обязательно предупреди если есть ограничения (спина, суставы — делать осторожно)
Отвечай строго в JSON без текста вне JSON:
[{"name":"","description":"как делать, 1-2 предложения","reps":"","duration_sec":30,"caution":""}]"""

FITNESS_MODEL = "gemini-3.1-flash-lite"


async def _gemini(prompt: str) -> str:
    """LLM-вызов через Leviathan LLMFactory (KeyPool + CircuitBreaker + Groq fallback)
    вместо raw urllib + ручной ротации ключей из .env.
    """
    if not _LEVIATHAN_CORE:
        raise RuntimeError("LLMFactory недоступен")
    return await LLMFactory.execute_request(
        prompt=prompt,
        system=SYS,
        model=FITNESS_MODEL,
        driver="gemini",
        fallback=True,
        task_type="structured",
    )


def _parse(raw: str) -> list:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
    return json.loads(raw)


async def generate_exercises(meal: str, diet_mode: str = "home") -> list:
    ctx = MEAL_CONTEXT.get(meal, "лёгкая разминка")
    hint = DIET_HINTS.get(diet_mode, "")
    prompt = f"Контекст: {ctx}. Диета: {hint}. Без инвентаря, без снарядов."
    raw = await _gemini(prompt)
    return _parse(raw)


def format_exercises(exercises: list) -> str:
    lines = ["💪 <b>Разминка (<i>осторожно при проблемах со спиной или суставами</i>):</b>"]
    for i, ex in enumerate(exercises, 1):
        reps = ex.get("reps", "")
        dur = ex.get("duration_sec", "")
        timing = f"{reps}" if reps else f"{dur} сек"
        lines.append(f"{i}. <b>{ex['name']}</b> — {timing}")
        lines.append(f"   {ex.get('description', '')}")
        caution = ex.get("caution", "")
        if caution:
            lines.append(f"   ⚠️ {caution}")
    return "\n".join(lines)
````

---

## Файл: modules/notifier/sender.py

`2739 байт`

````
"""Отправка уведомлений через собственный aiogram-бот diet_platform.

CONFLICT-01 history: раньше diet_platform держал собственный Pyrogram Client на общей
session с den4ik-claude — давало database is locked. Потом перешли на Userbot Relay
(httpx -> Pyrogram внутри den4ik-claude).

2026-06-30: den4ik-claude мигрировал на leviathan_hub_bot.py, который вообще не
использует Pyrogram — решение владельца: userbot больше не нужен вообще.
Уведомления теперь идут через обычный aiogram Bot API собственным токеном diet_platform
(TELEGRAM_BOT_TOKEN из .env) — никакой зависимости от den4ik-claude/Pyrogram больше нет.
Короткоживущий Bot()-инстанс на каждую отправку — стандартная практика aiogram для
одиночных отправок из фоновых задач (scheduler), не связанных с long-polling в bot.py.
"""
import logging

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramAPIError

from building_blocks.config import get_settings

log = logging.getLogger(__name__)
cfg = get_settings()


async def send_notification(tg_id: int | str, text: str) -> bool:
    """Отправляет уведомление через собственный Bot API diet_platform.
    Сигнатура совместима со старым send_notification() — вызывающий код
    (scheduler/meal_scheduler.py и т.д.) не меняется.
    """
    if not cfg.telegram_bot_token:
        log.error("TELEGRAM_BOT_TOKEN не задан в .env, отправка невозможна")
        return False

    bot = Bot(
        token=cfg.telegram_bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    try:
        await bot.send_message(int(tg_id), text[:4096])
        return True
    except TelegramAPIError as e:
        log.warning("Notification send failed for %s: %s", tg_id, e)
        return False
    except Exception as e:
        log.error("Notification send error for %s: %s", tg_id, e)
        return False
    finally:
        await bot.session.close()


async def stop_client() -> None:
    """No-op: каждая отправка сама закрывает свою сессию (см. finally выше).
    Сохранена для совместимости с вызывающим кодом (shutdown hooks).
    """
    return None
````

---

## Файл: modules/puhlyash/irisochka.py

`5167 байт`

````
"""Ирисочка — мышка-помощник Пухляша, диетолог и нутрициолог.

Персонаж: маленькая серая мышка в белом колпаке, умная и заботливая.
Тон: профессиональный, тёплый, иногда мягко поправляет Пухляша.
Назначение:
- Комментарии к рецептам (БЖУ, польза, нюансы)
- Советы по диете с медицинской точки зрения
- «Голос разума» когда Пухляш предлагает что-то жирное
"""
import json
import random
import re
import logging

log = logging.getLogger(__name__)

SYS_IRISOCHKA = """Ты Ирисочка — маленькая серая мышка в белом поварском колпаке, помощник Пухляша и нутрициолог.
Твой характер:
- Умная, заботливая, профессиональная
- Иногда мягко поправляешь Пухляша (но никогда грубо)
- Говоришь коротко, дружелюбно, иногда с маленьким юмором
- Оперируешься фактами (ПжУ, витамины, минералы)
Отвечай 2-3 предложения. На русском. Начинай с "🐭 Ирисочка:"."""

# Комментарии по категориям рецептов
_QUICK_FACTS = [
    "🐭 Ирисочка: Не забывай выпивать стакан воды за 30 минут до еды — это помогает пищеварению!",
    "🐭 Ирисочка: Жуй медленнее — мозг получает сигнал насыщения через 20 минут!",
    "🐭 Ирисочка: Зелень лучше есть свежей — при тепловой обработке теряется до 50% витамина C.",
    "🐭 Ирисочка: Яйцо через день — отличный источник белка без проблем для сердца.",
    "🐭 Ирисочка: Добавь зелёнь в пасту не в конце варки, а прямо на тарелку — сохранишь цвет и витамины!",
    "🐭 Ирисочка: Кефир в маринаде — не только вкусно, но и пробиотики для кишечника.",
    "🐭 Ирисочка: Гречка — чемпион по белку среди круп, и Пухляш это знает!",
]


def get_quick_tip() -> str:
    """Случайный быстрый совет Ирисочки."""
    return random.choice(_QUICK_FACTS)


def _gemini(prompt: str) -> str:
    import urllib.request
    env = open("/opt/leviathan_engine/agent_service/.env").read()
    keys = re.findall(r'GEMINI_K\d+=([^\s]+)', env)
    random.shuffle(keys)
    for key in keys:
        url = ("https://generativelanguage.googleapis.com/v1beta/models/"
               f"gemini-3.1-flash-lite:generateContent?key={key}")
        body = json.dumps({
            "system_instruction": {"parts": [{"text": SYS_IRISOCHKA}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"temperature": 0.6, "maxOutputTokens": 200}
        }).encode()
        try:
            req = urllib.request.Request(
                url, body, {"Content-Type": "application/json"}, method="POST")
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read())["candidates"][0]["content"]["parts"][0]["text"]
        except Exception as e:
            if any(x in str(e) for x in ["403", "429", "503"]):
                continue
            raise
    return get_quick_tip()  # fallback если все ключи заняты


async def comment_recipe(recipe: dict) -> str:
    """Ирисочка комментирует рецепт Gemini."""
    import asyncio
    title = recipe.get("title", "?")
    kcal = recipe.get("calories_per_serving", "?")
    p = recipe.get("protein_g", "?")
    f = recipe.get("fat_g", "?")
    c = recipe.get("carbs_g", "?")
    try:
        ingr = json.loads(recipe.get("ingredients", "[]"))[:5]
    except Exception:
        ingr = []

    prompt = (
        f"Рецепт: {title}. "
        f"ПЖУ: белки {p}г, жиры {f}г, углеводы {c}г, {kcal} ккал. "
        f"Ингредиенты: {', '.join(ingr)}. "
        f"Дай короткий нутриционный комментарий и 1 совет по улучшению."
    )
    return await asyncio.get_running_loop().run_in_executor(None, _gemini, prompt)


async def advise_diet(goal: str, restrictions: str = "") -> str:
    """Ирисочка даёт совет по диете."""
    import asyncio
    prompt = f"Цель: {goal}. Ограничения: {restrictions or 'нет'}. Какой один важный нюанс должен знать человек?"
    return await asyncio.get_running_loop().run_in_executor(None, _gemini, prompt)
````

---

## Файл: modules/puhlyash/persona.py

`8954 байт`

````
"""Пухляш — персонаж и его рецепты с характером."""
import json
import random
import sys
from datetime import datetime
from building_blocks.logger import get_logger

log = get_logger(__name__)

sys.path.insert(0, "/opt/leviathan_engine")
try:
    from llm_factory import LLMFactory
    _LEVIATHAN_CORE = True
except ImportError:
    _LEVIATHAN_CORE = False
    log.warning("LLMFactory недоступен в puhlyash/persona.py")

# Фразы по времени суток
TIME_VIBES = {
    "morning": [
        "Утро доброе! Пухляш уже на кухне — хочется чего-то съесть!",
        "Щёлк, вставать уже пора — зато завтрак будет помогать!",
        "Доброе утро! Накормим тебя перед днём.",
    ],
    "lunch": [
        "Полдень! Желудок уже намекает — пора поесть по-новому!",
        "Обед не за горами — Пухляш уже придумал!",
        "В полдень надо кушать так, чтоб до вечера хватало!",
    ],
    "dinner": [
        "Вечер — время накормить себя за день!",
        "Ужин не за горами — Пухляш знает что приготовить!",
        "Ещё день позади, а вечером вкусно поесть — заслужил!",
    ],
    "night": [
        "Поздно, но Пухляш не спит — давай ясный перекус.",
        "Ночь, а хочется — знаем это чувство!",
    ],
}

# Сезонные / погодные настроения
SEASON_VIBES = [
    "Жарко! Потянуло на что-то лёгкое и освежающее.",
    "Лето в разгаре — значит пора готовить что-то с огорода.",
    "Жара такая, что хочется окрошки и холодного пива.",
    "Горячее лето — самое время для лёгких салатов и окрошек.",
]

# Спонтанные настроения Пухляша

SYS_PUHLYASH = """Ты Пухляш — рыжий кот в фартуке, обычный парень который очень любит поесть вкусно.
Твои рецепты: из простых обычных продуктов из любого супермаркета,
иногда с одной неожиданной деталью, без пармезана и трюфелей.
Тон: дружелюбный, лёгкая самоирония, не подкалываешься — но никогда не грубишь.
Отвечай строго в JSON без текста вне JSON:
{"title":"","description":"","mode":"home","cook_time_minutes":0,"servings":2,
"calories_per_serving":0,"protein_g":0,"fat_g":0,"carbs_g":0,
"ingredients":[],"steps":[],"tags":[]}"""

MOOD_PROMPTS = {
    "sweet":   "Сладкий десерт, построще. Не торт с зеркалами.",
    "comfort": "Сытное домашнее — картошка, гречка, макароны или пильмень.",
    "light":   "Лёгкий салат или закуска — ничего тяжёлого.",
    "spicy":   "Что-то острое, с перцем или чили.",
    "quick":   "На скорую руку, готовится за 10-15 минут.",
    "classic": "Проверенная классика которую все знают.",
    "summer":  "Летнее — окрошка, салат с огорода, газпачо.",
    "special": "Обычное блюдо с одной интересной деталью которая всё меняет.",
}

MOOD_TRIGGERS = [
    ("sweet", "Что-то потянуло на сладкое, поэтому решил приготовить вам —"),
    ("comfort", "Вечер такой, что хочется чего-то домашнего и сытного:"),
    ("light", "Как-то легко стало, поэтому сегодня что-то лёгкое:"),
    ("spicy", "Хочется острого! Думаю, вы меня поймёте —"),
    ("quick", "Некогда не хочется стоять долго у плиты, поэтому быстро:"),
    ("classic", "Иногда лучше проверенное, чем модное. Сегодня:"),
    ("summer", "Жарко, хочется окрошки. Ну и как же Пухляш без сладкого. На десерт —"),
]


def get_time_period() -> str:
    h = datetime.now().hour
    if 6 <= h < 11: return "morning"
    if 11 <= h < 15: return "lunch"
    if 15 <= h < 21: return "dinner"
    return "night"


def get_puhlyash_intro(mood: str | None = None) -> str:
    """Генерирует вступление сообщения от Пухляша."""
    period = get_time_period()
    month = datetime.now().month

    # Лето — больше шанс на летние настроения
    is_summer = month in (6, 7, 8)

    parts = []

    # Временное привет
    parts.append(random.choice(TIME_VIBES.get(period, TIME_VIBES["morning"])))

    # Сезонный триггер (с вероятн. 60% летом)
    if is_summer and random.random() < 0.6:
        parts.append(random.choice(SEASON_VIBES))
    
    # Настроение Пухляша
    if mood:
        trigger = next((t for k, t in MOOD_TRIGGERS if k == mood), None)
        if trigger:
            parts.append(trigger)
    elif random.random() < 0.5:
        parts.append(random.choice(MOOD_TRIGGERS)[1])

    return " ".join(parts)


async def generate_puhlyash_recipe(profile: dict | None = None,
                                    diet_name: str | None = None,
                                    mood: str | None = None) -> dict:
    """Генерирует рецепт Пухляша — независимо от бюджета."""
    from modules.recipes.engine import _parse

    month = datetime.now().month
    is_summer = month in (6, 7, 8)

    if not mood:
        if is_summer:
            mood = random.choice(["summer", "light", "sweet", "special", None, None])
        else:
            mood = random.choice(["comfort", "classic", "sweet", "special", None, None])

    if diet_name:
        query = f"рецепт для диеты ‘{diet_name}’. Из доступных продуктов."
    elif mood and mood in MOOD_PROMPTS:
        query = MOOD_PROMPTS[mood]
    else:
        season = "лето" if is_summer else "осень" if month in (9,10,11) else "зима" if month in (12,1,2) else "весна"
        query = f"Вкусное блюдо на {season}. Простые ингредиенты, но с характером."

    # LLMFactory (KeyPool + CircuitBreaker + Groq fallback) -- замена urllib
    if not _LEVIATHAN_CORE:
        raise RuntimeError("LLMFactory недоступен")
    raw = await LLMFactory.execute_request(
        prompt=query,
        system=SYS_PUHLYASH,
        model="gemini-3.1-flash-lite",
        driver="gemini",
        fallback=True,
        task_type="structured",
    )

    recipe = _parse(raw, "home")
    recipe["puhlyash_intro"] = get_puhlyash_intro(mood)
    recipe["mood"] = mood
    return recipe


def format_puhlyash_message(recipe: dict, irisochka_tip: str = "") -> str:
    """Форматирует сообщение рецепта дня с характером."""
    import json as _json
    intro = recipe.get("puhlyash_intro", "")
    title = recipe.get("title", "?")
    desc = recipe.get("description", "")
    try:
        ingr = _json.loads(recipe.get("ingredients", "[]"))
        steps = _json.loads(recipe.get("steps", "[]"))
    except:
        ingr, steps = [], []
    kcal = recipe.get("calories_per_serving", "?")
    time = recipe.get("cook_time_minutes", "?")
    servings = recipe.get("servings", 2)

    lines = [
        f"\U0001f35d <b>Рецепт дня от Пухляша</b>",
        "",
        f"\U0001f4ac <i>{intro}</i>",
        "",
        f"✨ <b>{title}</b>",
    ]
    if desc:
        lines.append(f"<i>{desc}</i>")
    lines += [
        "",
        f"⏱ {time} мин  |  \U0001f525 {kcal} ккал  |  \U0001f464 {servings} порц",
        "",
        "<b>Надо:</b>",
    ]
    for i in ingr:
        lines.append(f"• {i}")
    lines += ["", "<b>Готовим:</b>"]
    for s in steps:
        lines.append(s)
    # Ирисочка — нутриционный коммент
    tip = irisochka_tip or recipe.get("irisochka_tip", "")
    if not tip:
        from modules.puhlyash.irisochka import get_quick_tip
        tip = get_quick_tip()
    lines += ["", tip]
    return "\n".join(lines)

````

---

## Файл: modules/reactions/engine.py

`3608 байт`

````
"""Reactions: лайк/дизлайк/сохранить для рецептов/диет/упражнений."""
import uuid
import aiosqlite
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from database import DB_PATH


def reaction_kb(item_type: str, item_id: str) -> InlineKeyboardMarkup:
    """Инлайн-клавиатура реакций."""
    prefix = f"{item_type}:{item_id}"
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="👍", callback_data=f"react:like:{prefix}"),
            InlineKeyboardButton(text="👎", callback_data=f"react:dislike:{prefix}"),
            InlineKeyboardButton(text="🔖 Сохранить", callback_data=f"react:save:{prefix}"),
        ],
        [
            InlineKeyboardButton(text="🔄 Альтернативы", callback_data=f"react:alt:{prefix}"),
            InlineKeyboardButton(text="💡 Развить", callback_data=f"react:expand:{prefix}"),
        ],
    ])


def reaction_kb_with_reason(item_type: str, item_id: str, reaction: str) -> InlineKeyboardMarkup:
    """После лайка/дизлайка — предложить указать причину."""
    prefix = f"{item_type}:{item_id}"
    if reaction == "dislike":
        reasons = [
            ("🕒 Долго готовить", "too_long"),
            ("💸 Дорогие продукты", "too_expensive"),
            ("🧐 Не мои ингредиенты", "bad_ingredients"),
            ("😕 Не мой вкус", "not_my_taste"),
            ("👎 Просто не нравится", "just_no"),
        ]
    else:
        reasons = [
            ("🔥 Очень вкусно", "delicious"),
            ("⚡ Быстро готовится", "quick"),
            ("💰 Дешёво", "cheap"),
            ("🥗 Полезно", "healthy"),
        ]
    rows = [[InlineKeyboardButton(text=t, callback_data=f"reason:{r}:{prefix}")] for t, r in reasons]
    rows.append([InlineKeyboardButton(text="✔️ Без причины", callback_data=f"reason:skip:{prefix}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def save_reaction(tg_id: str, item_type: str, item_id: str,
                        item_title: str, reaction: str, reason: str = None):
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        # Удаляем предыдущую реакцию на этот item
        await db.execute(
            "DELETE FROM reactions WHERE tg_id=? AND item_type=? AND item_id=?",
            (tg_id, item_type, item_id)
        )
        await db.execute(
            "INSERT INTO reactions (id, tg_id, item_type, item_id, item_title, reaction, reason) "
            "VALUES (?,?,?,?,?,?,?)",
            (str(uuid.uuid4()), tg_id, item_type, item_id, item_title, reaction, reason)
        )
        await db.commit()


async def get_saved(tg_id: str, item_type: str = None) -> list:
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        if item_type:
            async with db.execute(
                "SELECT * FROM reactions WHERE tg_id=? AND item_type=? AND reaction='save' ORDER BY created_at DESC",
                (tg_id, item_type)
            ) as c:
                return [dict(r) for r in await c.fetchall()]
        else:
            async with db.execute(
                "SELECT * FROM reactions WHERE tg_id=? AND reaction='save' ORDER BY created_at DESC",
                (tg_id,)
            ) as c:
                return [dict(r) for r in await c.fetchall()]
````

---

## Файл: modules/recipes/engine.py

`2698 байт`

````
"""Recipe Engine v2."""
import json, uuid, sys
sys.path.insert(0, "/opt/diet_platform")
sys.path.insert(0, "/opt/leviathan_engine")
from building_blocks.logger import get_logger
log = get_logger(__name__)

try:
    from llm_factory import LLMFactory
    _LEVIATHAN_CORE = True
    log.info("🔗 Leviathan LLMFactory подключён в recipes/engine.py")
except ImportError:
    _LEVIATHAN_CORE = False
    log.warning("⚠️ LLMFactory недоступен в recipes/engine.py")

MODES = {"quick": "⚡ Быстро", "home": "🏠 Домашний", "restaurant": "🍽 Ресторанный", "pp": "🥦 ПП"}

SYS_PROMPT = """Ты шеф-повар и диетолог. Отвечай строго в JSON без текста вне JSON.
{"title":"","description":"","mode":"","cook_time_minutes":0,"servings":2,
"calories_per_serving":0,"protein_g":0,"fat_g":0,"carbs_g":0,
"ingredients":["ингредиент - количество"],"steps":["Шаг 1: ..."],"tags":[]}"""

RECIPE_MODEL = "gemini-3.1-flash-lite"


async def _gemini(prompt: str) -> str:
    """LLM-вызов через Leviathan LLMFactory (KeyPool + CircuitBreaker + Groq fallback)
    вместо raw urllib + ручной ротации ключей из .env.
    """
    if not _LEVIATHAN_CORE:
        raise RuntimeError("LLMFactory недоступен")
    return await LLMFactory.execute_request(
        prompt=prompt,
        system=SYS_PROMPT,
        model=RECIPE_MODEL,
        driver="gemini",
        fallback=True,
        task_type="structured",
    )


def _parse(raw: str, mode: str) -> dict:
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
    d = json.loads(raw)
    d["id"] = str(uuid.uuid4())
    d["mode"] = mode
    for field in ["ingredients", "steps", "tags"]:
        d[field] = json.dumps(d.get(field, []), ensure_ascii=False)
    return d


async def generate_recipe(query: str, mode: str, profile: dict | None = None) -> dict:
    from modules.recipes.prompt_builder import build_recipe_prompt
    prompt = build_recipe_prompt(query, mode, profile)
    raw = await _gemini(prompt)
    return _parse(raw, mode)


async def generate_from_fridge(ingredients: list) -> dict:
    prompt = f"Холодильник: {', '.join(ingredients)}. Что приготовить? Режим: home."
    raw = await _gemini(prompt)
    return _parse(raw, "home")


async def generate_budget_recipe(budget: int, currency: str = "руб") -> dict:
    prompt = f"Ужин для семьи на {budget} {currency}, доступные продукты. Режим: home."
    raw = await _gemini(prompt)
    return _parse(raw, "home")
````

---

## Файл: modules/recipes/prompt_builder.py

`3890 байт`

````
"""Profile-aware recipe prompt builder."""

COOK_LEVEL_HINTS = {
    "beginner":  "уровень новичок: максимум 3-4 шага, минимум ингредиентов, никаких сложных техник. Яичница, пельмени, паста с маслом.",
    "amateur":   "уровень любитель: до 6 шагов, знакомые продукты, простые соусы. Омлет, суп, паста болоньезе.",
    "cook":      "уровень уверенный: любое число шагов, можно мариновать, тушить, запекать.",
    "expert":    "уровень эксперт: равиоли, ризотто, сложные соусы, профессиональные техники.",
}

BUDGET_HINTS = {
    "student": "бюджет студент: дешёвые доступные продукты, никаких деликатесов и пармезанов.",
    "normal":  "обычный бюджет: обычные продукты из супермаркета.",
    "free":    "бюджет не ограничен: можно дорогие ингредиенты.",
}

EXPERIMENT_HINTS = {
    "classic":    "только проверенные блюда, ничего необычного.",
    "sometimes": "иногда можно что-то новое, но не каждый раз.",
    "explorer":  "люблю пробовать новое, необычные сочетания приветствуются.",
}

TIME_HINTS = {
    15: "максимум 15 минут на приготовление.",
    30: "максимум 30 минут.",
    60: "время не ограничено.",
}


def build_recipe_prompt(query: str, mode: str, profile: dict | None = None) -> str:
    hints = {
        "quick":      "15-20 мин, минимум ингредиентов",
        "home":       "домашняя кухня, доступные продукты",
        "restaurant": "ресторанная подача",
        "pp":         "низкокалорийный, без сахара",
    }.get(mode, "")

    lines = [f"Режим '{mode}' ({hints}): {query}"]

    if profile:
        lvl = profile.get("cook_level", "beginner")
        bud = profile.get("budget_level", "normal")
        exp = profile.get("experiment_level", "sometimes")
        tme = profile.get("max_cook_time", 30)
        excl = profile.get("excluded_foods", "[]")

        lines.append(f"\nТребования пользователя:")
        lines.append(f"- {COOK_LEVEL_HINTS.get(lvl, '')}")
        lines.append(f"- {BUDGET_HINTS.get(bud, '')}")
        lines.append(f"- {EXPERIMENT_HINTS.get(exp, '')}")
        lines.append(f"- {TIME_HINTS.get(tme, str(tme) + ' мин')}")
        if excl and excl != "[]":
            lines.append(f"- Исключить: {excl}")

        lines.append("\nВАЖНО: рецепт должен строго соответствовать уровню. "
                       "Новичку НЕ давать равиоли и пармезан. "
                       "Студенту НЕ давать дорогие ингредиенты.")

    return "\n".join(lines)


def build_random_recipe_prompt(profile: dict | None = None, diet_name: str | None = None) -> str:
    if diet_name:
        return f"Случайный рецепт для диеты '{diet_name}'. Режим: home."

    lvl = (profile or {}).get("cook_level", "beginner")
    bud = (profile or {}).get("budget_level", "normal")
    lines = [
        "Случайный рецепт на сегодня. Режим: home.",
        f"- {COOK_LEVEL_HINTS.get(lvl, '')}",
        f"- {BUDGET_HINTS.get(bud, '')}",
        "Сделай рецепт простым, понятным, вкусным.",
    ]
    return "\n".join(lines)
````

---

## Файл: modules/scheduler/meal_scheduler.py

`3770 байт`

````
"""APScheduler — планировщик питания и уведомлений."""
import asyncio
import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
import aiosqlite
from database import DB_PATH
from modules.notifier.sender import send_notification
from modules.recipes.engine import generate_recipe
from modules.fitness.engine import generate_exercises, format_exercises

log = logging.getLogger(__name__)
scheduler = AsyncIOScheduler(timezone="Europe/Moscow")

MEAL_EMOJI = {"breakfast": "🌅", "lunch": "🍽", "dinner": "🌙"}
MEAL_LABEL = {"breakfast": "Завтрак", "lunch": "Обед", "dinner": "Ужин"}


async def _get_active_users() -> list[dict]:
    async with aiosqlite.connect(DB_PATH, timeout=30) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT tg_id, meal_breakfast, meal_lunch, meal_dinner, "
            "active_diet_mode, notifications_enabled FROM user_profiles "
            "WHERE notifications_enabled=1"
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def send_meal_notification(meal: str):
    """Called by scheduler for breakfast/lunch/dinner."""
    users = await _get_active_users()
    log.info("Sending %s notifications to %d users", meal, len(users))

    for user in users:
        if not user.get("notify_personal", 1) or not user.get("notify_meals", 1):
            continue
        meal_time = user.get(f"meal_{meal}")
        if not meal_time:
            continue
        tg_id = user["tg_id"]
        diet_mode = user.get("active_diet_mode") or "home"
        try:
            from modules.puhlyash.persona import generate_puhlyash_recipe, format_puhlyash_message
            recipe, exercises = await asyncio.gather(
                generate_puhlyash_recipe(profile=dict(user)),
                generate_exercises(meal, diet_mode),
            )
            emoji = MEAL_EMOJI[meal]
            text = (
                f"{emoji} <b>{MEAL_LABEL[meal]}!</b>\n\n"
                f"{format_puhlyash_message(recipe)}\n\n"
                f"{format_exercises(exercises)}"
            )
            await send_notification(tg_id, text)
            await asyncio.sleep(0.5)
        except Exception as e:
            log.error("Failed notification for %s: %s", tg_id, e)


def _parse_time(t: str) -> tuple[int, int]:
    """'08:30' -> (8, 30)"""
    h, m = t.split(":")
    return int(h), int(m)


async def reschedule_user(tg_id: str, breakfast: str, lunch: str, dinner: str):
    """Add/update cron jobs for a specific user."""
    for meal, time_str in [("breakfast", breakfast), ("lunch", lunch), ("dinner", dinner)]:
        job_id = f"{meal}_{tg_id}"
        if scheduler.get_job(job_id):
            scheduler.remove_job(job_id)
        if time_str:
            h, m = _parse_time(time_str)
            scheduler.add_job(
                send_meal_notification,
                CronTrigger(hour=h, minute=m),
                args=[meal],
                id=job_id,
                replace_existing=True,
            )
            log.info("Scheduled %s for user %s at %s", meal, tg_id, time_str)


async def load_all_schedules():
    """Load all user schedules on startup."""
    users = await _get_active_users()
    for u in users:
        b = u.get("meal_breakfast") or ""
        l = u.get("meal_lunch") or ""
        d = u.get("meal_dinner") or ""
        if any([b, l, d]):
            await reschedule_user(u["tg_id"], b, l, d)
    log.info("Loaded schedules for %d users", len(users))


def start_scheduler():
    scheduler.start()
    log.info("⏰ Scheduler started")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
````

---

## Файл: modules/search_gateway/internal/searcher.py

`4652 байт`

````
"""Search Gateway: DuckDuckGo HTML scraping + SERP fallback.

Responsibility:
- Оркестрация поисковых провайдеров
- Rate limiting + fallback strategy
- Генерация Correlation ID
- Запись задач в Outbox (Транзакционный Outbox)
"""
import json
import hashlib
import uuid
import asyncio
from datetime import datetime, timedelta
from typing import Optional
import httpx
from bs4 import BeautifulSoup
import aiosqlite

from building_blocks.config import get_settings
from building_blocks.logger import get_logger, set_trace_context
from building_blocks.contracts import PipelineStatus, new_trace_id

log = get_logger(__name__)
cfg = get_settings()

DDG_URL = "https://html.duckduckgo.com/html/"
DDG_HEADERS = {
    "User-Agent": cfg.scraper_user_agent,
    "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
}


def _query_cache_key(query: str) -> str:
    return hashlib.sha256(query.lower().strip().encode()).hexdigest()


async def _check_cache(db: aiosqlite.Connection, cache_key: str) -> Optional[list]:
    """TTL-кэш поисковой выдачи."""
    ttl_cutoff = (datetime.utcnow() - timedelta(hours=cfg.search_cache_ttl_hours)).isoformat()
    async with db.execute(
        "SELECT payload FROM outbox WHERE event_type='search_cache' "
        "AND json_extract(payload,'$.cache_key')=? AND created_at>? LIMIT 1",
        (cache_key, ttl_cutoff)
    ) as cur:
        row = await cur.fetchone()
        if row:
            data = json.loads(row[0])
            return data.get("urls", [])
    return None


async def _scrape_duckduckgo(query: str) -> list:
    """Fallback: HTML-скрапинг DuckDuckGo."""
    diet_query = f"{query} диета план питания медицинский"
    try:
        async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
            resp = await client.post(
                DDG_URL,
                data={"q": diet_query, "kl": "ru-ru"},
                headers=DDG_HEADERS,
            )
            resp.raise_for_status()
        soup = BeautifulSoup(resp.text, "lxml")
        urls = []
        for a in soup.select(".result__url"):
            href = a.get("href", "").strip()
            if href.startswith("http") and len(urls) < cfg.max_urls_per_query:
                urls.append(href)
        log.info("DuckDuckGo found %d URLs for query: %s", len(urls), query[:50])
        return urls
    except Exception as e:
        log.warning("DuckDuckGo scraping failed: %s", e)
        return []


async def initiate_search(
    db: aiosqlite.Connection,
    query_text: str,
    user_id: Optional[str] = None,
) -> str:
    """
    Entry point: создаёт SearchSession, запускает поиск, пишет в Outbox.
    Returns: session_id
    """
    session_id = str(uuid.uuid4())
    trace_id = new_trace_id()
    set_trace_context(trace_id, session_id)

    # 1. Создаём сессию
    await db.execute(
        "INSERT INTO search_sessions(id, trace_id, query_text, status, user_id) "
        "VALUES(?,?,?,?,?)",
        (session_id, trace_id, query_text, PipelineStatus.SEARCHING, user_id)
    )

    # 2. Проверяем кэш
    cache_key = _query_cache_key(query_text)
    cached_urls = await _check_cache(db, cache_key)

    if cached_urls:
        log.info("Cache hit for query: %s", query_text[:50])
        urls = cached_urls
    else:
        # 3. Делаем поиск
        urls = await _scrape_duckduckgo(query_text)
        if not urls:
            await db.execute(
                "UPDATE search_sessions SET status=?, error_message=?, updated_at=datetime('now') WHERE id=?",
                (PipelineStatus.FAILED, "No URLs found", session_id)
            )
            await db.commit()
            log.warning("Search failed: no URLs for query: %s", query_text[:50])
            return session_id

    # 4. Транзакционно пишем Outbox-задачи для каждого URL
    for url in urls:
        task_id = str(uuid.uuid4())
        payload = json.dumps({
            "task_id": task_id,
            "session_id": session_id,
            "trace_id": trace_id,
            "url": url,
            "query_text": query_text,
        })
        await db.execute(
            "INSERT INTO outbox(id, session_id, trace_id, event_type, payload, status) "
            "VALUES(?,?,?,?,?,?)",
            (task_id, session_id, trace_id, "fetch_url", payload, "pending")
        )

    # 5. Атомарно коммитим
    await db.commit()
    log.info("Session %s created with %d URLs", session_id, len(urls))
    return session_id
````

---

## Файл: modules/web_scraper/fetcher/http_fetcher.py

`3903 байт`

````
"""Web Scraper: requests + BS4. MVP без headless-браузера (нет OOM-риска)."""
import hashlib
import json
import re
import uuid
from typing import Optional
from urllib.parse import urlparse

import httpx
from bs4 import BeautifulSoup

from building_blocks.config import get_settings
from building_blocks.contracts import FetchFailReason
from building_blocks.logger import get_logger
from modules.web_scraper.network.ssrf_guard import validate_url_for_ssrf

log = get_logger(__name__)
cfg = get_settings()

MIN_TEXT_LENGTH = 100  # мин. символов для валидного контента


def _extract_text(html: str, url: str) -> str:
    """Boilerplate Remover: извлекаем основной текст."""
    soup = BeautifulSoup(html, "lxml")

    # Удаляем мусор
    for tag in soup(["script", "style", "nav", "footer", "header",
                     "aside", "iframe", "noscript", "form", "button"]):
        tag.decompose()

    # Приоритет article/main
    for selector in ["article", "main", ".content", ".article", ".post", "#content"]:
        target = soup.select_one(selector)
        if target:
            text = target.get_text(separator=" ", strip=True)
            if len(text) >= MIN_TEXT_LENGTH:
                return _clean_text(text)

    # Fallback: body
    body = soup.find("body")
    if body:
        return _clean_text(body.get_text(separator=" ", strip=True))

    return _clean_text(soup.get_text(separator=" ", strip=True))


def _clean_text(text: str) -> str:
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"[\x00-\x1f\x7f]", "", text)
    return text.strip()[:50000]  # Hard limit


async def fetch_url(url: str, task_id: str, trace_id: str) -> dict:
    """
    Returns dict with keys: ok, raw_text, content_sha256, http_status,
    fail_reason (if not ok).
    """
    # 1. SSRF Guard
    is_safe, reason = validate_url_for_ssrf(url)
    if not is_safe:
        log.warning("[%s] SSRF blocked: %s | %s", task_id, url, reason)
        return {"ok": False, "fail_reason": FetchFailReason.SECURITY_VIOLATION}

    # 2. HTTP request с таймаутом
    headers = {
        "User-Agent": cfg.scraper_user_agent,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8",
        "Accept-Encoding": "gzip, deflate, br",
    }
    try:
        async with httpx.AsyncClient(
            timeout=cfg.scraper_timeout_seconds,
            follow_redirects=True,
            max_redirects=3,
        ) as client:
            resp = await client.get(url, headers=headers)

        if resp.status_code >= 400:
            log.warning("[%s] HTTP %d for %s", task_id, resp.status_code, url)
            return {"ok": False, "fail_reason": FetchFailReason.HTTP_ERROR,
                    "http_status": resp.status_code}

        # 3. Извлекаем текст
        raw_text = _extract_text(resp.text, url)

        if len(raw_text) < MIN_TEXT_LENGTH:
            log.warning("[%s] Content too short (%d chars): %s", task_id, len(raw_text), url)
            return {"ok": False, "fail_reason": FetchFailReason.EMPTY_CONTENT}

        content_sha256 = hashlib.sha256(raw_text.encode()).hexdigest()
        log.info("[%s] Fetched %d chars from %s", task_id, len(raw_text), url)

        return {
            "ok": True,
            "raw_text": raw_text,
            "content_sha256": content_sha256,
            "http_status": resp.status_code,
            "content_length": len(raw_text),
        }

    except httpx.TimeoutException:
        log.warning("[%s] Timeout for %s", task_id, url)
        return {"ok": False, "fail_reason": FetchFailReason.TIMEOUT}
    except Exception as e:
        log.error("[%s] Fetch error for %s: %s", task_id, url, e)
        return {"ok": False, "fail_reason": FetchFailReason.HTTP_ERROR}
````

---

## Файл: modules/web_scraper/network/ssrf_guard.py

`1868 байт`

````
"""SSRF Protection: валидация URL перед HTTP-запросом."""
import ipaddress
import socket
from urllib.parse import urlparse
from building_blocks.logger import get_logger

log = get_logger(__name__)

# RFC1918 + link-local + loopback + cloud metadata
_BLOCKED_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),  # cloud metadata
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]

_ALLOWED_SCHEMES = {"http", "https"}


def validate_url_for_ssrf(url: str) -> tuple[bool, str]:
    """
    Returns (is_safe, reason).
    Проверяет URL перед отправкой HTTP-запроса.
    Аудит: ContentFetchFailed(reason=SECURITY_VIOLATION) если небезопасно.
    """
    try:
        parsed = urlparse(url)

        if parsed.scheme not in _ALLOWED_SCHEMES:
            return False, f"Scheme not allowed: {parsed.scheme}"

        hostname = parsed.hostname
        if not hostname:
            return False, "Empty hostname"

        # Резолвим IP
        try:
            ip_str = socket.gethostbyname(hostname)
        except socket.gaierror as e:
            return False, f"DNS resolution failed: {e}"

        ip = ipaddress.ip_address(ip_str)

        for blocked_net in _BLOCKED_NETWORKS:
            if ip in blocked_net:
                log.warning(
                    "SSRF blocked: %s resolved to %s (%s)",
                    hostname, ip_str, blocked_net
                )
                return False, f"IP {ip_str} is in blocked network {blocked_net}"

        return True, "ok"

    except Exception as e:
        return False, f"Validation error: {e}"
````

---

## Файл: start_here/MASTER_PROMPT.md

`3171 байт`

````
# 🤖 MASTER PROMPT — Diet Platform «Пухляш»

## Читай это первым

Ты — Senior Python-разработчик, работающий над проектом **Diet Platform «Пухляш»**.
Перед любым действием прочитай `PASSPORT.md` и последний лог сессии в `logs/`.

---

## Контекст проекта

**Что это:** Бэкенд-платформа + Telegram-бот для:
- умных рецептов с режимами (быстро/домашний/ресторанный/ПП)
- индивидуальных диет (профиль + FSM опроса)
- меню из холодильника / по бюджету / сезонное
- список покупок
- рассылки email/SMS

**Стек** | Python 3.11+, FastAPI, aiogram3, aiosqlite, SQLite (WAL)

**LLM** | gemini-2.5-flash через `/opt/leviathan_engine/llm_factory.py` (KeyPool 14 ключей + CircuitBreaker + фоллбэк на Groq)

**Сервер** | leviathanstory.ru, путь `/opt/diet_platform`, порт `8150`

---

## Архитектурные границы (HOLY RULES)

1. **Не меняй API контракты** без явного разрешения от владельца
2. **Все новые функции бота** — через `bot.py`, новые файлы через `modules/`
3. **Схема БД меняется только через `database.py`** (добавить таблицу в SCHEMA)
4. **LLM вызовы только** через `LLMFactory.execute_request()` (не `google.genai` напрямую)
5. **Персональные данные пользователя** (профиль) — таблица `user_profiles`, без FSM-переспроса при повторном входе
6. **Leviathan Agent управляет Leviathan → Diet Platform**, не наоборот
7. **Каждое действие** пиши в `start_here/logs/` через `SessionLogger`

---

## Как логировать сессию

```python
from start_here.session_logger import get_session_logger

log = get_session_logger("block_name")
log.task("что нужно сделать")
log.doing("как делаю")
log.done("что сделано")
log.next("что дальше")
log.snapshot()  # сохраняет snapshot_block_name.md
```

---

## Как добавить новую функцию бота

1. Создай модуль в `modules/` или `bot_handlers/`
2. Добавь маршрут(ы) в `bot.py` (Router + handler)
3. Если нужна схема — добавь `CREATE TABLE` в `database.py::SCHEMA`
4. Запиши в лог сессии
5. `systemctl restart diet-platform.service`
6. `curl http://127.0.0.1:8150/health`

---

## Ссылки на дополнительные документы

- **Паспорт проекта:** `start_here/PASSPORT.md`
- **Текущая сессия:** последний файл в `start_here/logs/`
- **Шема БД:** `database.py::SCHEMA`
- **Контракты:** `building_blocks/contracts.py`
- **Конфиг:** `building_blocks/config.py` + `.env`
````

---

## Файл: start_here/PASSPORT.md

`9306 байт`

````
# 🧁 Паспорт проекта: Diet Platform «Пухляш»

> Последнее обновление: **2026-06-19**

---

## Основные данные

| Параметр | Значение |
|---|---|
| **Название** | Diet Platform «Пухляш» |
| **Сервер** | `leviathanstory.ru` (`78.17.24.96`) |
| **Путь** | `/opt/diet_platform` |
| **API-порт** | `8150` |
| **Сервис** | `diet-platform.service` |
| **База данных** | `/opt/diet_platform/diet_platform.db` (SQLite, WAL) |
| **Gemini-модель** | `gemini-3.1-flash-lite` (K1-K14 ротация) |
| **Telegram-бот** | `@Fatboyandgirl_bot` (token в `.env`) |
| **Mini App** | `https://leviathanstory.ru/diet/app` |
| **Питон** | `/usr/bin/python3` (системный, venv удалены) |
| **Userbot** | `/opt/telegram-agent-book/my_account.session` (Pyrogram) |

---

## Маскот Пухляш

**Образ:** Рыжий кот в фартуке + мышка-помощник
**Персонаж:** Свой парень, любит поесть, знает толк в обычной еде с нотками эксклюзивности
**Тон:** Дружелюбный, чуть юмор, но со знанием дела
**Таглайн:** «Свой парень, знает толк в еде!»
**Фишка:** Бот проверяет совместимость ингредиентов (не даст дать смешать селёдку с молоком)
**Изображения:** `/opt/diet_platform/assets/mascot/` (добавить)

---

## Архитектура (2026-06-19)

```
[Telegram Bot @Fatboyandgirl_bot]
        ↓ aiogram3 + FSM
[FastAPI :8150]
        ↓
├── Рецепты  → modules/recipes/engine.py → Gemini 3.1-flash-lite
├── Пухляш  → modules/puhlyash/persona.py → настроение + рецепт без бюджета
├── Диеты   → modules/diet_registry/ → SQLite
├── Уведом.  → modules/notifier/sender.py → Pyrogram userbot
├── Распис. → modules/scheduler/meal_scheduler.py → APScheduler
├── Реакции → modules/reactions/engine.py → SQLite
├── Фитнес  → modules/fitness/engine.py → Gemini
└── Mini App → api/miniapp_router.py → https://leviathanstory.ru/diet/app
```

---

## Бот-хендлеры

| Файл | Назначение | Статус |
|---|---|---|
| `bot.py` | Главный бот + запуск | ✅ |
| `bot_handlers/recipes.py` | Рецепты, холодильник, бюджет, шеф, Пухляш | ✅ |
| `bot_handlers/puhlyash_settings.py` | Настройка маскота + тест уведомлений | ✅ |
| `bot_handlers/reactions.py` | Лайк/дизлайк/сохранить/альтернативы/мастер | ✅ |
| `bot_handlers/meal_schedule_v2.py` | Расписание питания v2 (все приёмы) | ✅ |
| `bot_handlers/diet_picker.py` | Подбор диеты (опросник + 3 варианта) | ✅ |
| `bot_handlers/cabinet.py` | Личный кабинет (FSM) | ✅ |
| `bot_handlers/schedule.py` | Старое расписание (fallback) | ⚠️ устаревшее |

---

## Модули

| Модуль | Назначение | Статус |
|---|---|---|
| `modules/puhlyash/persona.py` | Персонаж, настроения, промпты (без бюджета!) | ✅ |
| `modules/recipes/engine.py` | Генерация рецептов (Gemini) | ✅ |
| `modules/recipes/prompt_builder.py` | Промпты с учётом профиля | ✅ |
| `modules/reactions/engine.py` | Реакции, inline-кнопки | ✅ |
| `modules/fitness/engine.py` | Упражнения без снарядов (Gemini) | ✅ |
| `modules/notifier/sender.py` | Pyrogram userbot + авто-реконнект | ✅ |
| `modules/scheduler/meal_scheduler.py` | APScheduler, CronTrigger, Europe/Moscow | ✅ |
| `api/miniapp_router.py` | Telegram Mini App + профиль API | ✅ |
| `api/cabinet_router.py` | HTML-кабинет (дублирует Mini App) | ⚠️ можно удалить |

---

## База данных (sqlite)

| Таблица | Назначение | Строк |
|---|---|---|
| `recipes` | Генерированные рецепты | 28 |
| `diet_master` | Верифицированные диеты | 12 |
| `user_profiles` | Профили пользователей | 2 |
| `meal_schedule` | Приёмы пищи | 5 |
| `reactions` | Лайки/дизлайки/сохранённые | 0 |
| `diary_entries` | Дневник (запланирован, не реализован) | 0 |
| `dlq` | Ошибки pipeline | 137 |

---

## Функциональность бота

### Реализовано ✅

| Кнопка | Описание |
|---|---|
| 🎯 Подобрать диету | Опросник 4 шага → Gemini даёт 3 варианта → план на неделю |
| 👤 Кабинет | Уровень/эксп., бюджет, время, исключения, рецепт дня |
| 🍝 Рецепт от Пухляша | Случайный рецепт с настроением, без бюджетных ограничений |
| 👨‍🍳 Рецепты | 4 режима: быстро/дом/ресторан/ПП, учитывает профиль |
| 🧊 Холодильник | Рецепт из перечня продуктов |
| 💰 По бюджету | Ужин на сумму |
| 👨‍🍳 Шеф на телефоне | Чат с Gemini в роли шефа |
| ⏰ Расписание | Приёмы пищи с именами, вкл/выкл, стандартное |
| 🍝 Пухляш | Настройка маскота + тест уведомлений |
| 👍/👎 inline | Реакции на рецепты + причина |
| 🔄 Альтернативы | 2 варианта альтернативного рецепта |
| 💡 Мастер эксперим. | Диалог с Пухляшем, проверка совместимости |
| 📱 Mini App | Telegram WebApp с двумя вкладками |

### Запланировано 🔧

| Функция | Приоритет |
|---|---|
| 👍/👎 Тестирование реакций (нет данных) | П1 |
| 🔔 Уведомления в личку (тест по кнопке в Пухляш) | П1 |
| 🕊️⃣ Цены на продукты в рецепте | П2 |
| 📰 Дневник пользователя | П2 |
| 🧠 RAG-анализ привычек (ChromaDB) | П2 |
| 🛒 Интеграция с магазинами/ценами | П3 |
| 💳 Монетизация (подписка) | П3 |

---

## Настройка nginx

```nginx
location ^~ /diet/ {
    proxy_pass http://127.0.0.1:8150/diet/;
}
```
Mini App: `https://leviathanstory.ru/diet/app?uid={tg_id}`

---

## Команды для сессии

```bash
# Перезапустить
fuser -k 8150/tcp 2>/dev/null; sleep 2 && systemctl start diet-platform

# Логи
systemctl status diet-platform
journalctl -u diet-platform -n 30 --no-pager
cat /opt/diet_platform/logs/diet_platform.log | tail -30

# Проверка синтаксиса
cd /opt/diet_platform && python3 -c "import bot; print('ok')"

# БД
curl -s http://localhost:8150/health

# Тест Gemini
python3 -c "from modules.puhlyash.persona import generate_puhlyash_recipe; import asyncio; r=asyncio.run(generate_puhlyash_recipe()); print(r['title'])"
```

---

## Известные проблемы

| Проблема | Статус |
|---|---|
| Pyrogram-сессия занята `den4ik-claude.service` | Решено: авто-реконнект в sender.py |
| `meal_breakfast='01:04'` (баг FSM) | Исправлено, сброшено |
| DLQ 137 записей | Ошибки старого pipeline поиска, не критично |
| `schedule.py` - устаревшее | Заменить на `meal_schedule_v2.py` |
| `api/cabinet_router.py` - дублирует Mini App | Можно удалить |

---

## Роадмап v4 — Личный AI-ассистент

Подробно: `/opt/diet_platform/start_here/ROADMAP_v4_assistant.md`

Коротко:
1. `modules/diary/` — дневник (текст + голос)
2. `modules/rag/` — ChromaDB (port 8009 уже есть)
3. `modules/planner/` — 3 варианта плана недели
4. FastAPI endpoint + HTML страница выбора
5. Уведомления по расписанию, покупкам, воде

---

## Структура профиля пользователя (user_profiles)

Основные: `cook_level`, `experiment_level`, `budget_level`, `max_cook_time`, `excluded_foods`
Расписание: `meal_breakfast/lunch/dinner`, `recipe_day_time`, `recipe_day_enabled`
Уведомления: `notify_personal`, `notify_meals`, `notify_recipe_day`
Пухляш: `puhlyash_name`, `puhlyash_specialty`, `puhlyash_tone`, `puhlyash_catchphrase`, `puhlyash_emoji`

---

*Файл обновляется в начале каждой рабочей сессии. Следующий Claude: читай этот файл первым!*
````

---

## Файл: start_here/ROADMAP_v4_assistant.md

`4422 байт`

````
# Diet Platform v4 — Личный AI-Ассистент
> Зафиксировано: 2026-06-12

## Концепция

Персональный AI-коуч поверх diet platform.
Пользователь ведёт дневник привычек → RAG анализирует 1-2 недели →
Gemini предлагает 3 варианта плана → пользователь выбирает →
бот шлёт напоминалки по расписанию.

---

## Модули

### 1. Дневник (`modules/diary/`)
- Запись через текст или голос в Telegram
- Типы записей: еда, активность, самочувствие, покупки, распорядок
- Таблица `diary_entries` уже создана в БД
- Голос → Gemini speech-to-text (или whisper через faster-whisper)

### 2. RAG-анализ (`modules/rag/`)
- ChromaDB (уже есть на сервере, port 8009)
- Каждая запись дневника → эмбеддинг → хранится per user_id
- Через 7 дней: Gemini анализирует паттерны
  - Когда обычно ест
  - Какие продукты предпочитает
  - Уровень активности
  - Циклы сна/усталости

### 3. Генерация плана (`modules/planner/`)
- Gemini генерирует 3 варианта плана на неделю
- Каждый вариант: название + краткое описание + ключевые отличия
- Форматы вывода:
  - **Telegram**: инлайн-кнопки с выбором варианта
  - **HTML-страница**: выпадающие списки + поле «свой вариант»
    - URL: `leviathanstory.ru/diet/plan/{user_token}`
    - Кнопки: вариант 1 / вариант 2 / вариант 3 / свой
    - После выбора → форма заполнения / подтверждение

### 4. Напоминалки (`modules/scheduler/` — расширение)
- Уже реализован meal_scheduler
- Добавить: задачи на покупки, воду, сон, активность
- Утренний дайджест: план на день
- Вечерний итог: что выполнено

---

## Поток пользователя

```
День 1-7: пользователь пишет/говорит боту что ест, как себя чувствует
             ↓
День 8: «Я проанализировал твои привычки за неделю. Вот 3 плана:
         1. Лёгкий старт — плавный переход...
         2. Активное похудение — дефицит 300 ккал...
         3. Набор энергии — фокус на завтраки...
         Выбери или опиши свой: [кнопки] [ссылка на страницу]"
             ↓
Выбор → сохранение в БД → scheduler настраивает напоминалки
             ↓
Ежедневно: утренний план + рецепты + упражнения в личку
```

---

## HTML-страница плана

```html
<!-- leviathanstory.ru/diet/plan/{token} -->
- Заголовок с именем пользователя
- 3 карточки вариантов с описанием
- Радиокнопки выбора
- Поле «свой вариант» (textarea)
- Кнопка «Подтвердить» → POST → API → уведомление в TG
```

---

## Технический стек

- ChromaDB (уже: port 8009)
- faster-whisper (уже установлен) → голосовые записи
- Gemini 2.5-flash → анализ + генерация планов
- APScheduler (уже: meal_scheduler.py)
- Pyrogram userbot (уже: notifier/sender.py)
- FastAPI endpoint `/diet/plan/{token}` → HTML страница

---

## Приоритет задач

1. `modules/diary/` — запись дневника (текст + голос)
2. `modules/rag/` — интеграция с ChromaDB
3. `modules/planner/` — генерация 3 планов через Gemini
4. FastAPI endpoint + HTML страница выбора
5. Расширение scheduler — покупки, вода, дайджесты
````

---

## Файл: start_here/__init__.py

`122 байт`

````
from start_here.session_logger import get_session_logger, SessionLogger

__all__ = ["get_session_logger", "SessionLogger"]
````

---

## Файл: start_here/logs/session_20260527_001.md

`1601 байт`

````
# 📓 Сессия: v1_foundation
**started:** 2026-05-27 10:07 UTC
**block:** v1_foundation
**file:** session_20260527_001.md

---

**[10:07:37]** 🟡 `TASK` Развернуть Diet Platform v1: pipeline + bot + Leviathan integration

**[10:07:37]** ✅ `DONE` diet-platform.service запущен на порту 8150

**[10:07:37]** ✅ `DONE` Telegram-бот @puhlyash подключён, токен прописан в .env

**[10:07:37]** ✅ `DONE` Постоянная ReplyKeyboard: 5 кнопок (Найти/Диеты/Ожидают/DLQ/Помощь)

**[10:07:37]** ✅ `DONE` Экстрактор переключён на Leviathan LLMFactory (gemini-2.5-flash, 14 ключей)

**[10:07:37]** ✅ `DONE` Gemini model: 2.0-flash -> 2.5-flash везде

**[10:07:37]** ✅ `DONE` Leviathan Agent: 7 diet_* инструментов зарегистрированы (diet_health/search/status/list/pending/verify/dlq)

**[10:07:37]** ✅ `DONE` start_here/ создана: MASTER_PROMPT.md, PASSPORT.md, session_logger.py

**[10:07:37]** ➡️ `NEXT` v2: Рецепты с режимами (быстро/домашний/ресторанный/ПП)

**[10:07:37]** ➡️ `NEXT` v2: Холодильник, Бюджет, Сезонный рынок, Шеф на телефоне

**[10:07:37]** ➡️ `NEXT` v3: user_profiles + FSM-профиль + индивидуальная диета

**[10:07:37]** ➡️ `NEXT` v3: Меню на неделю + список покупок + рассылки

**[10:07:37]** 📸 `SNAPSHOT` Сохранён в `snapshot_v1_foundation.md`


````

---

## Файл: start_here/logs/session_20260527_002.md

`424 байт`

````
# 📓 Сессия: v2_recipes_modes
**started:** 2026-05-27 10:07 UTC
**block:** v2_recipes_modes
**file:** session_20260527_002.md

---

**[10:07:46]** 🟡 `TASK` Реализовать: Рецепты (быстро/домашний/ресторанный/ПП), холодильник, бюджет, шеф, сезон

**[10:07:46]** 🔧 `DOING` Создаю modules/recipes/ + bot_handlers/ + миграция БД


````

---

## Файл: start_here/logs/snapshot_v1_foundation.md

`1736 байт`

````
# 📸 Snapshot: v1_foundation
**Выполнено:** 2026-05-27 10:07 UTC

## Резюме
Блок v1 Foundation полностью завершён. Сервис работает.

## Полная сессия

# 📓 Сессия: v1_foundation
**started:** 2026-05-27 10:07 UTC
**block:** v1_foundation
**file:** session_20260527_001.md

---

**[10:07:37]** 🟡 `TASK` Развернуть Diet Platform v1: pipeline + bot + Leviathan integration

**[10:07:37]** ✅ `DONE` diet-platform.service запущен на порту 8150

**[10:07:37]** ✅ `DONE` Telegram-бот @puhlyash подключён, токен прописан в .env

**[10:07:37]** ✅ `DONE` Постоянная ReplyKeyboard: 5 кнопок (Найти/Диеты/Ожидают/DLQ/Помощь)

**[10:07:37]** ✅ `DONE` Экстрактор переключён на Leviathan LLMFactory (gemini-2.5-flash, 14 ключей)

**[10:07:37]** ✅ `DONE` Gemini model: 2.0-flash -> 2.5-flash везде

**[10:07:37]** ✅ `DONE` Leviathan Agent: 7 diet_* инструментов зарегистрированы (diet_health/search/status/list/pending/verify/dlq)

**[10:07:37]** ✅ `DONE` start_here/ создана: MASTER_PROMPT.md, PASSPORT.md, session_logger.py

**[10:07:37]** ➡️ `NEXT` v2: Рецепты с режимами (быстро/домашний/ресторанный/ПП)

**[10:07:37]** ➡️ `NEXT` v2: Холодильник, Бюджет, Сезонный рынок, Шеф на телефоне

**[10:07:37]** ➡️ `NEXT` v3: user_profiles + FSM-профиль + индивидуальная диета

**[10:07:37]** ➡️ `NEXT` v3: Меню на неделю + список покупок + рассылки


````

---

## Файл: start_here/session_logger.py

`5390 байт`

````
"""
start_here/session_logger.py

Система логирования сессий AI-разработки.

Каждое действие пишется в Markdown-файл сессии:
  - задача (TASK)
  - в процессе (DOING)
  - сделано (DONE)
  - следующее (NEXT)
  - ошибка (ERROR)
  - снапшот блока (snapshot_BLOCK.md)

Использование:
    from start_here.session_logger import get_session_logger
    log = get_session_logger("v2_recipes")
    log.task("Реализовать режимы рецептов")
    log.doing("Создаю modules/recipes/")
    log.done("Модуль создан, 4 режима")
    log.next("Добавить кнопки в bot.py")
    log.snapshot()
"""
from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

LOGS_DIR = Path(__file__).parent / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)


class SessionLogger:
    """
    Пишет Markdown-лог в `start_here/logs/session_YYYYMMDD_NNN.md`.
    Снапшот блока — в `snapshot_BLOCK.md`.
    """

    def __init__(self, block_name: str, session_file: Optional[Path] = None):
        self.block_name = _slugify(block_name)
        ts = datetime.now().strftime("%Y%m%d")

        if session_file:
            self._path = session_file
        else:
            # Автономер сессий за день
            n = 1
            while True:
                candidate = LOGS_DIR / f"session_{ts}_{n:03d}.md"
                if not candidate.exists():
                    break
                # Если файл с этим блоком уже существует — подключаемся к нему
                content = candidate.read_text()
                if f"block: {self.block_name}" in content:
                    candidate = candidate
                    n = -1  # сентинел
                    break
                n += 1
            if n == -1:
                self._path = LOGS_DIR / f"session_{ts}_{1:03d}.md"
                # Найдём по блоку
                for f in sorted(LOGS_DIR.glob(f"session_{ts}_*.md")):
                    if f"block: {self.block_name}" in f.read_text():
                        self._path = f
                        break
            else:
                self._path = candidate

        self._init_file()

    def _init_file(self):
        if not self._path.exists():
            ts_full = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
            self._path.write_text(
                f"# 📓 Сессия: {self.block_name}\n"
                f"**started:** {ts_full}\n"
                f"**block:** {self.block_name}\n"
                f"**file:** {self._path.name}\n\n"
                f"---\n\n",
                encoding="utf-8",
            )

    def _append(self, emoji: str, label: str, text: str):
        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        line = f"**[{ts}]** {emoji} `{label}` {text}\n\n"
        with self._path.open("a", encoding="utf-8") as f:
            f.write(line)

    def task(self, text: str):
        """TASK: что нужно сделать."""
        self._append("🟡", "TASK", text)

    def doing(self, text: str):
        """DOING: как делаю."""
        self._append("🔧", "DOING", text)

    def done(self, text: str):
        """DONE: что сделано."""
        self._append("✅", "DONE", text)

    def next(self, text: str):
        """NEXT: что дальше."""
        self._append("➡️", "NEXT", text)

    def error(self, text: str):
        """ERROR: ошибка."""
        self._append("❌", "ERROR", text)

    def info(self, text: str):
        """INFO: произвольная пометка."""
        self._append("ℹ️", "INFO", text)

    def snapshot(self, summary: str = ""):
        """
        Сохраняет снапшот блока в `snapshot_BLOCK.md`.
        Вызывай по завершению блока работы.
        """
        snap_path = LOGS_DIR / f"snapshot_{self.block_name}.md"
        ts_full = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        session_content = self._path.read_text(encoding="utf-8")

        snap = (
            f"# 📸 Snapshot: {self.block_name}\n"
            f"**Выполнено:** {ts_full}\n\n"
        )
        if summary:
            snap += f"## Резюме\n{summary}\n\n"
        snap += f"## Полная сессия\n\n{session_content}"

        snap_path.write_text(snap, encoding="utf-8")
        self._append("📸", "SNAPSHOT", f"Сохранён в `{snap_path.name}`")
        return snap_path


# ── singleton-список активных логгеров по block_name ──────────────
_LOGGERS: dict[str, SessionLogger] = {}


def get_session_logger(block_name: str) -> SessionLogger:
    """Возвращает существующий логгер или создаёт новый."""
    slug = _slugify(block_name)
    if slug not in _LOGGERS:
        _LOGGERS[slug] = SessionLogger(block_name)
    return _LOGGERS[slug]


def _slugify(s: str) -> str:
    s = s.lower().strip()
    s = re.sub(r"[\s\-]+", "_", s)
    s = re.sub(r"[^\w]", "", s)
    return s[:40]
````

---

## Файл: tests/test_puhlyash.py

`5736 байт`

````
"""Тесты модуля Пухляш (persona + irisochka)."""
import pytest
import json
from datetime import datetime


# ── Persona tests ──

class TestTimePeriod:
    """get_time_period() — временные периоды."""

    def test_morning(self):
        from modules.puhlyash.persona import get_time_period
        period = get_time_period()
        assert period in ("morning", "lunch", "dinner", "night"), (
            f"get_time_period() вернул '{period}', ожидается morning/lunch/dinner/night"
        )

    def test_season_vibes_not_empty(self):
        from modules.puhlyash.persona import SEASON_VIBES
        assert len(SEASON_VIBES) >= 3

    def test_time_vibes_all_periods(self):
        from modules.puhlyash.persona import TIME_VIBES
        for period in ("morning", "lunch", "dinner", "night"):
            assert period in TIME_VIBES
            assert len(TIME_VIBES[period]) >= 1

    def test_mood_triggers_exist(self):
        from modules.puhlyash.persona import MOOD_TRIGGERS
        assert len(MOOD_TRIGGERS) >= 5

    def test_mood_prompts_all_keys(self):
        from modules.puhlyash.persona import MOOD_PROMPTS
        for mood in ("sweet", "comfort", "light", "spicy", "quick", "classic", "summer", "special"):
            assert mood in MOOD_PROMPTS


class TestPuhlyashIntro:
    """get_puhlyash_intro() — генерация вступления."""

    def test_intro_returns_string(self):
        from modules.puhlyash.persona import get_puhlyash_intro
        intro = get_puhlyash_intro()
        assert isinstance(intro, str)
        assert len(intro) > 10

    def test_intro_with_mood(self):
        from modules.puhlyash.persona import get_puhlyash_intro
        intro = get_puhlyash_intro("sweet")
        assert isinstance(intro, str)
        assert len(intro) > 10

    def test_intro_all_moods(self):
        from modules.puhlyash.persona import get_puhlyash_intro, MOOD_PROMPTS
        for mood in MOOD_PROMPTS:
            intro = get_puhlyash_intro(mood)
            assert isinstance(intro, str)
            assert len(intro) > 10

    def test_intro_never_empty(self):
        from modules.puhlyash.persona import get_puhlyash_intro
        for _ in range(20):
            assert len(get_puhlyash_intro()) > 5


class TestFormatMessage:
    """format_puhlyash_message() — форматирование рецепта."""

    def test_format_with_minimal_recipe(self):
        from modules.puhlyash.persona import format_puhlyash_message
        recipe = {
            "title": "Тестовый рецепт",
            "description": "Описание",
            "ingredients": '["вода"]',
            "steps": '["вскипятить"]',
            "calories_per_serving": 100,
            "cook_time_minutes": 10,
            "servings": 1,
            "puhlyash_intro": "Привет!",
        }
        msg = format_puhlyash_message(recipe)
        assert "Пухляша" in msg or "Рецепт" in msg
        assert "Тестовый рецепт" in msg
        assert len(msg) > 20

    def test_format_with_empty_ingredients(self):
        from modules.puhlyash.persona import format_puhlyash_message
        recipe = {
            "title": "Пустой рецепт",
            "description": "",
            "ingredients": "[]",
            "steps": "[]",
            "calories_per_serving": 0,
            "cook_time_minutes": 0,
            "servings": 2,
            "puhlyash_intro": "Тест",
        }
        msg = format_puhlyash_message(recipe)
        assert "Пустой рецепт" in msg

    def test_format_with_irisochka_tip(self):
        from modules.puhlyash.persona import format_puhlyash_message
        recipe = {
            "title": "Тест",
            "description": "",
            "ingredients": '["мука"]',
            "steps": '["замесить"]',
            "calories_per_serving": 200,
            "cook_time_minutes": 30,
            "servings": 4,
            "puhlyash_intro": "Вступление",
        }
        msg = format_puhlyash_message(recipe, irisochka_tip="🐭 Ирисочка: Совет!")
        assert "Ирисочка" in msg


class TestIrisochka:
    """Ирисочка — быстрые советы."""

    def test_get_quick_tip_returns_string(self):
        from modules.puhlyash.irisochka import get_quick_tip
        tip = get_quick_tip()
        assert isinstance(tip, str)
        assert len(tip) > 5

    def test_quick_tip_contains_irisochka(self):
        from modules.puhlyash.irisochka import get_quick_tip
        tip = get_quick_tip()
        assert "Ирисочка" in tip or "🐭" in tip

    def test_quick_tip_all_unique(self):
        from modules.puhlyash.irisochka import _QUICK_FACTS
        assert len(set(_QUICK_FACTS)) == len(_QUICK_FACTS)

    def test_quick_tips_minimum_count(self):
        from modules.puhlyash.irisochka import _QUICK_FACTS
        assert len(_QUICK_FACTS) >= 3


class TestSysPrompts:
    """Системные промпты персонажей."""

    def test_puhlyash_sys_prompt_exists(self):
        from modules.puhlyash.persona import SYS_PUHLYASH
        assert "Пухляш" in SYS_PUHLYASH
        assert "рыжий кот" in SYS_PUHLYASH.lower()

    def test_irisochka_sys_prompt_exists(self):
        from modules.puhlyash.irisochka import SYS_IRISOCHKA
        assert "Ирисочка" in SYS_IRISOCHKA
        assert "нутрициолог" in SYS_IRISOCHKA.lower()

    def test_sys_prompt_has_json_structure(self):
        from modules.puhlyash.persona import SYS_PUHLYASH
        assert "title" in SYS_PUHLYASH
        assert "ingredients" in SYS_PUHLYASH

````

---

## Файл: tests/test_vault_integration.py

`3899 байт`

````
"""Тесты интеграции diet_platform с Secrets Vault."""
import pytest
import json
from unittest.mock import patch, MagicMock


class TestVaultSecretLoader:
    """VaultSecretLoader — методы работы с vault."""

    def test_health(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        ok = vault.health()
        # Vault running on port 8400 — should be True in production
        assert isinstance(ok, bool)

    def test_get_secret_not_found(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        val = vault.get_secret("NONEXISTENT_KEY_12345")
        assert val is None

    def test_get_secret_known_key(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        # TELEGRAM_BOT_TOKEN was migrated earlier
        val = vault.get_secret("TELEGRAM_BOT_TOKEN")
        if val is not None:
            assert isinstance(val, str)
            assert len(val) > 5

    def test_list_secrets_returns_dict(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        secrets = vault.list_secrets()
        assert isinstance(secrets, dict)

    def test_load_all_returns_dict(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        all_s = vault.load_all()
        assert isinstance(all_s, dict)

    def test_set_and_get_secret_roundtrip(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        ok = vault.set_secret("TEST_KEY", "test_value_123")
        if ok:
            val = vault.get_secret("TEST_KEY")
            assert val == "test_value_123"

    def test_set_secret_empty_value(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        # Empty string should still be accepted
        ok = vault.set_secret("TEST_EMPTY", "")
        # Either succeeds or fails gracefully
        assert isinstance(ok, bool)

    def test_batch_write(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        saved = vault.set_secrets_batch({"BATCH_K1": "v1", "BATCH_K2": "v2"})
        assert isinstance(saved, int)
        if saved > 0:
            assert vault.get_secret("BATCH_K1") == "v1"

    def test_close_no_error(self):
        from building_blocks.vault_integration import VaultSecretLoader
        vault = VaultSecretLoader(api_key="test")
        vault.close()  # should not raise
        vault.close()  # calling twice should also not raise

    def test_init_defaults(self):
        from building_blocks.vault_integration import VaultSecretLoader, VAULT_URL, PROJECT_ID
        vault = VaultSecretLoader()
        assert vault.vault_url == VAULT_URL
        assert vault.project_id == PROJECT_ID


class TestVaultConfig:
    """Настройки vault в config.py."""

    def test_settings_has_vault_fields(self):
        from building_blocks.config import get_settings
        s = get_settings()
        assert hasattr(s, "vault_url")
        assert hasattr(s, "vault_api_key")
        assert hasattr(s, "vault_project_id")
        assert hasattr(s, "vault_enabled")

    def test_vault_default_url(self):
        from building_blocks.config import get_settings
        s = get_settings()
        assert s.vault_url == "http://127.0.0.1:8400"

    def test_vault_default_project(self):
        from building_blocks.config import get_settings
        s = get_settings()
        assert s.vault_project_id == "diet_platform"

````

---

## Файл: workers/pipeline_worker.py

`7507 байт`

````
"""Pipeline Worker: читает Outbox -> парсит -> экстрагирует -> регистрирует.

Transactional Outbox pattern: все задачи в SQLite, нет потери при рестарте.
"""
import asyncio
import json
import uuid
from datetime import datetime, timedelta
import aiosqlite

from building_blocks.config import get_settings
from building_blocks.contracts import PipelineStatus, FetchFailReason
from building_blocks.logger import get_logger, set_trace_context
from database import DB_PATH
from modules.web_scraper.fetcher.http_fetcher import fetch_url
from modules.diet_extractor.engine.gemini_extractor import extract_diet
from modules.diet_registry.infrastructure.repository import register_diet_draft

log = get_logger(__name__)
cfg = get_settings()

_semaphore: asyncio.Semaphore = None


def _get_semaphore() -> asyncio.Semaphore:
    global _semaphore
    if _semaphore is None:
        _semaphore = asyncio.Semaphore(cfg.worker_max_concurrent)
    return _semaphore


async def _process_fetch_task(db: aiosqlite.Connection, task: dict) -> None:
    """Fetch URL -> Extract -> Register в одном pipeline."""
    payload = json.loads(task["payload"])
    task_id = task["id"]
    session_id = payload["session_id"]
    trace_id = payload["trace_id"]
    url = payload["url"]

    set_trace_context(trace_id, session_id)
    log.info("➔ Processing task %s | url=%s", task_id, url)

    # Mark as processing
    await db.execute(
        "UPDATE outbox SET status='processing', attempt=attempt+1 WHERE id=?",
        (task_id,)
    )
    await db.commit()

    try:
        # Step 1: Fetch
        result = await fetch_url(url, task_id, trace_id)

        if not result["ok"]:
            fail_reason = result["fail_reason"]
            log.warning("[❌] Fetch failed: %s | %s", task_id, fail_reason)
            await _handle_failure(db, task, str(fail_reason), payload)
            return

        # Save snapshot
        await db.execute(
            """INSERT OR IGNORE INTO web_snapshots
               (id, session_id, trace_id, source_url, content_sha256,
                raw_text_length, http_status)
               VALUES(?,?,?,?,?,?,?)""",
            (task_id, session_id, trace_id, url,
             result["content_sha256"], result["content_length"],
             result["http_status"])
        )

        # Step 2: Extract
        draft_cmd = await extract_diet(
            raw_text=result["raw_text"],
            source_url=url,
            session_id=session_id,
            trace_id=trace_id,
            content_sha256=result["content_sha256"],
        )

        if draft_cmd is None:
            log.info("[⏭] Low confidence, sending to DLQ: %s", task_id)
            await _to_dlq(db, task, "LOW_CONFIDENCE", payload)
            await db.execute(
                "UPDATE outbox SET status='dlq' WHERE id=?", (task_id,)
            )
            await _update_session_progress(db, session_id)  # BUG-03 fix
            await db.commit()
            return

        # Step 3: Register (sync call)
        diet_id, status = await register_diet_draft(db, draft_cmd)
        log.info("[✅] Registered diet=%s status=%s", diet_id, status.value)

        # Mark outbox done
        await db.execute(
            "UPDATE outbox SET status='done', processed_at=datetime('now') WHERE id=?",
            (task_id,)
        )

        # Update session status
        await _update_session_progress(db, session_id)
        await db.commit()

    except Exception as e:
        log.error("[❌] Unexpected error in task %s: %s", task_id, e, exc_info=True)
        await _handle_failure(db, task, str(e), payload)


async def _handle_failure(
    db: aiosqlite.Connection, task: dict, error: str, payload: dict
) -> None:
    attempt = task["attempt"] + 1
    max_attempts = task["max_attempts"]

    session_id = payload.get("session_id", "-")
    if attempt >= max_attempts:
        log.warning("Max attempts reached for task %s, moving to DLQ", task["id"])
        await _to_dlq(db, task, error, payload)
        await db.execute(
            "UPDATE outbox SET status='dlq', error=? WHERE id=?",
            (error, task["id"])
        )
        await _update_session_progress(db, session_id)  # BUG-03 fix
    else:
        # Exponential backoff: 2^attempt * 5 seconds
        delay_seconds = min(5 * (2 ** attempt), 300)
        scheduled = (datetime.utcnow() + timedelta(seconds=delay_seconds)).isoformat()
        await db.execute(
            "UPDATE outbox SET status='pending', attempt=?, error=?, scheduled_at=? WHERE id=?",
            (attempt, error, scheduled, task["id"])
        )
        log.info("Task %s rescheduled in %ds (attempt %d/%d)",
                 task["id"], delay_seconds, attempt, max_attempts)
    await db.commit()


async def _to_dlq(
    db: aiosqlite.Connection, task: dict, reason: str, payload: dict
) -> None:
    await db.execute(
        """INSERT OR IGNORE INTO dlq
           (id, outbox_id, session_id, trace_id, event_type, payload, reason)
           VALUES(?,?,?,?,?,?,?)""",
        (
            str(uuid.uuid4()), task["id"],
            task["session_id"], task["trace_id"],
            task["event_type"], task["payload"], reason
        )
    )


async def _update_session_progress(db: aiosqlite.Connection, session_id: str) -> None:
    async with db.execute(
        "SELECT COUNT(*) as total FROM outbox WHERE session_id=?", (session_id,)
    ) as cur:
        total_row = await cur.fetchone()
    async with db.execute(
        "SELECT COUNT(*) as done FROM outbox WHERE session_id=? AND status IN ('done','dlq')",
        (session_id,)
    ) as cur:
        done_row = await cur.fetchone()

    total = total_row[0] if total_row else 1
    done = done_row[0] if done_row else 0

    if done >= total:
        await db.execute(
            "UPDATE search_sessions SET status=?, updated_at=datetime('now') WHERE id=?",
            (PipelineStatus.COMPLETED.value, session_id)
        )


async def run_worker_loop() -> None:
    """Main worker loop: поллинг Outbox каждые N секунд."""
    log.info("▶ Pipeline worker started (poll=%ds, concurrent=%d)",
             cfg.worker_poll_interval_seconds, cfg.worker_max_concurrent)
    sem = _get_semaphore()

    while True:
        try:
            async with aiosqlite.connect(DB_PATH, timeout=30) as db:
                db.row_factory = aiosqlite.Row
                now = datetime.utcnow().isoformat()

                async with db.execute(
                    """SELECT * FROM outbox
                       WHERE status='pending' AND scheduled_at<=?
                       ORDER BY created_at ASC LIMIT ?""",
                    (now, cfg.worker_max_concurrent)
                ) as cur:
                    tasks = await cur.fetchall()

                if tasks:
                    log.info("📦 Found %d pending tasks", len(tasks))
                    coros = [
                        _run_with_semaphore(sem, db, dict(t))
                        for t in tasks
                    ]
                    await asyncio.gather(*coros, return_exceptions=True)

        except Exception as e:
            log.error("❌ Worker loop error: %s", e, exc_info=True)

        await asyncio.sleep(cfg.worker_poll_interval_seconds)


async def _run_with_semaphore(
    sem: asyncio.Semaphore,
    db: aiosqlite.Connection,
    task: dict,
) -> None:
    async with sem:
        await _process_fetch_task(db, task)
````

---

## Пропущенные файлы (медиа/бинарные/крупные)

- `.pytest_cache/CACHEDIR.TAG` — медиа/бинарный, 191 байт
- `.pytest_cache/v/cache/lastfailed` — медиа/бинарный, 2 байт
- `.pytest_cache/v/cache/nodeids` — медиа/бинарный, 2504 байт
- `bot_handlers/__init__.py` — бинарный, 0 байт
- `bot_handlers/recipes.py.bak_before_model_switch` — медиа/бинарный, 16147 байт
- `building_blocks/__init__.py` — бинарный, 0 байт
- `building_blocks/config.py.bak_before_model_switch` — медиа/бинарный, 1414 байт
- `diet_platform.db` — медиа/бинарный, 458752 байт
- `diet_platform.db-shm` — медиа/бинарный, 32768 байт
- `diet_platform.db-wal` — медиа/бинарный, 0 байт
- `dump_project.sh.bak` — медиа/бинарный, 3273 байт
- `logs/diet_platform.log` — слишком большой, 1712730 байт
- `modules/__init__.py` — бинарный, 0 байт
- `modules/diet_extractor/engine/gemini_extractor.py.bak_before_model_switch` — медиа/бинарный, 8514 байт
- `modules/fitness/__init__.py` — бинарный, 0 байт
- `modules/notifier/__init__.py` — бинарный, 0 байт
- `modules/notifier/sender.py.bak_20260619_211357` — медиа/бинарный, 2248 байт
- `modules/puhlyash/__init__.py` — бинарный, 0 байт
- `modules/reactions/__init__.py` — бинарный, 0 байт
- `modules/recipes/__init__.py` — бинарный, 0 байт
- `modules/scheduler/__init__.py` — бинарный, 0 байт
- `tests/__init__.py` — бинарный, 0 байт
